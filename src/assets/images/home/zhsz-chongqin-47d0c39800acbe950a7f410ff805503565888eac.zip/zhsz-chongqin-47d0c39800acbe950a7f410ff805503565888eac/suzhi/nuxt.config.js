import pkg from './package'
/*
 ** axios config for development
 */

// export const baseURL = 'http://wp-suzhi.yunschool.com'
export const baseURL = '/api/'

export default {
  mode: 'universal',

  /*
   ** Headers of the page
   */
  head: {
    title: '综合素质评定',
    meta: [
      {
        charset: 'utf-8'
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1'
      },
      {
        hid: 'description',
        name: 'description',
        content: pkg.description
      }
    ],
    link: [
      {
        rel: 'icon',
        type: 'image/x-icon',
        href: '/favicon.ico'
      }
    ]
  },

  router: {
    scrollBehavior: function(to, from, savedPosition) {
      const scrollWarpper = document.querySelector('.iframe-outter')
      scrollWarpper && scrollWarpper.scrollTo(0, 0)
      // if (savedPosition) {
      //   return savedPosition
      // } else {
      //   let position = {}
      //   // 目标页面子组件少于两个
      //   if (to.matched.length < 2) {
      //     // 滚动至页面顶部滚动至页面顶部
      //     position = { x: 0, y: 0 }
      //   } else if (
      //     to.matched.some(r => r.components.default.options.scrollToTop)
      //   ) {
      //     // 如果目标页面子组件中存在配置了scrollToTop为true
      //     position = { x: 0, y: 0 }
      //   }
      //   // 如果目标页面的url有锚点,  则滚动至锚点所在的位置
      //   if (to.hash) {
      //     position = { selector: to.hash }
      //   }
      //   return position
      // }
    }
  },
  /*
   ** Customize the progress-bar color
   */
  loading: {
    color: '#8db6f1',
    failedColor: '#347ee9'
  },

  /*
   ** Global CSS
   */
  css: [
    {
      src: 'assets/main.css'
    },
    {
      src: 'assets/css/reset.css'
    },
    {
      src: 'ant-design-vue/lib/table/style/index.css'
    },
    {
      src: 'ant-design-vue/lib/date-picker/style/index.css'
    },
    {
      src: 'ant-design-vue/lib/select/style/index.css'
    },
    {
      src: 'ant-design-vue/lib/pagination/style/index.css'
    },
    {
      src: 'ant-design-vue/lib/checkbox/style/index.css'
    },
    {
      src: 'ant-design-vue/lib/spin/style/index.css'
    },
    {
      src: 'assets/css/ant-design.css'
    },
    {
      src: 'assets/css/winupon.scss'
    }
  ],

  /*
   ** Plugins to load before mounting the App
   */
  plugins: [
    {
      src: '~/plugins/polyfill',
      ssr: false
    },
    {
      src: '~/plugins/route'
    },
    {
      src: '~/plugins/axios',
      ssr: true
    },
    {
      src: '~/plugins/winupon-ui',
      ssr: true
    },
    {
      src: '~/plugins/ant-design-vue',
      ssr: true
    },
    {
      src: '~/plugins/date-picker',
      ssr: false
    }
  ],

  /*
   ** Nuxt.js modules
   */
  modules: [
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    [
      'cookie-universal-nuxt',
      {
        alias: 'cookie'
      }
    ]
  ],
  /*
   ** Axios module configuration
   */
  // axios: process.env.NODE_ENV === 'production' ? production : development,
  axios: {
    prefix: '/api/',
    proxy: true,
    credentials: true,
    debug: true,
    progress: false
  },
  // axios: {
  //   baseURL: baseURL,
  //   browserBaseURL: baseURL,
  //   proxy: false,
  //   credentials: true,
  //   debug: false,
  //   progress: false
  // },
  // See https://github.com/nuxt-community/axios-module#options
  proxy: {
    '/api/': {
      // target: 'http://192.168.0.238:20000/mock/5c9a0b657ddb16132c821ab6/',
      target: 'http://192.168.0.16:8080/v7', // global setting proxy
      // target: 'http://192.168.0.131:8080/v7', // entry proxy
      // target: 'http://192.168.0.177:8080/', // entry proxy
      // target: 'http://192.168.0.22:8080/v7', // main proxy
      // target: 'http://192.168.22.13:97', // main proxy
      // target: baseURL, // main proxy
      // target: 'http://192.168.0.223:8085/', // main proxy
      changeOrigin: true,
      pathRewrite: {
        '^/api/': '/'
      }
    }
  },
  server: {
    port: 3000, // default: 3000
    // port: 3301, // default: 3000
    host: '0.0.0.0' // default: localhost
  },
  /*
   ** Build configuration
   */
  build: {
    /*
     ** You can extend webpack config here
     */
    analyze: false
    // extend(config, ctx) {
    //   // Run ESLint on save
    //   if (ctx.isDev && ctx.isClient) {
    //     config.module.rules.push({
    //       enforce: 'pre',
    //       test: /\.(js|vue)$/,
    //       loader: 'eslint-loader',
    //       exclude: /(node_modules)/
    //     })
    //   }
    // }
  }
}
