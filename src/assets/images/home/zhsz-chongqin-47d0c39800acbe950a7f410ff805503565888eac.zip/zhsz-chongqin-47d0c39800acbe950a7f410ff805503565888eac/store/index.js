export const state = () => ({
  acadyear: null,
  acadyearList: [],
  gradeList: [],
  semester: null,
  semesterList: [],
  globalSetting: {},
  defaultHost: '',
  initAlertState: false // 初始化弹窗状态
})

export const mutations = {
  // 设置全局变量
  setGlobalSetting(state, payload) {
    if (typeof payload === 'string') {
      payload = {}
    }
    state.globalSetting = payload
  },
  // 改变初始化弹窗状态
  changeInitAlert(state) {
    state.initAlertState = !state.initAlertState
  },
  // 获取学年学期年级选项列表
  setGradeAndAcadSemList(state, payload) {
    const {
      acadyear,
      acadyearList,
      gradeList,
      semester,
      semesterList
    } = payload
    state.acadyear = acadyear
    state.acadyearList = acadyearList
    state.gradeList = gradeList
    state.semester = semester
    state.semesterList = semesterList
  },
  setDefaultHost(state, payload) {
    // console.log(payload)
    if (payload) {
      state.defaultHost = payload
      // console.log(`配置host成功: ${state.defaultHost}`)
    } else {
      // console.log('配置host失败')
    }
  }
}

export const actions = {
  // 初始化store
  nuxtServerInit({ commit, dispatch }, { req, app, route, query, redirect }) {
    if (query.cid) {
      commit('setDefaultHost', query.cid)
    }
    const parentCookie = query.ckjid
    // const parentCookie = query.ckjid
    if (parentCookie) {
      app.$cookie.set('JSESSIONID', parentCookie)
    }
  },

  async findGlobal({ commit }) {
    const globalSetting = await this.$axios.$get(
      '/diathesis/setting/findGlobal'
    )
    commit('setGlobalSetting', globalSetting)
  },

  async getGradeAndAcadSemList({ commit }) {
    const {
      acadyear,
      acadyearList,
      gradeList,
      semester,
      semesterList
    } = await this.$axios.$get('/diathesis/getGradeAndAcadSemList')
    commit('setGradeAndAcadSemList', {
      acadyear,
      acadyearList,
      gradeList,
      semester,
      semesterList
    })
  }
}
