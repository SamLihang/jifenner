export const state = () => ({
  projectId: null
})

export const mutations = {
  setProjectId(state, payload) {
    state.projectId = payload
  }
}

export const actions = {}
