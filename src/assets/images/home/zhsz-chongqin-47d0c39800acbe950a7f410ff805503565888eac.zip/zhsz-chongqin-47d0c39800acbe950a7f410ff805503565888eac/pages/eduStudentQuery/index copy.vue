<!--  author: Li Hang   Date: 2019-4-1 -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-mixer>
        <wp-input></wp-input>
        <wp-button icon="search"></wp-button>
      </wp-mixer>
      <p>组织架构</p>
      <wp-tree></wp-tree>
    </div>
    <div class="wrapper_right">
      <div class="query_title">
        <wp-row>
          <wp-col align="center">
            <h5>学生综合素质查询</h5>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col align="center">
            <wp-mixer>
              <wp-select
                v-model="searchMode"
                :data="searchList"
                width="80px"
                value-key="value"
                label-key="label"
              ></wp-select>
              <wp-input
                v-model="searchKey"
                placeholder="请输入"
                v-on:keyup.enter.native="queryStudent"
                width="260px"
                maxlength="20"
                autofocus
              ></wp-input>
            </wp-mixer>
            <wp-button @click="queryStudent">查询</wp-button>
          </wp-col>
        </wp-row>
      </div>
      <transition name="page">
        <div class="query_result" v-if="studentList.length">
          <wp-tabbar
            v-model="tabbar"
            class="query_result_tabbar"
            :datasource="studentList"
            target="id"
            label-key="studentName"
            @change="tabbarChangeHandler"
          ></wp-tabbar>
          <template v-if="studentList.length">
            <wp-row>
              <wp-button-group>
                <wp-button @click="importHandler" :disabled="exporting">导出PDF</wp-button>
              </wp-button-group>
            </wp-row>
            <div id="baseTable">
              <wp-row>
                <wp-col align="center">
                  <h4>综合素质基本信息</h4>
                </wp-col>
              </wp-row>
              <wp-row>
                <table border="1" class="student_info">
                  <thead>
                    <tr>
                      <th colspan="100">学生综合信息</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>姓名</td>
                      <td class="content">{{ studentInfo.studentName }}</td>
                      <td>性别</td>
                      <td class="content">{{ studentInfo.sex }}</td>
                      <td>名族</td>
                      <td class="content">{{ studentInfo.nation }}</td>
                      <td>出生年月</td>
                      <td class="content">{{ studentInfo.birthday }}</td>
                    </tr>
                    <tr>
                      <td>身份证号</td>
                      <td class="content">{{ studentInfo.idCard }}</td>
                      <td>学校名称</td>
                      <td class="content">{{ studentInfo.schoolName }}</td>
                      <td>学籍号</td>
                      <td class="content">{{ studentInfo.stuCode }}</td>
                      <td>班级</td>
                      <td class="content">{{ studentInfo.className }}</td>
                    </tr>
                  </tbody>
                </table>
                <table border="1" class="quality_valuate">
                  <thead>
                    <tr>
                      <th colspan="100">综合素质考评</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td></td>
                      <td v-for="cls in classList" :key="cls.timeId">{{ cls.timeText }}</td>
                    </tr>
                    <tr v-for="(project,ind) in projectList" :key="ind">
                      <td class="content">{{ project[0] }}</td>
                      <td v-for="(val, index) in classList" :key="index">{{ project[index + 1] }}</td>
                    </tr>
                  </tbody>
                </table>
                <table border="1" class="subject_level">
                  <thead>
                    <tr>
                      <th colspan="100">学业水平</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="item in Math.ceil(subjectList.length / 15)">
                      <tr style="height: 10px" v-if="item!==1" :key="item"></tr>
                      <tr :key="item">
                        <td>科目</td>
                        <td
                          v-for="index in 15"
                          :key="index"
                        >{{ subjectList[(item-1) * 15 + index - 1] ? subjectList[(item-1) * 15 + index -1].subjectName : '' }}</td>
                      </tr>
                      <tr :key="item">
                        <td>成绩</td>
                        <td
                          v-for="index in 15"
                          :key="index"
                          class="content"
                        >{{ subjectList[(item-1) * 15 + index -1] ?subjectList[(item-1) * 15 + index -1].score : '' }}</td>
                      </tr>
                    </template>
                  </tbody>
                </table>
                <table border="1" class="subject_grade">
                  <thead>
                    <tr>
                      <th colspan="100">学科成绩</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="item in Math.ceil(classList.length / 3)">
                      <tr style="height: 10px" v-if="item!==1" :key="item"></tr>
                      <tr :key="'leixing' + item">
                        <td rowspan="2">类型</td>
                        <td rowspan="2">科目</td>
                        <td
                          v-for="cls in classList.slice((item-1) * 3,item * 3)"
                          :key="'kemu' + cls.timeId"
                          :colspan="1"
                        >{{ cls.timeText }}</td>
                      </tr>
                      <tr :key="'qita' + item">
                        <template v-for="(i,num) in classList.slice((item-1) * 3,item * 3)">
                          <td :key="'chengji' + num">成绩</td>
                          <!-- <td :key="i">学分</td> -->
                          <!-- <td :key="i">负责人</td> -->
                        </template>
                      </tr>
                      <tr
                        v-for="(subject, index) in requiredScoreList"
                        :key="item + 'bixiu' + index"
                      >
                        <td v-if="!index" :rowspan="requiredScoreList.length">必修课</td>
                        <td>{{ subject.subjectName }}</td>
                        <template v-for="cls in classList.slice((item-1) * 3,item * 3)">
                          <td
                            class="content"
                            :key="'content'+cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].score}}</td>
                          <!-- <td
                        class="content"
                        :key="cls.timeId"
                      >{{subject.data[cls.timeId] && subject.data[cls.timeId].credit}}</td>
                      <td
                        class="content"
                        :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].chargePerson}}</td>-->
                        </template>
                      </tr>
                      <tr
                        v-for="(subject, index) in optionalScoreList"
                        :key="item + 'xuanxiu' + index"
                      >
                        <td v-if="!index" :rowspan="optionalScoreList.length">选修课</td>
                        <td>{{ subject.subjectName }}</td>
                        <template v-for="cls in classList.slice((item-1) * 3,item * 3)">
                          <td
                            class="content"
                            :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].score}}</td>
                          <!-- <td
                        class="content"
                        :key="cls.timeId"
                      >{{subject.data[cls.timeId] && subject.data[cls.timeId].credit}}</td>
                      <td
                        class="content"
                        :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].chargePerson}}</td>-->
                        </template>
                      </tr>
                    </template>
                  </tbody>
                </table>
                <table border="1" class="subject_level">
                  <thead>
                    <tr>
                      <th colspan="100">写实记录</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>类型</td>
                      <td>项目</td>
                      <td>时间</td>
                      <td>内容</td>
                      <td>附件</td>
                    </tr>
                    <tr v-for="(record,index) in recordList" :key="index">
                      <td :rowspan="record.firstIndex" v-if="record.firstIndex">{{record.typeName}}</td>
                      <td
                        :rowspan="record.secondIndex"
                        v-if="record.secondIndex"
                      >{{record.projectName}}</td>
                      <td>{{formatData(record)}}</td>
                      <td>{{record.textContent}}</td>
                      <td>
                        <template v-if="record.fileList&&record.fileList.length">
                          <div v-for="(file,index) in record.fileList" :key="index">
                            <a href="javascript:void(0)" @click="downloadHandler(file)">{{file[0]}}</a>
                            <br />
                          </div>
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </wp-row>
            </div>
          </template>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
import { downloadFile } from '~/utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      tabbar: '',
      searchKey: '',
      searchMode: '1',
      studentInfo: {}, // 学生信息
      searchList: [
        { value: '1', label: '姓名' },
        { value: '2', label: '学号' }
      ],
      student_info_columns: [
        {
          title: '学生综合信息'
        }
      ],
      studentList: [],
      classList: [],
      projectList: [], // 综合素质
      subjectList: [], // 学业水平
      requiredScoreList: [],
      optionalScoreList: [],
      recordList: [], // 写实记录,
      requiredScoreListLength: 0,
      exporting: false
    }
  },
  computed: {},
  mounted() {
    // console.log(parent)
  },
  methods: {
    formatData(record) {
      for (let i of this.classList) {
        if (i.timeId === record.timeId) return i.timeText
      }
    },
    tabbarChangeHandler(item) {
      this.getStudentInfo(item.id)
    },
    async importHandler() {
      // const {
      //   data: { fileName, blob }
      // } = await this.$axios({
      //   method: 'get',
      //   url: '/diathesis/student/downExcel',
      //   params: { studentId: this.tabbar },
      //   responseType: 'blob'
      // })
      // downloadFile(fileName, blob)
      if (this.exporting) return
      const html2pdf = require('~/plugins/html2pdf').default
      this.exporting = true
      html2pdf(
        'baseTable',
        `${this.studentInfo.studentName}综合素质基本信息`,
        () => {
          this.exporting = false
        }
      )
    },
    async getStudentInfo(id) {
      const res = await this.$axios.$get(
        `/diathesis/student/getStuReport?studentId=${id}`
      )
      this.studentInfo = res.student || {}
      this.projectList = res.data1 || []
      this.subjectList = res.data2 || []
      this.classList = res.timeList || []
      let data3 = []
      res.data3.forEach(element => {
        if (
          data3.some(data => {
            if (data.subjectId === element.subjectId) {
              data.data[element.timeId] = element
              return true
            }
          })
        ) {
        } else {
          data3.push({
            subjectId: element.subjectId,
            subjectName: element.subjectName,
            data: { [element.timeId]: element }
          })
        }
      })
      let data4 = []
      res.data4.forEach(element => {
        if (
          data4.some(data => {
            if (data.subjectId === element.subjectId) {
              data.data[element.timeId] = element
              return true
            }
          })
        ) {
        } else {
          data4.push({
            subjectId: element.subjectId,
            subjectName: element.subjectName,
            data: { [element.timeId]: element }
          })
        }
      })
      let data5 = []
      let record = []
      res.data5.forEach(element => {
        if (
          data5.some(data => {
            if (data.typeName === element.typeName) {
              if (
                data.data.some(da => {
                  if (da.projectName === element.projectName) {
                    da.data.push(element)
                    return true
                  }
                })
              ) {
              } else {
                data.data.push({
                  projectName: element.projectName,
                  data: [element]
                })
              }
              return true
            }
          })
        ) {
        } else {
          data5.push({
            typeName: element.typeName,
            data: [{ projectName: element.projectName, data: [element] }]
          })
        }
      })
      data5.forEach((element, index) => {
        element.data.forEach((ele, ind) => {
          ele.data.forEach((e, i) => {
            if (!ind && !i) {
              let firstIndex = 0
              res.data5.forEach(j => {
                if (j.typeName === element.typeName) {
                  firstIndex++
                }
              })
              e.firstIndex = firstIndex
            }
            if (!i) {
              e.secondIndex = ele.data.length
            }
            record.push(e)
          })
        })
      })
      this.recordList = record
      this.requiredScoreList = data3
      this.optionalScoreList = data4
    },
    async queryStudent() {
      if (!this.searchKey.trim()) return
      this.studentList = await this.$axios.$get(
        `/diathesis/student/studentList?type=${this.searchMode}&typeValue=${this.searchKey}`
      )
      if (typeof this.studentList === 'string') {
        this.studentList = []
      }
      if (!this.studentList.length) {
        this.$warn.show({ title: '未查找到相关信息' })
        return
      }
      const { id } = this.studentList[0]
      this.tabbar = id
      this.getStudentInfo(id)
    },
    async downloadHandler(file) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: `/diathesis/common/downloadFile`,
        params: { filePath: file[1] },
        responseType: 'blob'
      })
      downloadFile(file[0], blob)
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper {
  .subject_level {
    width: 100%;
  }
  .query_title {
    background: #f2faff;
    padding: 40px 0;
  }
  .query_result {
    .query_result_tabbar {
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border: 1px solid #bfbfbf;
      background: #fff;
      margin-top: 20px;
      &:first-child {
        margin-top: 0;
      }
      & td,
      th {
        padding: 15px 10px 13px;
      }
      td {
        &.content {
          font-weight: 600;
        }
      }
      thead {
        background: #ececec;
      }
    }
  }
}
</style>
