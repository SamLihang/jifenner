<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <div class="wrapper_select">
        学年：
        <wp-select v-model="acadyear" :data="acadyearList" width="150px"></wp-select>
      </div>
      <div class="wrapper_select">
        学期：
        <wp-select
          v-model="semester"
          :data="semesterList"
          value-key="thisId"
          label-key="mcodeContent"
          width="150px"
        ></wp-select>
      </div>
      <div class="wrapper_select">
        年级：
        <wp-select
          v-model="gradeCode"
          :data="gradeList"
          value-key="gradeCode"
          label-key="gradeName"
          width="150px"
        ></wp-select>
      </div>
    </wp-row>
    <wp-row v-if="rowlist.length > 0">
      <a-table
        class="subjectTable"
        :scroll="{x: '200%'}"
        :columns="columns"
        bordered
        :loading="loading"
        :data-source="rowlist"
        :pagination="page.maxRowCount > 10 ? { current: pageIndex, pageSize: pageSize, total: page.maxRowCount || 0, showQuickJumper: true, showSizeChanger: true } : false"
        @change="tableChangeHandler"
        :locale="{emptyText: '暂无数据'}"
      ></a-table>
    </wp-row>
    <wp-row v-else>
      <div class="nocontent">
        <img src="~/assets/image/subject/nocontent.png" />
        <div class="nocontent_title">暂无数据</div>
      </div>
    </wp-row>
  </div>
</template>

<script>
const pageIndex = 1,
  pageSize = 50
export default {
  name: '',
  components: {},
  data() {
    return {
      loading: false
    }
  },
  async asyncData({ $axios }) {
    let {
      acadyearList = [],
      semesterList = [],
      acadyear = '',
      semester = '',
      gradeList = []
    } = await $axios.$get('/diathesis/getAcadSemList')
    semester = semester.toString()
    const gradeCode = gradeList[0].gradeCode
    let { page, unitList } = await $axios.$get(
      `/diathesis/unitQuery/comprehenStatistics?acadyear=${acadyear}&semester=${semester}&gradeCode=${gradeCode}`
    )
    let rowlist = []
    unitList &&
      unitList.forEach(maxitem => {
        let rowli = {}
        rowli.schoolName = maxitem.schoolName
        rowli.studentNum = maxitem.studentNum
        rowli.excellentNum = maxitem.excellentNum
        rowli.failNum = maxitem.failNum
        maxitem.projectScoreList.forEach((cenitem, cenindex) => {
          cenitem.scoreList.forEach(minitem => {
            rowli[`project${cenindex}` + minitem.score] = minitem.count
          })
        })
        rowlist.push(rowli)
      })
    return {
      acadyearList,
      semesterList,
      acadyear,
      semester,
      gradeList,
      gradeCode,
      page,
      pageSize: page.pageSize,
      pageIndex: page.pageIndex,
      unitList,
      rowlist
    }
  },
  watch: {
    acadyear(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    semester(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    gradeCode(newVal) {
      this.pageIndex = 1
      this.getData()
    }
  },
  methods: {
    async getData() {
      this.loading = true
      const { page, unitList } = await this.$axios.$get(
        `/diathesis/unitQuery/comprehenStatistics?acadyear=${this.acadyear}&semester=${this.semester}&_pageIndex=${this.pageIndex}&_pageSize=${this.pageSize}&gradeCode=${this.gradeCode}`
      )
      this.unitList = unitList
      let rowlist = []
      unitList &&
        unitList.forEach(maxitem => {
          let rowli = {}
          rowli.schoolName = maxitem.schoolName
          rowli.studentNum = maxitem.studentNum
          rowli.excellentNum = maxitem.excellentNum
          rowli.failNum = maxitem.failNum
          maxitem.projectScoreList.forEach((cenitem, cenindex) => {
            cenitem.scoreList.forEach(minitem => {
              rowli[`project${cenindex}` + minitem.score] = minitem.count
            })
          })
          rowlist.push(rowli)
        })
      this.rowlist = rowlist
      this.loading = false
    },
    tableChangeHandler(pagination) {
      this.pageIndex = pagination.current
      this.pageSize = pagination.pageSize
      this.getData()
    }
  },
  computed: {
    columns() {
      const columnsList = [
        {
          title: '序号',
          customRender: (text, row, index) => {
            return {
              children: (this.pageIndex - 1) * this.pageSize + index + 1
            }
          },
          fixed: 'left',
          width: 100
        },
        {
          title: '学校名称',
          dataIndex: 'schoolName',
          fixed: 'left',
          width: 100
        },
        {
          title: '学生人数',
          dataIndex: 'studentNum',
          fixed: 'left',
          width: 100
        },
        {
          title: '全优秀人数',
          dataIndex: 'excellentNum',
          fixed: 'left',
          width: 100
        },
        {
          title: '不合格',
          dataIndex: 'failNum',
          fixed: 'left',
          width: 100
        }
      ]
      let scoreitem = []
      this.unitList[0].projectScoreList.forEach((project, index) => {
        let scoreitem = []
        project.scoreList.forEach(scorearr => {
          scoreitem.push({
            title: scorearr.score,
            dataIndex: `project${index}` + scorearr.score
          })
        })
        columnsList.push({
          title: project.name,
          dataIndex: `project${index}`,
          children: scoreitem,
          customRender: text => {
            return {
              children: text === '无' ? '' : text
            }
          }
        })
      })
      return columnsList
    }
  },
  mounted() {}
}
</script>
<style lang='scss' scoped>
.wrapper_select {
  display: inline-block;
  margin-right: 20px;
}
.wrapper {
  .subjectTable {
    white-space: nowrap;
  }
}
</style>