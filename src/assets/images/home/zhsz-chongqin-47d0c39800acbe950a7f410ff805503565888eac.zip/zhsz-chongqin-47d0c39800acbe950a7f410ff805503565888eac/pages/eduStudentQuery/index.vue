<template>
  <div class="wrapper mulual_body clearfix">
    <div class="mulual_body_left">
      <wp-mixer class="student_body_search">
        <wp-input placeholder="请输入" width="108px" maxlength="10" v-model="searchKey"></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999"></wp-icon>
        </wp-button>
      </wp-mixer>
      <wp-tree
        :data="treeData"
        @select="queryStudent"
        :filter="searchKey"
        open_icon="angle-single-right"
        close_icon="angle-single-right"
        class="treeheight"
        :loaddata="loaddata"
        ref="mytree"
      ></wp-tree>
    </div>
    <div class="mulual_body_right">
      <div class="no_content" v-show="!studentid">
        <img src="~/assets/image/studentquery/nocontent.png" />
        <div class="no_content_title">请在左侧选择学生查询哦</div>
      </div>
      <div :class="changeshow ? 'quality_box' : 'quality_box showani'" v-show="studentid">
        <div class="query_result">
          <template v-if="studentid">
            <wp-row>
              <wp-button-group>
                <wp-button @click="importHandler" :disabled="exporting">导出PDF</wp-button>
              </wp-button-group>
            </wp-row>
            <div id="baseTable" style="padding-bottom:20px;">
              <wp-row>
                <wp-col align="center">
                  <h4>综合素质基本信息</h4>
                </wp-col>
              </wp-row>
              <wp-row>
                <table border="1" class="student_info">
                  <thead>
                    <tr>
                      <th colspan="100">学生综合信息</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>姓名</td>
                      <td class="content">{{ studentInfo.studentName }}</td>
                      <td>性别</td>
                      <td class="content">{{ studentInfo.sex }}</td>
                      <td>名族</td>
                      <td class="content">{{ studentInfo.nation }}</td>
                      <td>出生年月</td>
                      <td class="content">{{ studentInfo.birthday }}</td>
                    </tr>
                    <tr>
                      <td>身份证号</td>
                      <td class="content">{{ studentInfo.idCard }}</td>
                      <td>学校名称</td>
                      <td class="content">{{ studentInfo.schoolName }}</td>
                      <td>学籍号</td>
                      <td class="content">{{ studentInfo.stuCode }}</td>
                      <td>班级</td>
                      <td class="content">{{ studentInfo.className }}</td>
                    </tr>
                  </tbody>
                </table>
                <table border="1" class="quality_valuate">
                  <thead>
                    <tr>
                      <th colspan="100">综合素质考评</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td></td>
                      <td v-for="cls in classList" :key="cls.timeId">{{ cls.timeText }}</td>
                    </tr>
                    <tr v-for="(project,ind) in projectList" :key="ind">
                      <td class="content">{{ project[0] }}</td>
                      <td v-for="(val, index) in classList" :key="index">{{ project[index + 1] }}</td>
                    </tr>
                  </tbody>
                </table>
                <table border="1" class="subject_level">
                  <thead>
                    <tr>
                      <th colspan="100">学业水平</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="item in Math.ceil(subjectList.length / 15)">
                      <tr style="height: 10px" v-if="item!==1" :key="item"></tr>
                      <tr :key="item">
                        <td>科目</td>
                        <td
                          v-for="index in 15"
                          :key="index"
                        >{{ subjectList[(item-1) * 15 + index - 1] ? subjectList[(item-1) * 15 + index -1].subjectName : '' }}</td>
                      </tr>
                      <tr :key="item">
                        <td>成绩</td>
                        <td
                          v-for="index in 15"
                          :key="index"
                          class="content"
                        >{{ subjectList[(item-1) * 15 + index -1] ?subjectList[(item-1) * 15 + index -1].score : '' }}</td>
                      </tr>
                    </template>
                  </tbody>
                </table>
                <table border="1" class="subject_grade">
                  <thead>
                    <tr>
                      <th colspan="100">学科成绩</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="item in Math.ceil(classList.length / 3)">
                      <tr style="height: 10px" v-if="item!==1" :key="item"></tr>
                      <tr :key="'leixing' + item">
                        <td rowspan="2">类型</td>
                        <td rowspan="2">科目</td>
                        <td
                          v-for="cls in classList.slice((item-1) * 3,item * 3)"
                          :key="'kemu' + cls.timeId"
                          :colspan="1"
                        >{{ cls.timeText }}</td>
                      </tr>
                      <tr :key="'qita' + item">
                        <template v-for="(i,num) in classList.slice((item-1) * 3,item * 3)">
                          <td :key="'chengji' + num">成绩</td>
                          <!-- <td :key="i">学分</td> -->
                          <!-- <td :key="i">负责人</td> -->
                        </template>
                      </tr>
                      <tr
                        v-for="(subject, index) in requiredScoreList"
                        :key="item + 'bixiu' + index"
                      >
                        <td v-if="!index" :rowspan="requiredScoreList.length">必修课</td>
                        <td>{{ subject.subjectName }}</td>
                        <template v-for="cls in classList.slice((item-1) * 3,item * 3)">
                          <td
                            class="content"
                            :key="'content'+cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].score}}</td>
                          <!-- <td
                        class="content"
                        :key="cls.timeId"
                      >{{subject.data[cls.timeId] && subject.data[cls.timeId].credit}}</td>
                      <td
                        class="content"
                        :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].chargePerson}}</td>-->
                        </template>
                      </tr>
                      <tr
                        v-for="(subject, index) in optionalScoreList"
                        :key="item + 'xuanxiu' + index"
                      >
                        <td v-if="!index" :rowspan="optionalScoreList.length">选修课</td>
                        <td>{{ subject.subjectName }}</td>
                        <template v-for="cls in classList.slice((item-1) * 3,item * 3)">
                          <td
                            class="content"
                            :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].score}}</td>
                          <!-- <td
                        class="content"
                        :key="cls.timeId"
                      >{{subject.data[cls.timeId] && subject.data[cls.timeId].credit}}</td>
                      <td
                        class="content"
                        :key="cls.timeId"
                          >{{subject.data[cls.timeId] && subject.data[cls.timeId].chargePerson}}</td>-->
                        </template>
                      </tr>
                    </template>
                  </tbody>
                </table>
                <table border="1" class="subject_level">
                  <thead>
                    <tr>
                      <th colspan="100">写实记录</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>类型</td>
                      <td>项目</td>
                      <td>时间</td>
                      <td>内容</td>
                      <td>附件</td>
                    </tr>
                    <tr v-for="(record,index) in recordList" :key="index">
                      <td :rowspan="record.firstIndex" v-if="record.firstIndex">{{record.typeName}}</td>
                      <td
                        :rowspan="record.secondIndex"
                        v-if="record.secondIndex"
                      >{{record.projectName}}</td>
                      <td>{{formatData(record)}}</td>
                      <td>{{record.textContent}}</td>
                      <td>
                        <template v-if="record.fileList&&record.fileList.length">
                          <div v-for="(file,index) in record.fileList" :key="index">
                            <a href="javascript:void(0)" @click="downloadHandler(file)">{{file[0]}}</a>
                            <br />
                          </div>
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </wp-row>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { downloadFile } from '~/utils/tools'
//判断树是否有子集，循环
function circulatesub(arr) {
  arr.forEach((item, index) => {
    item.label = item.name
    if (item.type === '2') {
      item.isLeaf = true
    }

    if (item.childList) {
      item.children = circulatesub(item.childList)
    }
  })
  return arr
}
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      //树结构数组
      treeData: [],
      studentid: '',
      tabbar: '',
      studentInfo: {}, // 学生信息
      student_info_columns: [
        {
          title: '学生综合信息'
        }
      ],
      studentList: [],
      classList: [],
      projectList: [], // 综合素质
      subjectList: [], // 学业水平
      requiredScoreList: [],
      optionalScoreList: [],
      recordList: [], // 写实记录,
      requiredScoreListLength: 0,
      exporting: false,
      searchKey: '',
      changeshow: true
    }
  },
  async asyncData({ $axios }) {
    const unitlist = await $axios.$get('/diathesis/unitQuery/findUnitList')
    let treeData = circulatesub(unitlist)
    return { treeData: treeData }
  },
  computed: {},
  mounted() {
    // console.log(parent)
  },
  methods: {
    //加载异步学生树
    loaddata(treeNode) {
      return new Promise(async resolve => {
        let childrenlist = await this.$axios.$get(
          `/diathesis/unitQuery/findClassBySchoolId?schoolId=${treeNode.id}`
        )
        treeNode.children = []
        childrenlist = childrenlist.filter(item => {
          let ishave = false
          ishave = item.studentList ? true : false
          return ishave
        })
        childrenlist.forEach((item, index) => {
          ;(item.id = item.classId), (item.label = item.className)
          item.studentList &&
            item.studentList.forEach((minitem, minindex) => {
              ;(minitem.id = minitem.studentId),
                (minitem.label = minitem.studentName)
            })
          item.children = item.studentList
        })
        treeNode.children = childrenlist
        resolve()
      })
    },
    formatData(record) {
      for (let i of this.classList) {
        if (i.timeId === record.timeId) return i.timeText
      }
    },
    tabbarChangeHandler(item) {
      this.getStudentInfo(item.id)
    },
    async importHandler() {
      // const {
      //   data: { fileName, blob }
      // } = await this.$axios({
      //   method: 'get',
      //   url: '/diathesis/student/downExcel',
      //   params: { studentId: this.tabbar },
      //   responseType: 'blob'
      // })
      // downloadFile(fileName, blob)
      if (this.exporting) return
      const html2pdf = require('~/plugins/html2pdf').default
      this.exporting = true
      html2pdf(
        'baseTable',
        `${this.studentInfo.studentName}综合素质基本信息`,
        () => {
          this.exporting = false
        }
      )
    },
    async getStudentInfo(id) {
      this.changeshow = false
      const res = await this.$axios.$get(
        `/diathesis/student/getStuReport?studentId=${id}`
      )
      this.studentInfo = res.student || {}
      this.projectList = res.data1 || []
      this.subjectList = res.data2 || []
      this.classList = res.timeList || []
      let data3 = []
      res.data3.forEach(element => {
        if (
          data3.some(data => {
            if (data.subjectId === element.subjectId) {
              data.data[element.timeId] = element
              return true
            }
          })
        ) {
        } else {
          data3.push({
            subjectId: element.subjectId,
            subjectName: element.subjectName,
            data: { [element.timeId]: element }
          })
        }
      })
      let data4 = []
      res.data4.forEach(element => {
        if (
          data4.some(data => {
            if (data.subjectId === element.subjectId) {
              data.data[element.timeId] = element
              return true
            }
          })
        ) {
        } else {
          data4.push({
            subjectId: element.subjectId,
            subjectName: element.subjectName,
            data: { [element.timeId]: element }
          })
        }
      })
      let data5 = []
      let record = []
      res.data5.forEach(element => {
        if (
          data5.some(data => {
            if (data.typeName === element.typeName) {
              if (
                data.data.some(da => {
                  if (da.projectName === element.projectName) {
                    da.data.push(element)
                    return true
                  }
                })
              ) {
              } else {
                data.data.push({
                  projectName: element.projectName,
                  data: [element]
                })
              }
              return true
            }
          })
        ) {
        } else {
          data5.push({
            typeName: element.typeName,
            data: [{ projectName: element.projectName, data: [element] }]
          })
        }
      })
      data5.forEach((element, index) => {
        element.data.forEach((ele, ind) => {
          ele.data.forEach((e, i) => {
            if (!ind && !i) {
              let firstIndex = 0
              res.data5.forEach(j => {
                if (j.typeName === element.typeName) {
                  firstIndex++
                }
              })
              e.firstIndex = firstIndex
            }
            if (!i) {
              e.secondIndex = ele.data.length
            }
            record.push(e)
          })
        })
      })
      this.recordList = record
      this.requiredScoreList = data3
      this.optionalScoreList = data4
      let that = this
      setTimeout(function() {
        that.changeshow = true
      }, 300)
    },
    async queryStudent(item) {
      if (item.studentId) {
        this.studentid = item.id
        this.tabbar = item.id
        this.getStudentInfo(item.id)
      }
    },
    async downloadHandler(file) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: `/diathesis/common/downloadFile`,
        params: { filePath: file[1] },
        responseType: 'blob'
      })
      downloadFile(file[0], blob)
    }
  }
}
</script>

<style lang="scss" scoped>
.addpointer {
  cursor: pointer;
}
.mulual_body {
  padding: 0;
  height: 100%;
}
.mulual_body_left {
  width: 180px;
  height: 100%;
  border-right: 1px solid #cccccc;
  float: left;
  .wp-tree {
    font-size: 16px;
  }
  .student_body_search {
    padding: 10px 20px;
  }
}
.mulual_body_right {
  width: calc(100% - 180px);
  height: 100%;
  float: left;
  padding: 20px;
  overflow-y: auto;
  .quality_box {
    padding: 20px;
    .query_result {
      .query_result_tabbar {
        margin-bottom: 20px;
      }
      table {
        width: 100%;
        border: 1px solid #bfbfbf;
        background: #fff;
        margin-top: 20px;
        &:first-child {
          margin-top: 0;
        }
        & td,
        th {
          padding: 15px 10px 13px;
        }
        td {
          &.content {
            font-weight: 600;
          }
        }
        thead {
          background: #ececec;
        }
      }
    }
  }
  .showani {
    opacity: 0;
  }
}

.mulual_body_right::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}

.mulual_body_right::-webkit-scrollbar-track {
  background-color: #fff;
}

.mulual_body_right::-webkit-scrollbar-thumb {
  background-color: #ccc;
}
i {
  color: #e8e8e8;
}
.no_content {
  text-align: center;
  width: 100%;
  height: 100%;
  padding-top: 20%;
  .no_content_title {
    font-size: 14px;
    color: #999999;
    margin-top: 15px;
  }
}
.treeheight {
  height: calc(100% - 60px);
}
</style>
