<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <div v-if="showdetail">
      <div class="sub_item clearfix" v-for="(item,index) in gradeList" :key="item.gradeId + index">
        <div class="sub_title">{{item.gradeName}}</div>
        <div class="subchild_item" v-for="scoreitem in item.scoreList" :key="scoreitem.scoreId">
          <div class="subchild_title">学业水平</div>
          <div class="subchild_body">
            <div
              class="subchild_head"
              @click="showDetail(item.gradeId,scoreitem.scoreId)"
              :title="scoreitem.scoreName"
            >{{scoreitem.scoreName}}</div>
            <div class="subchild_time">录入时间：{{scoreitem.importTime ? scoreitem.importTime : '无'}}</div>
          </div>
          <wp-popover :value="scoreitem.del">
            <span class="sub_delete" @click="scoreitem.del = true">
              <wp-icon name="shanchu" font-size="16" fill="#ffffff"></wp-icon>
            </span>
            <div slot="content">
              <p>确定要删除吗？</p>
              <wp-button-group style="margin-top: 10px; float: right">
                <wp-button
                  type="second"
                  size="small"
                  background="primary"
                  @click="scoreitem.del = false"
                >取消</wp-button>
                <wp-button
                  type="main"
                  size="small"
                  background="primary"
                  @click="confirmDelete(scoreitem)"
                >确定</wp-button>
              </wp-button-group>
            </div>
          </wp-popover>
        </div>

        <div class="subchild_add" @click="uploadHandler(item)">
          <wp-icon name="plus" font-size="36" fill="#317EEB"></wp-icon>
          <div class="add_title">导入</div>
        </div>
      </div>
    </div>
    <div class="nocontent" v-else>
      <img src="~assets/image/subject/nocontent.png" />
      <div class="nocontent_title">请录入学业水平成绩哦~</div>
      <wp-button
        v-for="(item,index) in gradeList"
        :key="item.gradeId + index"
        @click="uploadHandler(item)"
      >{{item.gradeName}}</wp-button>
    </div>
  </div>
</template>

<script>
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      showdetail: false
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let { gradeList = [] } = await $axios.$get(
      '/diathesis/scholastic/gradeList'
    )
    let showdetail = false
    gradeList.forEach(grade => {
      if (grade.scoreList && grade.scoreList.length) {
        showdetail = true
        grade.scoreList.forEach((score, scoreIndex) => {
          score.del = false
        })
      }
    })
    return { gradeList, showdetail }
  },
  mounted() {},
  methods: {
    uploadHandler(record) {
      this.$router.push({
        path: '/subjectlevelentry/upload',
        query: { gradeId: record.gradeId }
      })
    },
    async getData() {
      let { gradeList } = await this.$axios.$get(
        '/diathesis/scholastic/gradeList'
      )
      let showdetail = false
      gradeList.forEach(grade => {
        if (grade.scoreList && grade.scoreList.length) {
          showdetail = true
          grade.scoreList.forEach((score, scoreIndex) => {
            score.del = false
          })
        }
      })
      this.gradeList = gradeList
    },
    async confirmDelete(record) {
      record.del = false
      if (!record.scoreId) {
        this.$warn.show({ title: '无法删除' })
        return
      }
      const { data } = await this.$axios.get('/diathesis/scholastic/delete', {
        params: {
          scoreId: record.scoreId
        }
      })
      if (data && data.code === '00') {
        this.$warn.show({ title: '删除成功' })
        this.getData()
      } else {
        this.$warn.show({ title: data.msg })
      }
    },
    showDetail(gradeId, scoreId) {
      this.$router.push({
        path: '/subjectLevelEntry/subjectDetail',
        query: { gradeId: gradeId, scoreId: scoreId }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
i {
  color: #d9d9d9;
}
.sub_item {
  margin-bottom: 8px;
}
.sub_title {
  font-size: 16px;
  color: #333333;
  padding-bottom: 18px;
}
.subchild_item {
  margin-right: 20px;
  margin-bottom: 10px;
  background: #ffffff;
  border: 1px solid #cccccc;
  border-radius: 4px;
  width: 189px;
  height: 140px;
  float: left;
  position: relative;
  .subchild_title {
    font-size: 16px;
    color: #ffffff;
    background-image: url(~assets/image/subject/subtitle.png);
    height: 52px;
    text-align: center;
    padding-top: 14px;
  }
  .subchild_body {
    padding: 15px 10px;
    .subchild_head {
      overflow: hidden;
      cursor: pointer;
      padding-bottom: 15px;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    .subchild_time {
      color: #999999;
    }
  }
  .wp-popover {
    position: absolute;
    right: 0;
    top: 0;
  }
  .sub_delete {
    position: absolute;
    right: 0;
    top: 0;
    width: 32px;
    height: 32px;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 4px;
    cursor: pointer;
    text-align: center;
    padding-top: 6px;
    display: none;
  }
}
.subchild_add {
  margin-right: 20px;
  margin-bottom: 10px;
  background: #ffffff;
  border: 1px solid #cccccc;
  border-radius: 4px;
  width: 189px;
  height: 140px;
  float: left;
  text-align: center;
  padding-top: 35px;
  cursor: pointer;

  .add_title {
    font-size: 18px;
    color: var(--primary-color);
    margin-top: 4px;
  }
}
.subchild_add:hover {
  border: 1px solid var(--primary-color);
}
.subchild_item:hover {
  border: 1px solid var(--primary-color);
}
.subchild_item:hover .sub_delete {
  display: inline-block;
}
</style>
