<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <wp-tabbar
        v-model="scholasticId"
        target="id"
        :datasource="scholasticList"
        @change="scholasticChangeHandler"
      ></wp-tabbar>
    </wp-row>
    <wp-row>
      <span class="wp_fl lineHeight32">班级：</span>
      <wp-select
        v-model="classId"
        :data="classList"
        value-key="classId"
        label-key="className"
        placeholder="请选择"
        width="150px"
        @change="classChangeHandler"
        class="wp_fl"
      ></wp-select>
      <wp-mixer style="margin-left: 20px">
        <wp-select v-model="searchMode" :data="searchList" width="100px"></wp-select>
        <wp-input
          v-model="searchKey"
          placeholder="请输入"
          width="200px"
          maxlength="20"
          @keyup.enter.native="searchHander"
        ></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999" @click.native="searchHander"></wp-icon>
        </wp-button>
      </wp-mixer>
    </wp-row>
    <wp-row>
      <a-table
        class="subjectTable"
        :scroll="{x: '100%'}"
        :columns="columns"
        bordered
        :loading="loading"
        :data-source="studentList"
        :pagination="page.maxRowCount > 10 ? { current: pageIndex, pageSize: pageSize, total: page.maxRowCount || 0, showQuickJumper: true, showSizeChanger: true } : false"
        @change="tableChangeHandler"
        :locale="{emptyText: '暂无数据'}"
      ></a-table>
    </wp-row>
  </div>
</template>

<script>
const pageIndex = 1,
  pageSize = 10
function formatStudentList(studentList) {
  return Array.from(studentList, student => {
    const obj = {
      sex: student.sex,
      className: student.className,
      studentId: student.studentId,
      studentCode: student.studentCode,
      studentName: student.studentName
    }
    student.scoreList.forEach((item, index) => {
      obj[`score${index}`] = item
    })
    return obj
  })
}

export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      pageSize,
      pageIndex,
      scholasticId: this.$route.query.scoreId,
      classId: '',
      searchKey: '',
      searchMode: '姓名',
      searchList: ['姓名', '学号'],
      pagination: {},
      loading: false
    }
  },
  computed: {
    studentName() {
      if (this.searchMode === '姓名') {
        return this.searchKey
      } else {
        return ''
      }
    },
    studentCode() {
      if (this.searchMode === '学号') {
        return this.searchKey
      } else {
        return ''
      }
    },
    columns() {
      const columnsList = [
        {
          title: '序号',
          customRender: (text, row, index) => {
            return {
              children: (this.pageIndex - 1) * this.pageSize + index + 1
            }
          },
          fixed: 'left'
        },
        {
          title: '学生姓名',
          dataIndex: 'studentName',
          fixed: 'left'
        },
        {
          title: '学号',
          dataIndex: 'studentCode'
        },
        {
          title: '性别',
          dataIndex: 'sex'
        },
        {
          title: '班级',
          dataIndex: 'className'
        }
      ]
      this.courseList.forEach((course, index) => {
        columnsList.push({
          title: course,
          dataIndex: `score${index}`,
          customRender: text => {
            return {
              children: text === '无' ? '' : text
            }
          }
        })
      })
      return columnsList
    }
  },
  watch: {
    pagination: {
      handler: function(newVal, old) {
        // console.log(newVal)
      },
      deep: true
    },
    '$route.query': function(newVal) {
      this.getData()
    }
  },
  async asyncData({ $axios, query }) {
    const { gradeId = '', scoreId = '' } = query
    let { classList = [], scholasticList = [] } = await $axios.$get(
      `/diathesis/scholastic/classList?gradeId=${query.gradeId}`
    )
    classList.unshift({ classId: '', className: '全部' })
    scholasticList = Array.from(scholasticList, scholastic => {
      return {
        id: scholastic.scoreId,
        title: scholastic.scoreName
      }
    })
    let courseList = [],
      studentList = [],
      page = {}
    if (scoreId) {
      const res =
        (await $axios.$get(`/diathesis/scholastic/detail`, {
          params: {
            gradeId,
            scholasticId: scoreId,
            _pageIndex: pageIndex,
            _pageSize: pageSize
          }
        })) || {}
      courseList = res.courseList || []
      studentList = formatStudentList(res.studentList || [])
      page = res.page || {}
    }
    return { classList, scholasticList, courseList, studentList, page }
  },
  mounted() {},
  methods: {
    searchHander() {
      this.pageIndex = 1
      this.getData()
    },
    tableChangeHandler(pagination) {
      this.pageIndex = pagination.current
      this.pageSize = pagination.pageSize
      this.$nextTick(() => {
        this.getData()
      })
    },
    classChangeHandler() {
      this.pageIndex = 1
      this.$nextTick(() => {
        this.getData()
      })
    },
    scholasticChangeHandler(item) {
      this.searchKey = ''
      this.classId = ''
      this.$router.replace({
        path: this.$route.path,
        query: {
          ...this.$route.query,
          scoreName: item.title,
          scoreId: item.id
        }
      })
    },
    async getData() {
      this.loading = true
      const { gradeId, scoreId } = this.$route.query
      let {
        courseList = [],
        studentList = [],
        page = {}
      } = await this.$axios.$get(`/diathesis/scholastic/detail`, {
        params: {
          gradeId: gradeId,
          scholasticId: scoreId,
          classId: this.classId,
          studentName: this.studentName,
          studentCode: this.studentCode,
          _pageSize: this.pageSize,
          _pageIndex: this.pageIndex
        }
      })
      this.studentList = formatStudentList(studentList)
      this.courseList = courseList
      this.page = page
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
.wrapper {
  padding-top: 0;
  .subjectTable {
    white-space: nowrap;
  }
}
.lineHeight32 {
  line-height: 32px;
}
</style>
