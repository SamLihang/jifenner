<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <a-table
      rowKey="scoreId"
      :data-source="gradeList"
      :columns="columns"
      bordered
      :pagination="false"
      :locale="{emptyText: '暂无数据'}"
    >
      <template slot="detail" slot-scope="text, record">
        <template v-if="record.scoreName !== ''">
          <a href="javascript:;" @click="showDetail(record)">查看</a>
          <i style="color: #d9d9d9">|</i>
        </template>
        <wp-popover :value="record.del">
          <a href="javascript:;" @click="record.del = true">删除</a>
          <div slot="content">
            <p>确定要删除吗？</p>
            <wp-button-group style="margin-top: 10px; float: right">
              <wp-button
                type="second"
                size="small"
                background="primary"
                @click="record.del = false"
              >取消</wp-button>
              <wp-button
                type="main"
                size="small"
                background="primary"
                @click="confirmDelete(text)"
              >确定</wp-button>
            </wp-button-group>
          </div>
        </wp-popover>
      </template>
    </a-table>
  </div>
</template>

<script>
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      columns: [
        {
          title: '年级',
          dataIndex: 'gradeName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        },
        {
          title: '级别',
          dataIndex: 'year',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        },
        {
          title: '学考成绩',
          dataIndex: 'scoreName',
          customRender: text => {
            return {
              children: text || <p style="color: #999">—</p>
            }
          }
        },
        {
          title: '录入时间',
          dataIndex: 'importTime',
          customRender: text => {
            return {
              children: text || <p style="color: #999">—</p>
            }
          }
        },
        {
          title: '查看详情',
          scopedSlots: {
            customRender: 'detail'
          }
        },
        {
          title: '操作',
          customRender: (text, row, index) => {
            return {
              children: this.$createElement('a', {
                domProps: {
                  innerHTML: '导入',
                  href: 'javascript:void(0)'
                },
                on: {
                  click: () => {
                    this.uploadHandler(row)
                  }
                }
              }),
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let { gradeList = [] } = await $axios.$get(
      '/diathesis/scholastic/gradeList'
    )
    const arr = []
    gradeList.forEach(grade => {
      if (grade.scoreList && grade.scoreList.length) {
        grade.scoreList.forEach((score, scoreIndex) => {
          arr.push({
            gradeId: grade.gradeId,
            gradeName: grade.gradeName,
            year: grade.year,
            scoreId: score.scoreId,
            scoreName: score.scoreName,
            importTime: score.importTime,
            scoreLength: scoreIndex === 0 ? grade.scoreList.length : 0,
            del: false
          })
        })
      } else {
        arr.push({
          gradeId: grade.gradeId,
          gradeName: grade.gradeName,
          year: grade.year,
          scoreId: '',
          scoreName: '',
          importTime: '',
          scoreLength: 1,
          del: false
        })
      }
    })
    gradeList = arr
    return { gradeList }
  },
  mounted() {},
  methods: {
    uploadHandler(record) {
      this.$router.push({
        path: '/subjectlevelentry/upload',
        query: { gradeId: record.gradeId }
      })
    },
    async getData() {
      let { gradeList } = await this.$axios.$get(
        '/diathesis/scholastic/gradeList'
      )
      const arr = []
      gradeList.forEach(grade => {
        if (grade.scoreList && grade.scoreList.length) {
          grade.scoreList.forEach((score, scoreIndex) => {
            arr.push({
              gradeId: grade.gradeId,
              gradeName: grade.gradeName,
              year: grade.year,
              scoreId: score.scoreId,
              scoreName: score.scoreName,
              importTime: score.importTime,
              scoreLength: scoreIndex === 0 ? grade.scoreList.length : 0,
              del: false
            })
          })
        } else {
          arr.push({
            gradeId: grade.gradeId,
            gradeName: grade.gradeName,
            year: grade.year,
            scoreId: '',
            scoreName: '',
            importTime: '',
            scoreLength: 1,
            del: false
          })
        }
      })
      gradeList = arr
      this.gradeList = gradeList
    },
    async confirmDelete(record) {
      record.del = false
      if (!record.scoreId) {
        this.$warn.show({ title: '无法删除' })
        return
      }
      const { data } = await this.$axios.get('/diathesis/scholastic/delete', {
        params: {
          scoreId: record.scoreId
        }
      })
      if (data && data.code === '00') {
        this.$warn.show({ title: '删除成功' })
        this.getData()
      } else {
        this.$warn.show({ title: data.msg })
      }
    },
    showDetail(record) {
      this.$router.push({
        path: '/subjectLevelEntry/subjectDetail',
        query: { ...record }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
i {
  color: #d9d9d9;
}
</style>
