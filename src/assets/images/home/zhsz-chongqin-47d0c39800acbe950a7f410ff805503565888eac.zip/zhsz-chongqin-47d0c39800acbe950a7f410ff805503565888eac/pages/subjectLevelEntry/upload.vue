<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <file-upload
      v-model="fileList"
      :businessKey="businessKey"
      @downloadTemplate="downloadTemplate"
      @onSuccess="onSuccess"
      @exportErrorMsg="exportErrorMsg"
    ></file-upload>
  </div>
</template>

<script>
import fileUpload from '~/components/fileUpload'
import { downloadFile } from '~/utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {
    fileUpload
  },
  data() {
    return {
      fullPath: '',
      fileList: []
    }
  },
  props: {
    gradeId: {
      type: String,
      required: true
    }
  },
  async asyncData({ $axios, query }) {
    const { businessKey } = await $axios.$get(`/diathesis/common/execute`)
    return { businessKey }
  },
  methods: {
    async downloadTemplate() {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: `/diathesis/scholastic/template?gradeId=${this.$route.query.gradeId}`,
        responseType: 'blob'
      })
      downloadFile(fileName, blob)
    },
    async exportErrorMsg(path) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'post',
        url: `/diathesis/common/exportErrorExcel`,
        data: { errorPath: path },
        transformRequest: [
          function(data) {
            let ret = ''
            for (let it in data) {
              ret +=
                encodeURIComponent(it) +
                '=' +
                encodeURIComponent(data[it]) +
                '&'
            }
            return ret
          }
        ],
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        responseType: 'blob'
      })
      downloadFile(fileName, blob)
    },
    onSuccess(res, file) {
      this.fullPath = res.fullPath
      this.validate(file)
    },
    async validate(file) {
      const { success, msg, detailError } = await this.$axios.$get(
        `/diathesis/scholastic/validate`,
        {
          params: {
            filePath: this.fullPath,
            gradeId: this.$route.query.gradeId
          }
        }
      )
      if (success) {
        this.importHandler(file)
        this.fileList.some(item => {
          if (item.uid === file.uid) {
            item.operater = msg
            return true
          }
        })
      } else {
        this.fileList.some(item => {
          if (item.uid === file.uid) {
            item.operater = msg
            item.err = detailError
            return true
          }
        })
        this.$warn.show({ title: detailError })
      }
    },
    async importHandler(file) {
      const {
        errorCount = '',
        errorExcelPath = '',
        successCount = '',
        totalCount = ''
      } = await this.$axios.$get(`/diathesis/scholastic/import`, {
        params: {
          filePath: this.fullPath,
          params: this.$route.query
        }
      })
      this.fileList.some(item => {
        if (item.uid === file.uid) {
          item.errorCount = errorCount
          item.errorExcelPath = errorExcelPath
          item.successCount = successCount
          item.totalCount = totalCount
        }
      })
      if (totalCount && successCount === totalCount) {
        this.$warn.show({ title: '导入成功' })
      }
    }
  },
  computed: {},
  mounted() {}
}
</script>
<style lang='scss' scoped>
</style>