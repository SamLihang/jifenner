<template>
  <div class="wrapper">
    <wp-menu v-model="data" trigger="click" accordion></wp-menu>
  </div>
</template>

<script>
export default {
  data() {
    return {
      aaa: '',
      data: [
        {
          title: '用户管理系统',
          sub: [
            { title: '角色管理', link: '/rolemanagement' },
            { title: '互评小组', link: '/mulualEvaluation' }
          ]
        },
        {
          title: '全局设置',
          sub: [
            { title: '全局设置页', link: '/globalsetting/setting' },
            { title: '保存后展示', link: '/globalsetting' }
          ]
        },
        {
          title: '项目设置',
          sub: [
            { title: '项目设置页', link: '/projectsetting' },
            {
              title: '写实记录设置',
              link: '/projectsetting/realisticrecordsetting'
            },
            {
              title: '考评标准设置',
              link: '/projectsetting/evaluationStandardSetting'
            }
          ]
        },
        {
          title: '综合素质录入',
          sub: [
            {
              title: '学科成绩录入',
              sub: [
                { title: '学科成绩录入页', link: '/academicrecordentry' },
                { title: '成绩详情', link: '/academicrecordentry/detail' },
                {
                  title: '导入设置',
                  link: '/academicrecordentry/uploadsetting'
                },
                { title: '导入', link: '/academicrecordentry/upload' },
                { title: '下载模板', link: '/academicrecordentry/download' }
              ]
            },
            {
              title: '学业水平录入',
              sub: [
                { title: '学业水平录入页', link: '/subjectlevelentry' },
                { title: '成绩详情', link: '/subjectlevelentry/subjectdetail' }
              ]
            },
            {
              title: '综合素质分录入',
              sub: [
                {
                  title: '综合素质分录入页',
                  link: '/comprehensivequalityentry'
                },
                { title: '录入', link: '/comprehensivequalityentry/entry' }
              ]
            },
            {
              title: '写实记录录入',
              sub: [
                { title: '写实记录录入页', link: '/realisticrecordentry' },
                { title: '新增', link: '/realisticrecordentry/add' }
              ]
            },
            {
              title: '写实记录审核',
              sub: [
                { title: '待审核', link: '/realisticrecordaudit' },
                { title: '已审核', link: '/realisticrecordaudit/audited' }
              ]
            },
            {
              title: '学生查询',
              sub: [
                { title: '旧版学生查询', link: 'studentquery' },
                { title: '新版学生查询', link: '/studentquery/newindex' }
              ]
            },
            { title: '学生评价', link: 'studentevaluation' }
          ]
        },
        {
          title: '学生端',
          sub: [
            {
              title: '综合素质分录入',
              sub: [
                {
                  title: '综合素质分录入页',
                  link: '/stuComprehensiveQualityEntry'
                },
                {
                  title: '录入',
                  link: '/stuComprehensiveQualityEntry/entry'
                },
                {
                  title: '学生互评',
                  link: '/stuComprehensiveQualityEntry/mutualEvaluation'
                }
              ]
            },
            {
              title: '写实记录录入',
              sub: [
                {
                  title: '写实记录录入页',
                  link: '/stuRealisticRecordEntry'
                },
                {
                  title: '新增',
                  link: '/stuRealisticRecordEntry/add'
                }
              ]
            },
            {
              title: '学生自述',
              link: '/stuStudentReoprt'
            },
            {
              title: '综合素质查询',
              link: '/stustudentQuery'
            }
          ]
        },
        {
          title: '家长端',
          sub: [
            {
              title: '综合素质分录入',
              sub: [
                {
                  title: '综合素质分录入页',
                  link: '/famComprehensivequalityentry'
                },
                {
                  title: '录入',
                  link: '/famComprehensivequalityentry/entry'
                }
              ]
            },
            {
              title: '综合素质查询',
              link: 'famStudentQuery'
            }
          ]
        },
        {
          title: '教育局端',
          sub: [
            {
              title: '全局设置',
              sub: [
                { title: '全局设置页', link: '/eduGlobalsetting/setting' },
                { title: '保存后展示', link: '/eduGlobalsetting' }
              ]
            },
            {
              title: '下属单位权限设置',
              link: '/eduSubUnitSetting'
            },
            {
              title: '考评标准设置',
              // sub: [
              //   { title: '项目设置页', link: '/eduProjectSetting' },
              //   {
              //     title: '写实记录设置',
              //     link: '/eduProjectSetting/realisticRecordSetting'
              //   }
              // ],
              sub: [
                { title: '项目设置页', link: '/projectSetting' },
                {
                  title: '写实记录设置',
                  link: '/projectSetting/realisticRecordSetting'
                },
                {
                  title: '考评标准设置',
                  link: '/projectsetting/evaluationStandardSetting'
                }
              ]
            },
            {
              title: '统计查询',
              sub: [
                { title: '综合素质表查询', link: '/eduStudentQuery' },
                {
                  title: '综合素质分统计',
                  link: '/eduStudentQuery/comprehensiveQualityQuery'
                }
              ]
            }
          ]
        }
      ]
    }
  },
  mounted() {}
}
</script>
<style lang="scss">
.wrapper {
  padding: 20px;
  background: #fff;
}
</style>
