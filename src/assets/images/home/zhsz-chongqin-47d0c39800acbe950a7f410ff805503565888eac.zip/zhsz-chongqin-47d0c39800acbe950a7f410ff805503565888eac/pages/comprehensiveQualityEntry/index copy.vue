<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <a-table
      bordered
      row-key="index"
      :columns="columns"
      :data-source="dataSource"
      :pagination="false"
      :locale="{emptyText: '暂无数据'}"
    >
      <template slot="rowOperation" slot-scope="text, record">
        <router-link
          v-if="record.importTime && checkImportTime(record.importTime)"
          :to="{
            path: '/comprehensivequalityentry/entry',
            query: { ...record }
          }"
        >
          <p class="link">去录入</p>
        </router-link>
        <p v-else class="placehoder">去录入</p>
      </template>
    </a-table>
    <wp-alert
      :visible="setTimeAlertShow"
      title="设置时间"
      @close="setTimeAlertShow = false"
      @confirm="setTimeAlertConfirm"
    >
      <wp-row>
        <wp-col :span="5" align="right">年级:</wp-col>
        <wp-col :span="18" :offset="1">
          {{
          temporaryTimeSetting.gradeName
          }}
        </wp-col>
      </wp-row>
      <wp-row v-for="(score, index) in temporaryTimeSetting.scoreList" :key="index">
        <wp-col :span="5" align="right">{{ score.scoreName }}:</wp-col>
        <wp-col :span="18" :offset="1">
          <no-ssr>
            <date-picker
              v-model="score.importTime"
              range
              confirm
              confirm-text="确认"
              style="width:100%"
            />
          </no-ssr>
        </wp-col>
      </wp-row>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      setTimeAlertShow: false,
      temporaryTimeSetting: {}, // 临时的时间设置
      columns: [
        {
          title: '级别',
          dataIndex: 'year',
          key: 'year',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '年级',
          dataIndex: 'gradeName',
          key: 'gradeName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '学期',
          dataIndex: 'semesterName',
          key: 'semesterName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '评价类型',
          dataIndex: 'scoreName',
          key: 'scoreName'
        },
        {
          title: '录入时间',
          dataIndex: 'importTime',
          key: 'importTime',
          customRender: (text, row, index) => {
            return {
              children: text || <p class="placehoder">请先设置时间</p>
            }
          }
        },
        {
          title: '操作',
          scopedSlots: { customRender: 'rowOperation' }
        },
        {
          title: '操作',
          dataIndex: 'operation',
          customRender: (text, row, index) => {
            return {
              children: [
                this.$createElement('a', {
                  domProps: {
                    innerHTML: '设置时间',
                    href: 'javascript:void(0)'
                  },
                  on: {
                    click: () => {
                      this.clickHandler(row)
                    }
                  }
                }),
                this.isShowStatistics(row) ? (
                  <span>&nbsp;&nbsp;|&nbsp;&nbsp;</span>
                ) : (
                  ''
                ),
                this.isShowStatistics(row)
                  ? this.$createElement('a', {
                      domProps: {
                        innerHTML: '统计',
                        href: 'javascript:void(0)'
                      },
                      on: {
                        click: () => {
                          this.checkStatisticsHandler(row)
                        }
                      }
                    })
                  : ''
              ],
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    const { gradeList = [] } = await $axios.$get(
      '/diathesis/comprehensive/quality/gradeList'
    )
    let scoreNum = 0
    const dataSource = []
    gradeList.forEach((grade, index) => {
      scoreNum = grade.scoreList.length
      grade.scoreList.forEach((score, i) => {
        dataSource.push({
          index: `${index}${i}`,
          gradeId: grade.gradeId,
          gradeCode: grade.gradeCode,
          year: grade.year,
          gradeName: grade.gradeName,
          semester: grade.semester,
          scoreName: score.scoreName,
          semesterName: grade.semesterName,
          scoreType: score.scoreType,
          scoreId: score.scoreId,
          importTime: score.importTime
        })
      })
    })
    return { dataSource, scoreNum, gradeList }
  },
  mounted() {},
  methods: {
    // 检测是否在录入时间范围内
    checkImportTime(importTime) {
      if (importTime) {
        let importTimeArr = importTime.split('~')
        let startTime =
          +new Date(importTimeArr[0]) +
          new Date().getTimezoneOffset() * 60 * 1000
        let endTime =
          +new Date(importTimeArr[1]) +
          new Date().getTimezoneOffset() * 60 * 1000 +
          1 * 24 * 60 * 60 * 1000
        let nowTime = +new Date()
        if (nowTime >= startTime && nowTime < endTime) {
          return true
        }
      }
      return false
    },
    // 是否展示统计
    isShowStatistics(row) {
      let isShow = true
      this.gradeList.some(grade => {
        if (grade.gradeId === row.gradeId) {
          isShow =
            grade.scoreList &&
            // 每条数据的录入结束时间小于现在时间则显示
            grade.scoreList.every(score => {
              return (
                score.importTime &&
                typeof score.importTime === 'string' &&
                +new Date(score.importTime.split('~')[1]) +
                  16 * 60 * 60 * 1000 <
                  +new Date()
              )
            })
          return true
        }
      })
      return isShow
    },
    async checkStatisticsHandler(row) {
      const { success: checkSuccess, msg: checkMsg } = await this.$axios.$get(
        '/diathesis/student/checkStatStudent',
        {
          params: {
            gradeId: row.gradeId,
            gradeCode: row.gradeCode,
            semester: row.semester
          }
        }
      )
      if (!checkSuccess) {
        this.$warn.show({ title: checkMsg })
        return
      } else if (checkMsg === 'old') {
        this.$alert.show({
          title: '统计',
          type: 'warning',
          message: '是否重新统计？',
          description: '重新统计将覆盖之前的统计数据。',
          closeCallBack: () => {
            this.$alert.hide()
          },
          confirmCallBack: () => {
            this.statisticsHandler(row)
            this.$alert.hide()
          }
        })
        return
      } else {
        this.statisticsHandler(row)
      }
    },
    async statisticsHandler(row) {
      const { success, msg } = await this.$axios.$get(
        '/diathesis/student/statStudent',
        {
          params: {
            gradeId: row.gradeId,
            gradeCode: row.gradeCode,
            semester: row.semester
          }
        }
      )
      if (success) {
        this.$warn.show({ title: '统计成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    clickHandler(row) {
      this.gradeList.some(grade => {
        if (grade.gradeId === row.gradeId) {
          let _grade = deepClone(grade)
          _grade.scoreList.forEach(item => {
            item.importTime &&
              (item.importTime = this.parseDate(item.importTime))
          })
          this.temporaryTimeSetting = _grade
          return true
        }
      })
      // console.log(this.temporaryTimeSetting)
      this.setTimeAlertShow = true
    },
    parseDate(time) {
      let timeArr = []
      typeof time === 'string' &&
        time.split('~').forEach(item => {
          timeArr.push(new Date(item))
        })
      return timeArr
    },
    async setTimeAlertConfirm() {
      let timeSetList = []
      this.temporaryTimeSetting.scoreList.forEach((score, index) => {
        if (score.importTime && score.importTime[0] && score.importTime[1]) {
          timeSetList.push(
            `${score.scoreType}:${this.formatDate(
              this.temporaryTimeSetting.scoreList[index].importTime[0]
            )}~${this.formatDate(
              this.temporaryTimeSetting.scoreList[index].importTime[1]
            )}`
          )
        }
      })
      if (timeSetList.length) {
        const { success, msg } = await this.$axios.$post(
          `/diathesis/comprehensive/quality/timeset?gradeId=${
            this.temporaryTimeSetting.gradeId
          }&timeSet=${timeSetList.join(',')}`
        )
        if (success) {
          this.$warn.show({ title: '修改成功' })
          this.getDate()
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
      this.setTimeAlertShow = false
    },
    formatDate(date) {
      let seperator1 = '-'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let currentdate =
        date.getFullYear() + seperator1 + month + seperator1 + strDate
      return currentdate
    },
    async getDate() {
      const { gradeList } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/gradeList'
      )
      let scoreNum
      const dataSource = []
      gradeList.forEach((grade, index) => {
        scoreNum = grade.scoreList.length
        grade.scoreList.forEach((score, i) => {
          dataSource.push({
            index: `${index}${i}`,
            gradeId: grade.gradeId,
            year: grade.year,
            gradeCode: grade.gradeCode,
            gradeName: grade.gradeName,
            semester: grade.semester,
            semesterName: grade.semesterName,
            scoreName: score.scoreName,
            scoreType: score.scoreType,
            scoreId: score.scoreId,
            importTime: score.importTime
          })
        })
      })
      this.dataSource = dataSource
      this.scoreNum = scoreNum
      this.gradeList = gradeList
    }
  }
}
</script>
<style lang="scss" scoped>
.link {
  color: #1890ff;
  cursor: pointer;
}
.placehoder {
  color: #999;
}
</style>
