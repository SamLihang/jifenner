<!--  author:   Date:  -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-mixer class="student_body_search">
        <wp-input placeholder="请输入" width="108px" maxlength="10" v-model="searchKey"></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999"></wp-icon>
        </wp-button>
      </wp-mixer>
      <wp-tree
        accordion
        title="组织架构"
        :data="classList"
        open_icon="arrow-line"
        close_icon="arrow-line"
        @select="treeSelectHandler"
        :default_select="classList[0] && classList[0].children[0]"
        :filter="searchKey"
        ref="classtree"
      ></wp-tree>
      <wp-button-group>
        <wp-button type="main" background="primary" style="width:74px;" @click="moveup">上一个</wp-button>
        <wp-button type="main" background="primary" style="width:74px;" @click="movedown">下一个</wp-button>
      </wp-button-group>
    </div>
    <transition name="page">
      <div class="wrapper_right" ref="wrapperright">
        <wp-row>
          <a-table
            bordered
            class="table"
            key="thirdDiathesisId"
            :data-source="diathesisList"
            :columns="columns"
            :locale="{emptyText: '暂无数据'}"
            :pagination="false"
            :loading="loading"
          >
            <div slot="selfEvaluation" :key="index" slot-scope="text, record, index">
              <template v-if="text === '/'">{{text}}</template>
              <template
                v-else-if="+scoreTypeIds[0] === 0
                ||
                !checkImportTime(scoreTypeTimes[0])"
              >{{text}}</template>
              <template v-else-if="inputValueType === 'S'">
                <wp-number-input
                  class="datainput"
                  type="number"
                  width="80"
                  v-model="record.selfEvaluation"
                  :max="100"
                  :min="0"
                ></wp-number-input>
              </template>
              <template v-else>
                <wp-select width="80px" :data="rankItems" v-model="record.selfEvaluation">{{record}}</wp-select>
              </template>
            </div>
            <div slot="teacherEvaluation" :key="index" slot-scope="text, record, index">
              <template v-if="text === '/'">{{text}}</template>
              <template
                v-else-if="+scoreTypeIds[1] === 0
                ||
                !checkImportTime(scoreTypeTimes[1])"
              >{{text}}</template>
              <template v-else-if="inputValueType === 'S'">
                <wp-number-input
                  class="datainput"
                  type="number"
                  width="80"
                  v-model="record.teacherEvaluation"
                  :max="100"
                  :mimn="0"
                ></wp-number-input>
              </template>
              <template v-else>
                <wp-select
                  width="80px"
                  :data="rankItems"
                  v-model="record.teacherEvaluation"
                >{{record}}</wp-select>
              </template>
            </div>
            <div slot="studentEvaluation" :key="index" slot-scope="text, record, index">
              <template v-if="text === '/'">{{text}}</template>
              <template
                v-else-if="+scoreTypeIds[2] === 0
                ||
                !checkImportTime(scoreTypeTimes[2])"
              >{{text}}</template>
              <template v-else-if="inputValueType === 'S'">
                <wp-number-input
                  class="datainput"
                  type="number"
                  width="80"
                  v-model="record.studentEvaluation"
                  :max="100"
                  :mimn="0"
                ></wp-number-input>
              </template>
              <template v-else>
                <wp-select
                  width="80px"
                  :data="rankItems"
                  v-model="record.studentEvaluation"
                >{{record}}</wp-select>
              </template>
            </div>
            <div slot="tutorEvaluation" :key="index" slot-scope="text, record, index">
              <template v-if="text === '/'">{{text}}</template>
              <template
                v-else-if="+scoreTypeIds[3] === 0
                ||
                !checkImportTime(scoreTypeTimes[3])"
              >{{text}}</template>
              <template v-else-if="inputValueType === 'S'">
                <wp-number-input
                  class="datainput"
                  type="number"
                  width="80"
                  v-model="record.tutorEvaluation"
                  :max="100"
                  :mimn="0"
                ></wp-number-input>
              </template>
              <template v-else>
                <wp-select
                  width="80px"
                  :data="rankItems"
                  v-model="record.tutorEvaluation"
                >{{record}}</wp-select>
              </template>
            </div>
            <div slot="headTeacherEvaluation" :key="index" slot-scope="text, record, index">
              <template v-if="text === '/'">{{text}}</template>
              <template
                v-else-if="+scoreTypeIds[4] === 0
                ||
                !checkImportTime(scoreTypeTimes[4])"
              >{{text}}</template>
              <template v-else-if="inputValueType === 'S'">
                <wp-number-input
                  class="datainput"
                  type="number"
                  width="80"
                  v-model="record.headTeacherEvaluation"
                  :max="100"
                  :mimn="0"
                ></wp-number-input>
              </template>
              <template v-else>
                <wp-select
                  width="80px"
                  :data="rankItems"
                  v-model="record.headTeacherEvaluation"
                >{{record}}</wp-select>
              </template>
            </div>
          </a-table>
        </wp-row>
        <wp-row>
          <wp-button-group>
            <wp-button @click="saveHandler">保存</wp-button>
          </wp-button-group>
        </wp-row>
      </div>
    </transition>
  </div>
</template>

<script>
import {
  formatEvaluationType,
  formatGradeCode,
  formatSemesterName
} from '~/utils/format'
import { chargeObjectEqual } from '~/utils/tools'
import allscoretd from '../../components/allscoretd'

export default {
  name: '',
  scrollToTop: true,
  components: {
    allscoretd
  },
  data() {
    return {
      timeout: null,
      searchKey: '',
      loading: false,
      dataInputList: [
        'selfEvaluation',
        'teacherEvaluation',
        'studentEvaluation',
        'tutorEvaluation',
        'headTeacherEvaluation'
      ],
      columns: [
        {
          title: '一级指标',
          dataIndex: 'diathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.diathesisLength || 0
              }
            }
          }
        },
        {
          title: '二级指标',
          dataIndex: 'secondDiathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.secondDiathesisLength || 0
              }
            }
          }
        },
        {
          title: '三级指标',
          rowKey: 'thirdDiathesisName',
          dataIndex: 'thirdDiathesisName'
        },
        {
          title: '学生自评',
          dataIndex: 'selfEvaluation',
          scopedSlots: { customRender: 'selfEvaluation' },
          width: 100
        },
        {
          title: '家长评价',
          dataIndex: 'teacherEvaluation',
          scopedSlots: { customRender: 'teacherEvaluation' },
          width: 100
          // customRender: record => {
          //   return record === 'null' ? '—' : record
          // }
        },
        {
          title: '学生互评',
          dataIndex: 'studentEvaluation',
          scopedSlots: { customRender: 'studentEvaluation' },
          width: 100

          // customRender: record => {
          //   return record === 'null' ? '—' : record
          // }
        },
        {
          title: '导师评价',
          dataIndex: 'tutorEvaluation',
          scopedSlots: { customRender: 'tutorEvaluation' },
          width: 100

          // customRender: record => {
          //   return record === 'null' ? '—' : record
          // }
        },
        {
          title: '班主任评价',
          dataIndex: 'headTeacherEvaluation',
          scopedSlots: { customRender: 'headTeacherEvaluation' },
          width: 100

          // customRender: record => {
          //   return record === 'null' ? '—' : record
          // }
        },
        {
          title: '总评',
          dataIndex: 'totalScore',
          customRender: (text, row, index) => {
            return {
              attrs: {
                rowSpan: row.diathesisLength || 0
              },
              children: this.$createElement('allscoretd', {
                props: {
                  record: row,
                  inputValueType: this.inputValueType,
                  rankItems: this.rankItems
                },
                on: {
                  editscore: this.editscore
                }
              })
            }
          },
          width: 100
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios, query }) {
    const { gradeCode = '', semester = '' } = query
    let { classList = [] } = await $axios.$get(
      '/diathesis/comprehensive/quality/class/student',
      {
        params: { gradeId: query.gradeId }
      }
    )
    const studentId =
      (classList.length &&
        classList[0].studentList &&
        classList[0].studentList.length &&
        classList[0].studentList[0].studentId) ||
      ''
    let {
      diathesisList = [],
      inputValueType = '',
      rankItems = [],
      scoreTypeIds = [],
      acadyearName = [],
      scoreTypeTimes = []
    } = await $axios.$get('/diathesis/comprehensive/quality/student/detail', {
      params: {
        gradeId: query.gradeId,
        studentId: studentId,
        gradeCode: gradeCode,
        semester: semester
      }
    })
    if (classList.length) {
      classList = Array.from(classList, (item, index) => {
        const obj = Object.create(null)
        obj.classId = item.classId
        obj.className = item.className
        obj.label = item.className
        obj.children = []
        item.studentList &&
          item.studentList.length &&
          item.studentList.forEach(i => {
            obj.children.push({
              label: i.studentName,
              studentId: i.studentId,
              studentName: i.studentName
            })
          })
        return obj
      })
    }
    const arr = []
    if (diathesisList && diathesisList.length) {
      diathesisList.forEach((diathesis, diathesisIndex) => {
        if (diathesis.subList && diathesis.subList.length) {
          diathesis.subList.forEach((secondDiathesis, secondDiathesisIndex) => {
            if (secondDiathesis.subList && secondDiathesis.subList.length) {
              const secondDiathesisLength = secondDiathesis.subList.length
              secondDiathesis.subList.forEach(
                (thirdDiathesis, thirdDiathesisIndex) => {
                  arr.push({
                    diathesisId: diathesis.diathesisId,
                    diathesisName: diathesis.diathesisName,
                    secondDiathesisId: secondDiathesis.diathesisId,
                    secondDiathesisName: secondDiathesis.diathesisName,
                    thirdDiathesisId: thirdDiathesis.diathesisId,
                    thirdDiathesisName: thirdDiathesis.diathesisName,
                    totalScore: diathesis.totalScore, //总评分数
                    totalRemark: diathesis.totalRemark, //总评备注
                    scoreTypeId: scoreTypeIds[diathesisIndex], //分数类型id
                    totalScoreId: diathesis.totalScoreId,
                    showscore: false,
                    selfEvaluation:
                      thirdDiathesis.scoreList[0] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[0],
                    teacherEvaluation:
                      thirdDiathesis.scoreList[1] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[1],
                    studentEvaluation:
                      thirdDiathesis.scoreList[2] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[2],
                    tutorEvaluation:
                      thirdDiathesis.scoreList[3] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[3],
                    headTeacherEvaluation:
                      thirdDiathesis.scoreList[4] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[4],
                    diathesisLength:
                      secondDiathesisIndex === 0 && thirdDiathesisIndex === 0
                        ? diathesis.subList.reduce((pre, cur) => {
                            return pre + cur.subList.length
                          }, 0)
                        : 0,
                    secondDiathesisLength:
                      thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                  })
                }
              )
            } else {
              arr.push()
            }
          })
        }
      })
      diathesisList = arr
    }
    const acadyear = formatGradeCode(gradeCode) + formatSemesterName(semester)
    return {
      studentId,
      classList,
      diathesisList,
      arr,
      inputValueType,
      rankItems,
      scoreTypeIds,
      scoreTypeTimes,
      acadyear,
      acadyearName
    }
  },
  mounted() {},
  methods: {
    // 检测是否在录入时间范围内
    checkImportTime(importTime) {
      if (importTime) {
        let importTimeArr = importTime.split('~')
        let startTime =
          +new Date(importTimeArr[0]) +
          new Date().getTimezoneOffset() * 60 * 1000
        let endTime =
          +new Date(importTimeArr[1]) +
          new Date().getTimezoneOffset() * 60 * 1000 +
          1 * 24 * 60 * 60 * 1000
        let nowTime = +new Date()
        if (nowTime >= startTime && nowTime < endTime) {
          return true
        }
      }
      return false
    },
    formatEvaluationType(evaluation) {
      return formatEvaluationType(evaluation)
    },
    treeSelectHandler(item) {
      if (item.children) return
      this.studentId = item.studentId
      this.getData(item.studentId)
    },
    //下一个
    movedown() {
      let selectshow = false
      for (let i = 0; i < this.classList.length; i++) {
        if (this.classList[i].children) {
          for (let j = 0; j < this.classList[i].children.length; j++) {
            if (
              chargeObjectEqual(
                this.classList[i].children[j],
                this.$refs.classtree.selected
              ) &&
              !selectshow
            ) {
              selectshow = true
            } else if (selectshow) {
              this.$refs.classtree.selected = this.classList[i].children[j]
              return false
            }
          }
        }
      }
    },
    //上一个
    moveup() {
      let selectshow = false
      for (let i = this.classList.length - 1; i > -1; i--) {
        if (this.classList[i].children) {
          for (let j = this.classList[i].children.length - 1; j > -1; j--) {
            if (
              chargeObjectEqual(
                this.classList[i].children[j],
                this.$refs.classtree.selected
              ) &&
              !selectshow
            ) {
              selectshow = true
            } else if (selectshow) {
              this.$refs.classtree.selected = this.classList[i].children[j]
              return
            }
          }
        }
      }
    },
    async saveHandler() {
      const { scoreType } = this.$route.query
      const conTxt = []
      this.diathesisList.forEach(diathesis => {
        const contextList = []
        this.dataInputList.forEach(item => {
          if (
            diathesis[item] &&
            diathesis[item] !== '' &&
            diathesis[item] !== '/'
          ) {
            contextList.push(
              `${diathesis.thirdDiathesisId}_${
                this.scoreTypeIds[this.dataInputList.indexOf(item)]
              }_${this.dataInputList.indexOf(item) + 1}-${diathesis[item]}`
            )
          }
        })
        if (contextList.join('~')) {
          conTxt.push(contextList.join('~'))
        }
      })
      if (!conTxt.length) {
        this.$warn.show({ title: '请先维护数据' })
        return
      }
      const { success, msg } = await this.$axios.$post(
        '/diathesis/comprehensive/quality/student/setScore',
        { studentId: this.studentId, params: conTxt.join('~') }
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    async getData(studentId) {
      this.loading = true
      let {
        diathesisList = [],
        inputValueType = '',
        rankItems = [],
        scoreTypeIds = [],
        acadyearName = [],
        scoreTypeTimes = []
      } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/student/detail',
        {
          params: {
            gradeId: this.$route.query.gradeId,
            studentId: this.studentId,
            gradeCode: this.gradeCode,
            semester: this.semester
          }
        }
      )
      const arr = []
      if (diathesisList && diathesisList.length) {
        diathesisList.forEach((diathesis, diathesisIndex) => {
          if (diathesis.subList && diathesis.subList.length) {
            diathesis.subList.forEach(
              (secondDiathesis, secondDiathesisIndex) => {
                if (secondDiathesis.subList && secondDiathesis.subList.length) {
                  const secondDiathesisLength = secondDiathesis.subList.length
                  secondDiathesis.subList.forEach(
                    (thirdDiathesis, thirdDiathesisIndex) => {
                      arr.push({
                        diathesisId: diathesis.diathesisId,
                        diathesisName: diathesis.diathesisName,
                        secondDiathesisId: secondDiathesis.diathesisId,
                        secondDiathesisName: secondDiathesis.diathesisName,
                        thirdDiathesisId: thirdDiathesis.diathesisId,
                        thirdDiathesisName: thirdDiathesis.diathesisName,
                        totalScore: diathesis.totalScore, //总评分数
                        totalRemark: diathesis.totalRemark, //总评备注
                        scoreTypeId: scoreTypeIds[diathesisIndex], //分数类型id
                        totalScoreId: diathesis.totalScoreId,
                        showscore: false,
                        selfEvaluation:
                          thirdDiathesis.scoreList[0] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[0],
                        teacherEvaluation:
                          thirdDiathesis.scoreList[1] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[1],
                        studentEvaluation:
                          thirdDiathesis.scoreList[2] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[2],
                        tutorEvaluation:
                          thirdDiathesis.scoreList[3] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[3],
                        headTeacherEvaluation:
                          thirdDiathesis.scoreList[4] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[4],
                        diathesisLength:
                          secondDiathesisIndex === 0 &&
                          thirdDiathesisIndex === 0
                            ? diathesis.subList.reduce((pre, cur) => {
                                return pre + cur.subList.length
                              }, 0)
                            : 0,
                        secondDiathesisLength:
                          thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                      })
                    }
                  )
                } else {
                  arr.push()
                }
              }
            )
          }
        })
      }
      this.diathesisList = arr
      this.inputValueType = inputValueType
      this.rankItems = rankItems
      this.scoreTypeIds = scoreTypeIds
      this.acadyearName = acadyearName
      this.scoreTypeTimes = scoreTypeTimes
      this.loading = false
      this.$refs.wrapperright.scrollTop = 0
    },
    //修改总评
    async editscore(record) {
      record.showscore = false
      const { success, msg } = await this.$axios.$post(
        '/diathesis/comprehensive/quality/student/setOverallScore',
        {
          totalScoreId: record.totalScoreId,
          remark: record.totalRemark,
          score: record.totalScore
        }
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    }
  },
  watch: {
    acadyear(newVal) {
      let gradeCodeName = newVal.slice(0, 2)
      let semestername = newVal.slice(2)
      this.gradeCode = formatGradeCode(gradeCodeName)
      this.semester = formatSemesterName(semestername)
      this.getData()
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_left {
  padding-top: 20px;
  padding-left: 10px;
  padding-right: 10px;
}
.content_right {
  width: 70%;
  float: right;
}
.datainput {
  width: 50px;
}
/deep/.wp-select__input {
  background: none;
}
/deep/.wp-tree,
/deep/.wp-tree__body {
  height: calc(100% - 80px);
}
</style>
