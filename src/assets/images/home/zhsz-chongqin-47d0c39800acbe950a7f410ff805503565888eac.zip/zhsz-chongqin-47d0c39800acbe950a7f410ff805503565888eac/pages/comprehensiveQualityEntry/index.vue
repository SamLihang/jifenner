<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <wp-col v-for="record in gradeList" :key="record.gradeId">
        <div class="quality_item">
          <div class="quality_item_title">
            <wp-row>
              <wp-col
                :span="12"
                class="item_title_left"
              >{{record.year}}{{record.gradeName}}{{record.semesterName}}</wp-col>
              <wp-col :span="12" align="right">
                <wp-mixer>
                  <wp-drop-menu border="bend">
                    <wp-button
                      type="second"
                      background="primary"
                      style="border-top-right-radius: 0;border-bottom-right-radius: 0;"
                      class="import_btn"
                    >
                      导入
                      <wp-icon name="angle-single-down"></wp-icon>
                    </wp-button>
                    <ul slot="content" class="compre_drop_ul">
                      <li
                        class="compre_drop_li"
                        v-for="dropitem in record.scoreList"
                        :key="dropitem.scoreId + dropitem.scoreName"
                        @click="uploadhandler(record.gradeId,dropitem.scoreType)"
                      >{{dropitem.scoreName}}</li>
                    </ul>
                  </wp-drop-menu>
                  <wp-button type="second" v-show="record.showlead" @click="gotoentry(record)">录入评价</wp-button>
                  <wp-button type="second" @click="clickHandler(record)">设置时间</wp-button>
                  <wp-button type="second" @click="checkStatisticsHandler(record)">生成总评</wp-button>
                </wp-mixer>
              </wp-col>
            </wp-row>
          </div>
          <div class="quality_item_body">
            <div
              class="quality_subitem"
              v-for="(item, index) in record.scoreList"
              :key="item.scoreId + index"
            >
              <div class="qua_subitem_tage">
                <div class="qua_sunitem_child">
                  <rings-percentage :percentNum="item.percentage"></rings-percentage>
                </div>
              </div>
              <div class="qua_subitem_title">{{item.scoreName}}</div>
              <div class="qua_subitem_time">限时:{{item.importTime ? item.importTime : '无'}}</div>
            </div>
          </div>
        </div>
      </wp-col>
    </wp-row>
    <wp-alert
      :visible="setTimeAlertShow"
      title="设置时间"
      @close="setTimeAlertShow = false"
      @confirm="setTimeAlertConfirm"
    >
      <wp-row>
        <wp-col :span="5" align="right">年级:</wp-col>
        <wp-col :span="18" :offset="1">
          {{
          temporaryTimeSetting.gradeName
          }}
        </wp-col>
      </wp-row>
      <wp-row v-for="(score, index) in temporaryTimeSetting.scoreList" :key="index">
        <wp-col :span="5" align="right">{{ score.scoreName }}:</wp-col>
        <wp-col :span="18" :offset="1">
          <no-ssr>
            <date-picker
              v-model="score.importTime"
              range
              confirm
              confirm-text="确认"
              style="width:100%"
            />
          </no-ssr>
        </wp-col>
      </wp-row>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
import ringsPercentage from '../../components/ringsPercentage'

// 检测是否在录入时间范围内
function checkImportTime(importTime) {
  if (importTime) {
    let importTimeArr = importTime.split('~')
    let startTime =
      +new Date(importTimeArr[0]) + new Date().getTimezoneOffset() * 60 * 1000
    let endTime =
      +new Date(importTimeArr[1]) +
      new Date().getTimezoneOffset() * 60 * 1000 +
      1 * 24 * 60 * 60 * 1000
    let nowTime = +new Date()
    if (nowTime >= startTime && nowTime < endTime) {
      return true
    }
  }
  return false
}
export default {
  name: '',
  scrollToTop: true,
  components: {
    ringsPercentage
  },
  data() {
    return {
      setTimeAlertShow: false,
      temporaryTimeSetting: {}, // 临时的时间设置
      rolelist: ['学生本人', '学生家长', '学生小组', '导师', '班主任']
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    const { gradeList = [] } = await $axios.$get(
      '/diathesis/comprehensive/quality/gradeList'
    )
    let scoreNum = 0
    gradeList.forEach((grade, index) => {
      scoreNum = grade.scoreList.length
      let showlead = false
      grade.scoreList.forEach((score, i) => {
        if (score.importTime && checkImportTime(score.importTime)) {
          showlead = true
        }
      })
      grade.showlead = showlead
    })
    return { scoreNum, gradeList }
  },
  mounted() {},
  methods: {
    // 检测是否在录入时间范围内
    checkImportTime(importTime) {
      if (importTime) {
        let importTimeArr = importTime.split('~')
        let startTime =
          +new Date(importTimeArr[0]) +
          new Date().getTimezoneOffset() * 60 * 1000
        let endTime =
          +new Date(importTimeArr[1]) +
          new Date().getTimezoneOffset() * 60 * 1000 +
          1 * 24 * 60 * 60 * 1000
        let nowTime = +new Date()
        if (nowTime >= startTime && nowTime < endTime) {
          return true
        }
      }
      return false
    },
    // 是否展示统计
    isShowStatistics(row) {
      let isShow = true
      this.gradeList.some(grade => {
        if (grade.gradeId === row.gradeId) {
          isShow =
            grade.scoreList &&
            // 每条数据的录入结束时间小于现在时间则显示
            grade.scoreList.every(score => {
              return (
                score.importTime &&
                typeof score.importTime === 'string' &&
                +new Date(score.importTime.split('~')[1]) +
                  16 * 60 * 60 * 1000 <
                  +new Date()
              )
            })
          return true
        }
      })
      return isShow
    },
    async checkStatisticsHandler(row) {
      const { success: checkSuccess, msg: checkMsg } = await this.$axios.$get(
        '/diathesis/student/checkStatStudent',
        {
          params: {
            gradeId: row.gradeId,
            gradeCode: row.gradeCode,
            semester: row.semester
          }
        }
      )
      if (!checkSuccess) {
        this.$warn.show({ title: checkMsg })
        return
      } else if (checkMsg === 'old') {
        this.$alert.show({
          title: '统计',
          type: 'warning',
          message: '是否重新统计？',
          description: '重新统计将覆盖之前的统计数据。',
          closeCallBack: () => {
            this.$alert.hide()
          },
          confirmCallBack: () => {
            this.statisticsHandler(row)
            this.$alert.hide()
          }
        })
        return
      } else {
        this.statisticsHandler(row)
      }
    },
    async statisticsHandler(row) {
      const { success, msg } = await this.$axios.$get(
        '/diathesis/student/statStudent',
        {
          params: {
            gradeId: row.gradeId,
            gradeCode: row.gradeCode,
            semester: row.semester
          }
        }
      )
      if (success) {
        this.$warn.show({ title: '统计成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    clickHandler(row) {
      this.gradeList.some(grade => {
        if (grade.gradeId === row.gradeId) {
          let _grade = deepClone(grade)
          _grade.scoreList.forEach(item => {
            item.importTime &&
              (item.importTime = this.parseDate(item.importTime))
          })
          this.temporaryTimeSetting = _grade
          return true
        }
      })
      // console.log(this.temporaryTimeSetting)
      this.setTimeAlertShow = true
    },
    parseDate(time) {
      let timeArr = []
      typeof time === 'string' &&
        time.split('~').forEach(item => {
          timeArr.push(new Date(item))
        })
      return timeArr
    },
    async setTimeAlertConfirm() {
      let timeSetList = []
      this.temporaryTimeSetting.scoreList.forEach((score, index) => {
        if (score.importTime && score.importTime[0] && score.importTime[1]) {
          timeSetList.push(
            `${score.scoreType}:${this.formatDate(
              this.temporaryTimeSetting.scoreList[index].importTime[0]
            )}~${this.formatDate(
              this.temporaryTimeSetting.scoreList[index].importTime[1]
            )}`
          )
        }
      })

      if (timeSetList.length) {
        const { success, msg } = await this.$axios.$post(
          `/diathesis/comprehensive/quality/timeset?gradeId=${
            this.temporaryTimeSetting.gradeId
          }&timeSet=${timeSetList.join(',')}`
        )
        if (success) {
          this.$warn.show({ title: '修改成功' })
          this.getDate()
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
      this.setTimeAlertShow = false
    },
    formatDate(date) {
      let seperator1 = '-'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let currentdate =
        date.getFullYear() + seperator1 + month + seperator1 + strDate
      return currentdate
    },
    async getDate() {
      const { gradeList = [] } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/gradeList'
      )
      let scoreNum
      gradeList.forEach((grade, index) => {
        scoreNum = grade.scoreList.length
        let showlead = false
        grade.scoreList.forEach((score, i) => {
          if (score.importTime && this.checkImportTime(score.importTime)) {
            showlead = true
          }
        })
        this.$set(grade, 'showlead', showlead)
      })
      this.scoreNum = scoreNum
      this.gradeList = gradeList
    },
    //录入评价
    gotoentry(record) {
      this.$router.push({
        path: '/comprehensivequalityentry/entry',
        query: { ...record }
      })
    },
    //导入
    uploadhandler(gradeId, scoreType) {
      this.$router.push({
        path: '/comprehensivequalityentry/upload',
        query: {
          gradeId: gradeId,
          scoreType: scoreType
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.link {
  color: #1890ff;
  cursor: pointer;
}
.placehoder {
  color: #999;
}
.wrapper {
  padding: 0;
  background: initial;
  box-shadow: none;
}
.quality_item {
  background: #ffffff;
  box-shadow: 0 1px 4px 0 #cfd2d4;
  border-radius: 4px;
  padding: 0 20px 17px 20px;
  margin-bottom: 10px;
  .quality_item_title {
    padding: 12px 0;
    border-bottom: 1px solid #e8e8e8;
    .item_title_left {
      font-size: 16px;
      line-height: 32px;
    }
    .import_btn:hover {
      fill: var(--primary-color);
    }
  }
  .quality_item_body {
    padding: 10px;
    .quality_subitem {
      display: inline-block;
      width: 220px;
      text-align: center;
      .qua_subitem_tage {
        width: 130px;
        height: 130px;
        display: inline-block;
        padding: 2px;
        position: relative;
        background: linear-gradient(#ecf4fd, #d4e5fa);
        border-radius: 50%;
        .qua_sunitem_child {
          width: 126px;
          height: 126px;
          background: #fff;
          border-radius: 50%;
          padding: 8px;
        }
      }
      .qua_subitem_title {
        font-size: 16px;
        margin-top: 6px;
      }
      .qua_subitem_time {
        color: #666666;
      }
    }
  }
}
a {
  color: #333;
}
.compre_drop_ul {
  min-width: 108px;
  background: #ffffff;
  .compre_drop_li {
    padding: 0 10px;
    height: 32px;
    line-height: 32px;
    text-align: left;
    cursor: pointer;
  }
  .compre_drop_li:hover {
    background: #e7f3fc;
  }
}
/deep/ .wp-drop-menu {
  font-size: inherit;
}
/deep/ .wp-drop-menu__content {
  font-size: 14px;
}
</style>
