<!--  author:   Date:  -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-tree
        accordion
        :data="treeData"
        open_icon="arrow-line"
        close_icon="arrow-line"
        :default_select="treeData[firstIndex] && treeData[firstIndex].children[secondIndex]"
        @select="treeSelectHandler"
      ></wp-tree>
    </div>
    <nuxt-child
      v-if="transPage"
      :key="1"
      :project-id="projectId"
      :data="childData"
      :firstIndex="firstIndex"
      :secondIndex="secondIndex"
      class="wrapper_right"
    ></nuxt-child>
    <nuxt-child
      v-else
      :key="2"
      :data="childData"
      :project-id="projectId"
      :firstIndex="firstIndex"
      :secondIndex="secondIndex"
      class="wrapper_right"
    ></nuxt-child>
  </div>
</template>

<script>
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      transPage: true
    }
  },
  computed: {},
  async asyncData({ $axios, route, store, query }) {
    const firstIndex = query.firstIndex || '0'
    const secondIndex = query.secondIndex || '0'
    let treeData = (await $axios.$get('/diathesis/getProjectList')) || []
    if (typeof treeData === 'string') {
      treeData = []
    }
    treeData.forEach(element => {
      element.label = element.projectName
      element.children = element.childList
      element.children &&
        element.children.forEach(ele => {
          ele.label = ele.projectName
        })
    })
    let projectId =
      (treeData[firstIndex] &&
        treeData[firstIndex].childList[secondIndex] &&
        treeData[firstIndex].childList[secondIndex].id) ||
      ''
    projectId = query.projectId ? query.projectId : projectId
    if (route.path.toLowerCase() === '/sturealisticrecordentry') {
      let [
        { acadyearList = [], semesterList = [], acadyear = '', semester = '' }
      ] = await Promise.all([$axios.$get('/diathesis/getAcadSemList')])
      const gradeId = ''
      const classId = ''
      const status = '0'
      const {
        recordList = [],
        structureList = [],
        page = {}
      } = await $axios.$get(`/diathesis/getRecordList`, {
        params: {
          projectId,
          acadyear,
          semester,
          gradeId,
          classId,
          status,
          _pageIndex: 1,
          _pageSize: 20
        }
      })
      const childData = {
        recordList,
        structureList,
        acadyear,
        acadyearList,
        semesterList,
        gradeId,
        semester: semester.toString(),
        classId,
        status,
        page
      }
      return {
        projectId,
        treeData,
        childData,
        firstIndex,
        secondIndex
      }
    } else {
      const [
        { acadyearList = [], acadyear = '', semester = '', semesterList = [] },
        {
          recordInfoList = [],
          projectName = '',
          stuName = '',
          stuId = '',
          semester: localSemester = '',
          acadyear: localAcadYear = ''
        }
      ] = await Promise.all([
        $axios.$get('/diathesis/getAcadSemList'),
        $axios.$get(`/diathesis/getRecord`, {
          params: { projectId, id: query.id || '' }
        })
      ])
      const childData = {
        acadyearList,
        acadyear,
        semester: semester.toString(),
        semesterList,
        recordInfoList,
        projectName,
        stuName,
        stuId,
        localSemester,
        localAcadYear
      }
      return { projectId, treeData, childData }
    }
  },
  mounted() {},
  watch: {
    '$route.path': {
      handler: function(newVal) {
        this.getData()
      }
    }
  },
  methods: {
    async getData() {
      if (this.$route.path.toLowerCase() === '/sturealisticrecordentry') {
        const [
          { acadyearList = [], semesterList = [], acadyear = '', semester = '' }
        ] = await Promise.all([this.$axios.$get('/diathesis/getAcadSemList')])
        const gradeId = ''
        const classId = ''
        const status = '0'
        const {
          recordList = [],
          structureList = [],
          page = {}
        } = await this.$axios.$get(`/diathesis/getRecordList`, {
          params: {
            projectId: this.projectId,
            acadyear: acadyear,
            semester: semester,
            gradeId: gradeId,
            classId: classId,
            status: status,
            _pageIndex: 1,
            _pageSize: 20
          }
        })
        const childData = {
          recordList,
          structureList,
          acadyear,
          acadyearList,
          semesterList,
          gradeId,
          semester: semester.toString(),
          classId,
          status,
          page
        }
        this.childData = childData
      } else if (
        this.$route.path.toLowerCase() === '/sturealisticrecordentry/add'
      ) {
        let [
          {
            acadyearList = [],
            acadyear = '',
            semester = '',
            semesterList = []
          },
          {
            recordInfoList = [],
            projectName = '',
            stuName = '',
            stuId = '',
            semester: localSemester = '',
            acadyear: localAcadYear = ''
          }
        ] = await Promise.all([
          this.$axios.$get('/diathesis/getAcadSemList'),
          this.$axios.$get(`/diathesis/getRecord`, {
            params: {
              projectId: this.projectId,
              id: this.$route.query.id || ''
            }
          })
        ])
        const childData = {
          acadyearList,
          acadyear,
          semester: semester.toString(),
          semesterList,
          recordInfoList,
          projectName,
          stuName,
          stuId,
          localSemester,
          localAcadYear
        }
        this.childData = childData
      }
    },
    treeSelectHandler(item) {
      if (item.childList && item.childList.length) return
      if (this.projectId === item.id) return
      for (let i in this.treeData) {
        for (let j in this.treeData[i].children) {
          if (this.treeData[i].children[j].id === item.id) {
            this.firstIndex = i
            this.secondIndex = j
          }
        }
      }
      this.treeData
      this.projectId = item.id
      if (this.$route.path.toLowerCase() !== '/sturealisticrecordentry') {
        this.$router.replace('/sturealisticrecordentry')
        return
      }
      this.getData()
      this.transPage = !this.transPage
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_left {
  padding-top: 10px;
}
.content_right {
  width: 70%;
  float: right;
}
/deep/.wp-tree, /deep/.wp-tree__body{
  height: 100%;
}
</style>
