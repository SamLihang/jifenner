<!--  author:   Date:  -->
<template>
  <div class="wrapper_right">
    <div class="title">
      <h5>{{ isAdd ? '新增' : '编辑' }}</h5>
    </div>
    <wp-row class="sub_titile">
      <wp-col :span="3.33333" align="right">
        <h4>记录内容</h4>
      </wp-col>
    </wp-row>
    <template v-if="isAdd">
      <wp-row>
        <wp-col :span="10">
          <wp-row>
            <wp-col :span="8" align="right">
              <p>学年:</p>
            </wp-col>
            <wp-col :span="14" :offset=".4">
              <wp-select v-model="acadyear" :data="acadyearList" width="100%"></wp-select>
            </wp-col>
          </wp-row>
        </wp-col>
        <wp-col :span="10">
          <wp-row>
            <wp-col :span="8" :offset=".4" align="right">
              <p>学期:</p>
            </wp-col>
            <wp-col :span="14" :offset=".4">
              <wp-select
                v-model="semester"
                :data="semesterList"
                value-key="thisId"
                label-key="mcodeContent"
                width="100%"
              ></wp-select>
            </wp-col>
          </wp-row>
        </wp-col>
      </wp-row>
    </template>
    <wp-row>
      <wp-col :span="10">
        <wp-row>
          <wp-col :span="8" align="right">
            <p>记录类型:</p>
          </wp-col>
          <wp-col :span="10" :offset=".4">
            <p>{{ projectName }}</p>
          </wp-col>
        </wp-row>
      </wp-col>
    </wp-row>
    <template v-if="structure.length">
      <wp-row style="margin-top:0;">
        <wp-col
          v-for="(item, index) in structure"
          :key="item.id"
          :span="item.dataType === '4' ? 20 : 10"
          class="realistitem"
        >
          <wp-row>
            <wp-col :span="item.dataType === '4' ? 4 : 8" align="right">
              <p>
                <i v-if="!!(+item.isMust)">*</i>
                {{ item.title }}:
              </p>
            </wp-col>
            <wp-col
              :span="item.dataType === '4' ? 16 : 14"
              :offset="item.dataType === '4' ? .2 : .4"
            >
              <data-type-input v-model="structure[index]"></data-type-input>
            </wp-col>
          </wp-row>
        </wp-col>
      </wp-row>
    </template>
    <wp-row class="sub_titile">
      <wp-col :span="3.33333" align="right">
        <h4>记录对象</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="3.33333" align="right">
        <p>学生姓名:</p>
      </wp-col>
      <wp-col :span="19" :offset=".2">
        <div v-if="isAdd">
          <wp-tag
            type="hollow"
            color="#333"
            close-color="#666"
            border-color="#d9d9d9"
            background="#fafafa"
            size="large"
            class="stu_tag"
            closeable
            v-for="(stu,index) in personList"
            :key="index"
            @close="closeHandler(index)"
          >{{stu.studentName}}</wp-tag>
          <wp-button class="stu_tag" type="second" @click="addPersonHandler">
            <wp-icon name="add-pure" class="add_icon" fill="#666"></wp-icon>
          </wp-button>
        </div>
        <p v-else>{{ data.stuName }}</p>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="19" :offset="3.5">
        <wp-button-group>
          <wp-button @click="saveHandler" size="large">保存</wp-button>
          <wp-button type="second" @click="cancelHandler" size="large">取消</wp-button>
        </wp-button-group>
      </wp-col>
    </wp-row>
    <wp-alert
      :visible="pickerAlertShow"
      title="选择人员"
      width="600px"
      @close="pickerAlertShow = false"
      @confirm="pickerAlertConfirm"
    >
      <person-picker2
        v-model="personList"
        :data="gradeList"
        v-if="pickerAlertShow"
        :project-id="projectId"
      ></person-picker2>
    </wp-alert>
  </div>
</template>

<script>
import dataTypeInput from '~/components/dataTypeInput.vue'
import { chargeObjectEqual } from '~/utils/tools'
import personPicker2 from '~/components/personPicker2.vue'

export default {
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: {
    personPicker2,
    dataTypeInput
  },
  props: {
    projectId: {
      type: String,
      required: true
    },
    data: {
      type: Object,
      required: true
    },
    firstIndex: {
      type: String
    },
    secondIndex: {
      type: String
    }
  },
  beforeRouteLeave(to, from, next) {
    this.checkSave(next)
  },
  data() {
    return {
      gradeList: [],
      structure: [],
      personList: [],
      acadyear: '',
      semester: '',
      projectName: '',
      acadyearList: [],
      semesterList: [],
      pickerAlertShow: false
    }
  },
  computed: {
    isAdd() {
      return !this.$route.query.id
    }
  },
  watch: {
    data: {
      handler: function(newVal) {
        const {
          acadyear,
          acadyearList,
          projectName,
          semester,
          semesterList,
          recordInfoList
        } = newVal
        this.projectName = projectName
        this.semester = semester
        this.semesterList = semesterList
        this.acadyear = acadyear
        this.acadyearList = acadyearList
        if (recordInfoList && recordInfoList.length) {
          this.structure = Array.from(recordInfoList, item => {
            return {
              id: item.structureId,
              title: item.title,
              dataType: item.dataType,
              contentTxt: item.contentTxt || '',
              optionList: item.optionList,
              resultTxt: item.resultTxt,
              isMust: item.isMust
            }
          })
        }
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {
    // console.log(this.data)
  },
  methods: {
    checkSave(next) {
      next()
      // if (
      //   this.acadyear === this.data.acadyear &&
      //   this.semester === this.data.semester &&
      //   !this.personList.length
      // ) {
      //   next()
      // } else {
      //   this.$alert.show({
      //     type: 'warning',
      //     description: '当前页面数据未保存，需要保存吗？',
      //     closeCallBack: () => {
      //       this.$alert.hide()
      //       if (next) {
      //         next()
      //       }
      //     },
      //     confirmCallBack: async () => {
      //       await this.saveHandler()
      //       this.$alert.hide()
      //       if (next) {
      //         next()
      //       }
      //     }
      //   })
      // }
    },
    async addPersonHandler(record) {
      this.pickerAlertShow = true
      this.gradeList = await this.$axios.$get('/diathesis/getGradeClassList', {
        params: { projectId: this.projectId, type: 1 }
      })
    },
    pickerAlertConfirm(person) {
      this.pickerAlertShow = false
    },
    async saveHandler() {
      const stuId = Array.from(this.personList, person => {
        return person.studentId
      }).join(',')
      const recordInfoList = Array.from(this.structure, item => {
        return {
          structureId: item.id,
          contentTxt: item.contentTxt,
          resultTxt: item.resultTxt
        }
      })
      const { success, msg } = await this.$axios.$post(
        '/diathesis/saveRecord',
        {
          id: this.$route.query.id || '',
          projectId: this.projectId,
          stuId: this.data.stuId || stuId,
          acadyear: this.data.localAcadyear || this.acadyear,
          semester: this.data.localSemester || this.semester,
          recordInfoList: recordInfoList
        }
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
        this.$router.push({
          path: '/realisticrecordentry',
          query: {
            projectId: this.projectId,
            firstIndex: this.$route.query.firstIndex,
            secondIndex: this.$route.query.secondIndex
          }
        })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
      // this.$router.go(-1)
    },
    cancelHandler() {
      this.$router.push({
        path: '/realisticrecordentry',
        query: {
          projectId: this.projectId,
          firstIndex: this.$route.query.firstIndex,
          secondIndex: this.$route.query.secondIndex
        }
      })
    },
    closeHandler(index) {
      this.personList.splice(index, 1)
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_right {
  padding-top: 0;
  .title {
    height: 60px;
    line-height: 60px;
    border-bottom: 1px solid #e8e8e8;
    margin-bottom: 20px;
  }
  .sub_titile {
    margin-top: 40px;
    h4 {
      display: inline-block;
      position: relative;
    }
  }
  p {
    line-height: 32px;
    i {
      color: red;
    }
  }
  .stu_tag {
    margin-right: 20px;
    margin-bottom: 10px;
    &:hover {
      .add_icon {
        fill: var(--primary-color) !important;
      }
    }
  }
}
/deep/ .wp-progress {
  opacity: 0;
}
/deep/ .wp-progress--ready {
  opacity: 1;
}
.realistitem {
  margin-top: 20px;
}
/deep/ .wp-checkbox-group .wp-checkbox {
  margin-bottom: 0;
  vertical-align: -webkit-baseline-middle;
}
</style>
