<!--  author:   Date:  -->
<template>
  <div class>
    <div class="rra_head">
      <wp-button-group>
        <router-link
          :to="{path:'/realisticrecordentry/upload', query: {acadyear, semester, projectId}}"
        >
          <wp-button>导入</wp-button>
        </router-link>
        <wp-button
          type="second"
          @click="$router.push({path: '/realisticrecordentry/add', query: {projectId: projectId, firstIndex: firstIndex, secondIndex: secondIndex}})"
        >新增</wp-button>
        <wp-button type="second" @click="batchDeleteHandler" :disabled="!selectedRowKeys.length">删除</wp-button>
      </wp-button-group>
      <div class="filters">
        <div class="filters_title">
          <span>筛选条件：</span>
        </div>
        <div class="filters_item">
          <span>学年:</span>
          <wp-select v-model="acadyear" :data="data.acadyearList" width="80%"></wp-select>
        </div>
        <div class="filters_item">
          <span>学期:</span>
          <wp-select
            v-model="semester"
            :data="data.semesterList"
            value-key="thisId"
            label-key="mcodeContent"
            width="70%"
          ></wp-select>
        </div>
        <div class="filters_item">
          <span>年级:</span>
          <wp-select
            v-model="gradeId"
            :data="data.gradeList"
            value-key="gradeId"
            label-key="gradeName"
            width="70%"
          ></wp-select>
        </div>
        <div class="filters_item">
          <span>班级:</span>
          <wp-select
            v-model="classId"
            :data="classList"
            value-key="classId"
            label-key="className"
            width="70%"
          ></wp-select>
        </div>
        <div class="filters_item">
          <span>状态:</span>
          <wp-select
            v-model="status"
            :data="statusList"
            value-key="value"
            label-key="label"
            width="70%"
          ></wp-select>
        </div>
      </div>
    </div>
    <a-table
      bordered
      :loading="loading"
      class="atable"
      :row-selection="{
        selectedRowKeys: selectedRowKeys,
        onChange: onSelectChange
      }"
      :columns="columns"
      row-key="id"
      :data-source="recordList"
      :locale="{emptyText: '暂无数据'}"
      style="white-space: nowrap"
      :scroll="{x: recordList.length ? '100%' : null}"
      :pagination="total > 10 ? { current: pageIndex, pageSize: pageSize, total: total || 0, showQuickJumper: true, showSizeChanger: true } : false"
      @change="tableChangeHandler"
    >
      <div slot="action" slot-scope="record">
        <a href="javascript:;" @click="editHandler(record)">编辑</a>
        <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
        <wp-popover v-model="record.reset">
          <a href="javascript:;" @click="record.reset = true">删除</a>
          <div slot="content">
            <p>确定要删除吗？</p>
            <wp-button-group style="marginTop: 10px;float: right">
              <wp-button type="words" size="small" @click="record.reset = false">取消</wp-button>
              <wp-button size="small" @click="delHandler(record)">确定</wp-button>
            </wp-button-group>
          </div>
        </wp-popover>
      </div>
      <wp-row slot="expandedRowRender" slot-scope="record" style="margin: 0" wrap>
        <template v-if="Object.keys(record.recordInfoMap).length">
          <template v-for="item in structureList">
            <wp-col :key="item.id" :span="4" min-width="200px">
              <wp-col v-if="!+item.isShow" :span="2" min-width="100px" align="right">
                <p class="record_title" :title="item.title">{{ item.title }}：</p>
              </wp-col>
              <wp-col v-if="!+item.isShow" :key="item.id" :span="2" min-width="100px">
                <template
                  v-if="record.recordInfoMap[item.id] && record.recordInfoMap[item.id][1] === '4'"
                >
                  <a
                    class="record_title"
                    href="javascript:void(0)"
                    :title="record.recordInfoMap[item.id][0]"
                    @click="fileClickHandler(record.recordInfoMap[item.id])"
                  >{{record.recordInfoMap[item.id][0]}}</a>
                </template>
                <template v-else-if="record.recordInfoMap[item.id]">
                  <p
                    class="record_title"
                    :title="record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—' "
                  >{{ record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—' }}</p>
                </template>
              </wp-col>
            </wp-col>
          </template>
        </template>
      </wp-row>
    </a-table>
  </div>
</template>

<script>
import { formatAuditStatus } from '~/utils/format'
import { downloadFile } from '~/utils/tools'
const pageIndex = 1
const pageSize = 10
export default {
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: {},
  props: {
    projectId: {
      type: String,
      required: true
    },
    data: {
      type: Object,
      required: true
    },
    firstIndex: {
      type: String
    },
    secondIndex: {
      type: String
    }
  },
  data() {
    return {
      pageSize,
      pageIndex,
      selectedRowKeys: [],
      classList: [],
      statusList: [
        { value: '0', label: '未审核' },
        { value: '1', label: '已通过' },
        { value: '2', label: '未通过' }
      ],
      recordList: [],
      structureList: [],
      acadyear: '',
      semester: '',
      gradeId: '',
      classId: '',
      status: '',
      loading: false
    }
  },
  computed: {
    columns() {
      const columns = [
        { title: '学生姓名', dataIndex: 'stuName' },
        { title: '班级', dataIndex: 'className' },
        { title: '录入时间', dataIndex: 'creationTime' },
        {
          title: '审核状态',
          dataIndex: 'status',
          customRender: text => {
            return { children: formatAuditStatus(text) }
          }
        },
        {
          title: '操作',
          scopedSlots: { customRender: 'action' }
        }
      ]
      if (this.structureList) {
        this.structureList
          .filter(item => {
            return item.isShow === 1
          })
          .forEach((element, index) => {
            columns.splice(2 + index, 0, {
              title: element.title,
              dataIndex: `recordInfoMap[${element.id}]`,
              customRender: (text, record) => {
                if (!text) {
                  return ''
                }
                if (text[1] === '4') {
                  switch (text[0].split('.')[1]) {
                    case 'png' || 'jpg':
                      return {
                        children: this.$createElement('wpTooltip', [
                          this.$createElement('div', [
                            this.$createElement('div', {
                              class: 'pic_img'
                            }),
                            this.$createElement('a', {
                              domProps: {
                                href: 'javascript:void(0)',
                                innerHTML: text[0]
                              },
                              class: 'file_name',
                              on: {
                                click: () => {
                                  this.fileClickHandler(text)
                                }
                              }
                            })
                          ]),
                          this.$createElement(
                            'div',
                            {
                              slot: 'content'
                            },
                            [
                              this.$createElement('div', {
                                class: 'show_img',
                                style:
                                  'background-image: url(/_nuxt/assets/image/academicRecord/pdf.png)'
                              })
                            ]
                          )
                        ])
                      }
                      break
                    default:
                      let localfilename = ''
                      switch (text[0].split('.')[1]) {
                        case 'xls':
                          localfilename = 'xls'
                          break
                        case 'pdf':
                          localfilename = 'pdf'
                          break
                        case 'ppt':
                          localfilename = 'ppt'
                          break
                        case 'doc':
                          localfilename = 'word'
                          break
                        default:
                          localfilename = 'xls'
                      }
                      return {
                        children: this.$createElement('div', [
                          this.$createElement('div', {
                            class: localfilename + '_img'
                          }),
                          this.$createElement('a', {
                            domProps: {
                              href: 'javascript:void(0)',
                              innerHTML: text[0]
                            },
                            class: 'file_name',
                            on: {
                              click: () => {
                                this.fileClickHandler(text)
                              }
                            }
                          })
                        ])
                      }
                      break
                  }
                } else {
                  return {
                    children: text[0]
                  }
                }
              }
            })
          })
      }
      return columns
    }
  },
  watch: {
    data: {
      handler: function(newVal) {
        const {
          recordList,
          structureList,
          acadyear,
          semester,
          classId,
          gradeId,
          classList,
          status,
          page
        } = newVal
        this.recordList = recordList
        this.structureList = structureList
        this.acadyear = acadyear
        this.gradeId = gradeId
        this.semester = semester
        this.classId = classId
        this.classList = classList
        this.status = status
        this.total = page ? page.maxRowCount : 0
      },
      deep: true,
      immediate: true
    },
    acadyear(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    semester(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    // 年级改变
    gradeId: {
      handler: function(newVal, oldVal) {
        this.data.gradeList.some(grade => {
          if (grade.gradeId === newVal) {
            this.classList = grade.classList
            this.classId = grade.classList[0].classId
            return true
          }
        })
        if (oldVal !== undefined) {
          this.pageIndex = 1
          this.getData()
        }
      },
      immediate: true
    },
    status: function(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    classId: function(newVal) {
      this.pageIndex = 1
      this.getData()
    }
  },
  methods: {
    tableChangeHandler(pagination) {
      this.pageIndex = pagination.current
      this.pageSize = pagination.pageSize
      this.getData()
    },
    async getData() {
      this.loading = true
      const { recordList = [], structureList = [] } = await this.$axios.$get(
        `/diathesis/getRecordList?projectId=${this.projectId}&gradeId=${this.gradeId}&classId=${this.classId}&status=${this.status}&acadyear=${this.acadyear}&semester=${this.semester}&_pageIndex=${this.pageIndex}&_pageSize=${this.pageSize}&type=1`
      )
      this.recordList = recordList
      this.loading = false
    },
    onSelectChange(selectedRowKeys) {
      this.selectedRowKeys = selectedRowKeys
    },
    async delHandler(record) {
      if (!record && !this.selectedRowKeys.length) return
      let ids
      if (record) {
        ids = record.id
        record.reset = false
      } else {
        ids = this.selectedRowKeys.join(',')
      }
      const { success, msg } = await this.$axios.$get(
        `/diathesis/deleteRecord?ids=${ids}`
      )
      if (success) {
        this.$warn.show({ title: '删除成功' })
        this.getData()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    batchDeleteHandler() {
      this.$alert.show({
        type: 'warning',
        title: '信息',
        description: '确认删除吗？',
        closeCallBack: () => {
          this.$alert.hide()
        },
        confirmCallBack: () => {
          this.delHandler()
          this.$alert.hide()
        }
      })
    },
    editHandler(item) {
      this.$router.push({
        path: '/realisticrecordentry/add',
        query: {
          id: item.id,
          projectId: this.projectId,
          firstIndex: this.$route.query.firstIndex,
          secondIndex: this.$route.query.secondIndex
        }
      })
    },
    async fileClickHandler(text) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: '/diathesis/common/downloadFile',
        params: { filePath: text[2] },
        responseType: 'blob'
      })
      downloadFile(text[0], blob)
    }
  }
}
</script>
<style lang="scss" scoped>
.rra_head {
  .filters {
    position: relative;
    margin-top: 20px;
    height: 40px;
    line-height: 40px;
    border: 1px solid #ddd;
    display: table;
    white-space: nowrap;
    width: 100%;
    span {
      font-size: 14px;
    }
    .filters_title {
      width: 10%;
      height: 100%;
      background: #ddd;
      display: table-cell;
      text-align: right;
      margin-right: 10px;
    }
    .filters_item {
      display: table-cell;
      width: 18%;
      border-right: 1px solid #ddd;
      padding-left: 10px;
      &:last-child {
        border-right: none;
      }
    }
    /deep/ .wp-select__content {
      border: none;
      border-radius: 0;
    }
    /deep/ .wp-select.is-active .wp-select__content {
      box-shadow: none;
    }
  }
}
.record_title {
  display: inline-block;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
i {
  color: #e8e8e8;
}
.atable {
  margin-top: 20px;
}
.xls_img {
  width: 20px;
  height: 24px;
  display: inline-block;
  background-image: url(~assets/image/academicRecord/excel.png);
  margin-right: 4px;
  background-size: 100% 100%;
}
.pdf_img {
  width: 20px;
  height: 24px;
  display: inline-block;
  background-image: url(~assets/image/academicRecord/pdf.png);
  margin-right: 4px;
  background-size: 100% 100%;
}
.pic_img {
  width: 20px;
  height: 24px;
  display: inline-block;
  background-image: url(~assets/image/academicRecord/pic.png);
  margin-right: 4px;
  background-size: 100% 100%;
}
.ppt_img {
  width: 20px;
  height: 24px;
  display: inline-block;
  background-image: url(~assets/image/academicRecord/ppt.png);
  margin-right: 4px;
  background-size: 100% 100%;
}
.word_img {
  width: 20px;
  height: 24px;
  display: inline-block;
  background-image: url(~assets/image/academicRecord/word.png);
  margin-right: 4px;
  background-size: 100% 100%;
}
.file_name {
  display: inline-block;
  vertical-align: super;
}
.show_img {
  width: 300px;
  height: 225px;
  background-size: 100% 100%;
}
</style>
