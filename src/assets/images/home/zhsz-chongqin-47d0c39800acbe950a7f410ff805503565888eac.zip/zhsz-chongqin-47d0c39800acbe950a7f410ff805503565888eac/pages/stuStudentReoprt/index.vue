<!--  author:   Date:  -->
<template>
  <div class="wrapper student_body clearfix">
    <div class="student_body_right">
      <div class="student_evaluat_box">
        <div class="evaluat_title">学生自评</div>
        <div class="evaluat_content">
          <wp-textarea width="500px" v-model="contentTxt" :maxheight="200" :height="300"></wp-textarea>
        </div>
        <wp-button size="large" @click="submitHandler" :disabled="!contentTxt">提交</wp-button>
      </div>
      <div class="evaluat_top"></div>
      <div class="evaluat_center">
        <div class="evaluat_center_body"></div>
      </div>
      <div class="evaluat_down"></div>
      <div class="evaluat_back"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',
  components: {},
  data() {
    return {}
  },
  async asyncData({ $axios }) {
    const { id = '', contentTxt = '' } = await $axios.$get(
      '/diathesis/evaluate/findEvaluate?type=0'
    )
    return { id, contentTxt }
  },
  methods: {
    async submitHandler() {
      if (!this.contentTxt) {
        return
      }
      const { success, code, msg } = await this.$axios.$post(
        '/diathesis/evaluate/saveEvaluate',
        {
          id: this.id,
          contentTxt: this.contentTxt
        }
      )
      this.$warn.show({ title: msg })
    }
  },
  computed: {},
  mounted() {}
}
</script>
<style lang='scss' scoped>
.addpointer {
  cursor: pointer;
}
.student_body {
  padding: 0;
  height: 100%;
}
.student_body_right {
  width: 100%;
  height: 100%;
  float: left;
  padding: 20px;
  position: relative;
  text-align: center;
  .evaluat_top {
    background: url('~assets/image/studenteva/backtop.png') center center
      no-repeat;
    height: 230px;
  }
  .evaluat_center {
    width: 100%;
    height: calc(100% - 460px);
    .evaluat_center_body {
      margin: 0 auto;
      width: 580px;
      height: 100%;
      border-left: 20px solid #f2f9ff;
      border-right: 20px solid #f2f9ff;
    }
  }
  .evaluat_down {
    height: 230px;
    background: url('~assets/image/studenteva/backdown.png') center center
      no-repeat;
  }
  .evaluat_back {
    position: absolute;
    width: 100%;
    background: url('~assets/image/studenteva/back1.png') center center
      no-repeat;
    height: 177px;
    bottom: 0;
  }
  .student_evaluat_box {
    position: absolute;
    width: 580px;
    top: 48px;
    left: 50%;
    margin-left: -290px;
    padding: 20px 40px;
    text-align: left;
    height: calc(100% - 138px);
    overflow-y: auto;
    .evaluat_title {
      font-size: 16px;
      color: #333333;
      font-weight: bold;
      padding-bottom: 16px;
    }
    .evaluat_content {
      padding-bottom: 22px;
    }
  }
}
i {
  color: #e8e8e8;
}
</style>