<template>
  <div class="wrapper student_body clearfix">
    <div class="student_body_left">
      <wp-mixer class="student_body_search">
        <wp-input placeholder="请输入" width="108px" maxlength="10" v-model="searchKey"></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999"></wp-icon>
        </wp-button>
      </wp-mixer>
      <wp-tree
        :data="treeData"
        @select="treeSelectHandler"
        open_icon="angle-single-right"
        close_icon="angle-single-right"
        :filter="searchKey"
        class="treeheight"
      ></wp-tree>
    </div>
    <div class="student_body_right" v-if="studentid">
      <div class="student_evaluat_box">
        <div class="evaluat_title">学生自述</div>
        <div class="evaluat_content">{{studentcontent ? studentcontent : '暂无评价'}}</div>
        <div class="evaluat_title">教师评价</div>
        <div class="evaluat_content">
          <wp-textarea width="500px" v-model="teachercontent" :maxheight="200" :height="160"></wp-textarea>
        </div>
        <wp-button size="large" @click="saveeva">提交</wp-button>
      </div>
      <div class="evaluat_top"></div>
      <div class="evaluat_center">
        <div class="evaluat_center_body"></div>
      </div>
      <div class="evaluat_down"></div>
      <div class="evaluat_back"></div>
    </div>
    <div class="no_content" v-else>
      <img src="~/assets/image/studentquery/nocontent.png" />
      <div class="no_content_title">请在左侧选择学生开始评价哟</div>
    </div>
  </div>
</template>

<script>
import { target } from '~/nuxt.config.js'
export default {
  data() {
    return {
      //树结构数组
      treeData: [],
      groupList: [],
      studentcontent: '', //学生评价
      teachercontent: '', //教师评价
      contentid: '',
      studentid: '',
      teacherid: '',
      searchKey: ''
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let treeData = await $axios.$get(
      '/diathesis/mutualGroup/getClassAndStudentTree'
    )
    if (typeof treeData === 'string') {
      treeData = []
    }
    let treeData1 = []
    treeData1 = treeData.filter(item => {
      if (item.classList) {
        let ishave = false
        item.classList.forEach(minitem => {
          ishave = minitem.studentList ? true : false
        })
        return ishave
      } else {
        return false
      }
    })
    treeData1.length &&
      treeData1.forEach(item => {
        item.label = item.gradeName
        item.classList &&
          item.classList.forEach(minitem => {
            minitem.label = minitem.name
            minitem.studentList.forEach(smaitem => {
              smaitem.label = smaitem.name
            })
            minitem.children = minitem.studentList
          })
        item.children = item.classList
      })
    return {
      treeData: treeData1
    }
  },
  mounted() {},
  methods: {
    // 异步加载学生列表
    // loaddata(treeNode) {
    //   return new Promise(async resolve => {
    //     this.seclectClassId = treeNode.id
    //     let childrenlist = await this.$axios.$get(
    //       `/diathesis/mutualGroup/findAllStudentByClassId?classId=${treeNode.id}`
    //     )
    //     treeNode.children = []
    //     childrenlist.forEach((item, index) => {
    //       treeNode.children.push({
    //         id: item.studentId,
    //         label: item.studentName
    //       })
    //     })
    //     this.treeData = [...this.treeData]
    //     resolve()
    //   })
    // },
    //学生选中事件
    async treeSelectHandler(item) {
      this.studentid = item.id
      console.log(item, 1)
      let studentatr = await this.$axios.$get(
        `/diathesis/evaluate/findEvaluate?studentId=${this.studentid}&type=0`
      )
      let teacheratr = await this.$axios.$get(
        `/diathesis/evaluate/findEvaluate?studentId=${this.studentid}&type=1`
      )
      this.studentcontent = studentatr.contentTxt
      this.teachercontent = teacheratr.contentTxt
      this.contentid = teacheratr.id ? teacheratr.id : ''
    },
    //提交
    async saveeva() {
      const { success, msg } = await this.$axios.$post(
        '/diathesis/evaluate/saveEvaluate',
        {
          studentId: this.studentid,
          contentTxt: this.teachercontent,
          id: this.contentid
        }
      )
      if (success) {
        this.$warn.show({
          title: '保存成功'
        })
      } else {
        this.$warn.show({
          title: msg
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.addpointer {
  cursor: pointer;
}
.student_body {
  padding: 0;
  height: 100%;
}
.student_body_left {
  width: 180px;
  height: 100%;
  border-right: 1px solid #cccccc;
  float: left;
  .wp-tree {
    font-size: 16px;
  }
  .student_body_search {
    padding: 10px 20px;
  }
}
.student_body_right {
  width: calc(100% - 180px);
  height: 100%;
  float: left;
  padding: 20px;
  position: relative;
  text-align: center;
  .evaluat_top {
    background: url('~assets/image/studenteva/backtop.png') center center
      no-repeat;
    height: 230px;
  }
  .evaluat_center {
    width: 100%;
    height: calc(100% - 460px);
    .evaluat_center_body {
      margin: 0 auto;
      width: 580px;
      height: 100%;
      border-left: 20px solid #f2f9ff;
      border-right: 20px solid #f2f9ff;
    }
  }
  .evaluat_down {
    height: 230px;
    background: url('~assets/image/studenteva/backdown.png') center center
      no-repeat;
  }
  .evaluat_back {
    position: absolute;
    width: 100%;
    background: url('~assets/image/studenteva/back1.png') center center
      no-repeat;
    height: 177px;
    bottom: 0;
  }
  .student_evaluat_box {
    position: absolute;
    width: 580px;
    top: 48px;
    left: 50%;
    margin-left: -290px;
    padding: 20px 40px;
    text-align: left;
    height: calc(100% - 138px);
    overflow-y: auto;
    .evaluat_title {
      font-size: 16px;
      color: #333333;
      font-weight: bold;
      padding-bottom: 14px;
    }
    .evaluat_content {
      padding-bottom: 22px;
      min-height: 80px;
    }
  }
  .student_evaluat_box::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }

  .student_evaluat_box::-webkit-scrollbar-track {
    background-color: #fff;
  }

  .student_evaluat_box::-webkit-scrollbar-thumb {
    background-color: #ccc;
  }
}
i {
  color: #e8e8e8;
}
.no_content {
  text-align: center;
  width: 100%;
  height: 100%;
  padding-top: 20%;
  .no_content_title {
    font-size: 14px;
    color: #999999;
    margin-top: 15px;
  }
}
.treeheight {
  height: calc(100% - 60px);
}
</style>
