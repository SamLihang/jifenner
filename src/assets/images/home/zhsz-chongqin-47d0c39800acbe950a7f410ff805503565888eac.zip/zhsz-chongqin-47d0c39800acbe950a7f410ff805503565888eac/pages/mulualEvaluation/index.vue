<template>
  <div class="wrapper mulual_body clearfix">
    <div class="mulual_body_left">
      <wp-tree
        :default_select="treeData.length ? treeData[0].children[0] : null"
        :data="treeData"
        @select="changeclass"
        :accordion="true"
        open_icon="angle-single-right"
        close_icon="angle-single-right"
      ></wp-tree>
    </div>
    <div class="mulual_body_right">
      <wp-row>
        <wp-col :span="8">
          <wp-button size="large" type="main" background="primary" @click.native="save()">保存</wp-button>
          <!-- <wp-button size="large" type="second" background="primary" @click.native="save()">导入</wp-button> -->
        </wp-col>
        <wp-col :span="16" align="right">
          <div class="mulual_title">
            <span>
              全班学生：
              <span class="mulual_title_num">{{personList.length}}</span>人
            </span>
            <span>
              已分组：
              <span class="mulual_title_num">{{personList.length - remainpersonList.length}}</span>人
            </span>
            <span>
              未分组：
              <span class="mulual_title_error">{{remainpersonList.length}}</span>人
            </span>
          </div>
        </wp-col>
      </wp-row>
      <div class="mulual_body_table" v-if="groupList.length > 0">
        <a-table :columns="columns" :dataSource="groupList" bordered>
          <template slot="groupName" slot-scope="text, record, index">
            <wp-input
              placeholder="请输入"
              width="200px"
              maxlength="10"
              v-model="groupList[index].groupName"
            ></wp-input>
          </template>
          <template slot="leaderName" slot-scope="text, record, index">
            <wp-tag
              type="hollow"
              class="mulual_label"
              v-show="text"
              border-color="#C1DDF2"
              color="#317EEB"
              background="#E7F3FC"
            >{{text}}</wp-tag>
            <a href="javascript:;" @click="showLeaderModal(record, index)" class="edit_span">
              <wp-icon name="bianji1" font-size="16px" fill="#999999" class="addpointer"></wp-icon>
            </a>
          </template>
          <template slot="studentList" slot-scope="studentList, record, index">
            <wp-tag
              type="hollow"
              v-for="item in studentList"
              :key="item.studentId"
              class="mulual_label"
              border-color="#C1DDF2"
              color="#317EEB"
              background="#E7F3FC"
            >{{item.studentName}}</wp-tag>
            <a href="javascript:;" @click="showPersonModal(record, index)" class="edit_span">
              <wp-icon name="bianji1" font-size="16px" fill="#999999" class="addpointer"></wp-icon>
            </a>
          </template>
          <template slot="operation" slot-scope="id, record, index">
            <wp-popover :value="record.del">
              <a href="javascript:;" @click="showDelete(record)">删除</a>
              <div slot="content">
                <p>确定要删除吗？</p>
                <wp-button-group class="mt20">
                  <wp-button
                    type="second"
                    size="small"
                    background="primary"
                    @click="record.del = false"
                  >取消</wp-button>
                  <wp-button
                    type="main"
                    size="small"
                    background="primary"
                    @click="confirmDelete(record, index)"
                  >确定</wp-button>
                </wp-button-group>
              </div>
            </wp-popover>
          </template>
          <template slot="footer">
            <div class="table_add">
              <wp-button type="words" background="primary" @click="addgroup">+ 新增</wp-button>
            </div>
          </template>
        </a-table>
      </div>
      <div class="nocontent" v-else>
        <img src="~assets/image/subject/nocontent.png" />
        <div class="nocontent_title">暂无数据，点击添加</div>
        <wp-button @click="addgroup">新增</wp-button>
      </div>
    </div>
    <wp-alert
      :visible="leaderModalShow"
      title="选择组长"
      width="600px"
      @close="leaderModalShow = false"
      @confirm="changeleader"
    >
      <leader-picker v-model="leaderSelectId" :data="personList"></leader-picker>
    </wp-alert>
    <wp-alert
      :visible="personModalShow"
      title="选择组员"
      width="600px"
      @close="personModalShow = false"
      @confirm="changeperson"
    >
      <mulual-picker v-model="personSelectList" :data="itempersonList"></mulual-picker>
    </wp-alert>
    <!-- 新增 -->
    <wp-alert
      :visible="addGroupModalShow"
      title="填写组名"
      width="400px"
      @close="addGroupModalShow = false"
      @confirm="addgrouptwo"
      confirmText="下一步"
    >
      <wp-row class="addgroup_body">
        <wp-col :span="3">
          <span>组名：</span>
        </wp-col>
        <wp-col :span="16">
          <wp-input v-model="addgroupname" ref="addname"></wp-input>
        </wp-col>
      </wp-row>
    </wp-alert>
    <wp-alert
      :visible="addleaderModalShow"
      title="选择组长"
      width="600px"
      @close="addleaderModalShow = false"
      @confirm="addleader"
    >
      <leader-picker v-model="leaderSelectId" :data="personList"></leader-picker>
    </wp-alert>
  </div>
</template>

<script>
import mulualPicker from '../../components/mulualPicker.vue'
import leaderPicker from '../../components/leaderPicker.vue'
import { target } from '~/nuxt.config.js'
import { deepClone, deleteIndex, chargeObjectEqual } from '~/utils/tools'
export default {
  components: {
    mulualPicker,
    leaderPicker
  },
  data() {
    return {
      selectindex: 0,
      seclectClassId: '',
      addGroupModalShow: false, //添加分组弹窗
      addleaderModalShow: false, //添加分组的组长弹窗
      addgroupname: '', //添加分组，填写的组名
      leaderModalShow: false, //组长弹窗
      personModalShow: false, //组员弹窗
      personSelectList: [], // 组员选人临时数据
      personList: [], // 班级学员列表
      remainpersonList: [], //被选完后剩下的学员列表
      itempersonList: [], //每个分组可选的学员列表
      leaderSelectId: '', // 组长选人临时数据
      leaderSelectName: '',
      //树结构数组
      treeData: [],
      columns: [
        {
          title: '序号',
          customRender: (text, row, index) => {
            return {
              children: index + 1
            }
          },
          width: '10%'
        },
        {
          title: '组名',
          dataIndex: 'groupName',
          scopedSlots: { customRender: 'groupName' },
          width: '20%'
        },
        {
          title: '人数',
          dataIndex: 'studentNum',
          width: '10%'
        },
        {
          title: '组长',
          dataIndex: 'leaderName',
          scopedSlots: { customRender: 'leaderName' },
          width: '15%'
        },
        {
          title: '组员',
          dataIndex: 'studentList',
          scopedSlots: { customRender: 'studentList' },
          width: '35%'
        },
        {
          title: '操作',
          dataIndex: 'operation',
          scopedSlots: { customRender: 'operation' },
          width: '10%'
        }
      ],
      groupList: [], //当前班级的分班的数据
      basicgroupList: [] //当前班级的分班的数据,用来比较
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let treeData = await $axios.$get('/diathesis/mutualGroup/getClassTree')
    if (typeof treeData === 'string') {
      treeData = []
    }
    let treeData1 = []
    treeData1 = treeData.filter(item => {
      return item.classList ? true : false
    })
    treeData1.length &&
      treeData1.forEach(item => {
        item.label = item.gradeName
        item.classList &&
          item.classList.forEach(minitem => {
            minitem.label = minitem.name
          })
        item.children = item.classList
      })
    return {
      treeData: treeData1,
      seclectClassId: treeData1.length ? treeData1[0].children[0].id : ''
    }
  },
  watch: {
    groupList: {
      handler: function(newVal) {
        let remainpersonList = deepClone(this.personList)
        newVal.length &&
          newVal.forEach((item, index) => {
            item.studentNum = item.studentList.length
            item.del = false
            item.studentList &&
              item.studentList.forEach((minitem, minindex) => {
                remainpersonList.forEach((twoitem, twoindex) => {
                  if (twoitem.studentId === minitem.studentId) {
                    deleteIndex(remainpersonList, twoindex)
                  }
                })
              })
          })
        this.remainpersonList = remainpersonList
      },
      deep: true
    }
  },
  mounted() {
    this.findMutualGroup()
    this.findAllStudentByClassId()
  },
  methods: {
    //获取班级的所有学生
    async findAllStudentByClassId() {
      const seclectClassId = this.seclectClassId
      let personList = await this.$axios.$get(
        `/diathesis/mutualGroup/findAllStudentByClassId?classId=${seclectClassId}`
      )
      this.personList = personList
    },
    //查询班级分班信息
    async findMutualGroup() {
      const seclectClassId = this.seclectClassId
      let groupList = await this.$axios.$get(
        `/diathesis/mutualGroup/findMutualGroup?classId=${seclectClassId}`
      )
      groupList.forEach(item => {
        item.studentList.forEach(minitem => {
          minitem.studentId = minitem.id
          minitem.studentName = minitem.name
        })
      })
      this.groupList = groupList
      this.basicgroupList = deepClone(groupList)
      this.basicgroupList.forEach(items => {
        items.studentNum = items.studentList.length
        items.del = false
      })
    },
    //点击tree,修改班级
    changeclass(item) {
      if (!chargeObjectEqual(this.groupList, this.basicgroupList)) {
        this.$alert.show({
          type: 'warning',
          description: '当前页面数据未保存，需要保存吗？',
          closeCallBack: async () => {
            this.seclectClassId = item.id
            await this.findAllStudentByClassId()
            await this.findMutualGroup()
            this.$alert.hide()
          },
          confirmCallBack: async () => {
            await this.save()
            this.$alert.hide()
            this.seclectClassId = item.id
            await this.findAllStudentByClassId()
            await this.findMutualGroup()
          }
        })
      } else {
        this.seclectClassId = item.id
        this.findAllStudentByClassId()
        this.findMutualGroup()
      }
    },
    //新增分组
    addgroup() {
      this.addgroupname = ''
      this.addGroupModalShow = true
      setTimeout(() => {
        this.$refs.addname.focus()
      }, 0)
    },
    //新增分组下一步
    addgrouptwo() {
      if (!this.addgroupname) {
        this.$warn.show({ title: '组名不能为空' })
        return
      }
      this.leaderSelectId = ''
      this.addGroupModalShow = false
      this.addleaderModalShow = true
    },
    //新增分组函数
    addleader() {
      this.addleaderModalShow = false
      let leaderlist = []
      leaderlist = this.personList.filter(item => {
        return item.studentId === this.leaderSelectId ? true : false
      })
      this.groupList.push({
        groupName: this.addgroupname,
        leaderId: this.leaderSelectId,
        leaderName: leaderlist.length > 0 ? leaderlist[0].studentName : '',
        //sortNum: this.groupList.length > 0 ? this.groupList[this.groupList.length].sortNum + 1 : 1 ,
        studentNum: 0,
        studentList: [],
        del: false
      })
    },
    //显示选择组长弹窗
    showLeaderModal(record, index) {
      this.leaderSelectId = record.leaderId
      this.leaderModalShow = true
      this.selectindex = index
    },
    //修改组长
    changeleader() {
      this.leaderModalShow = false
      let leaderlist = []
      leaderlist = this.personList.filter(item => {
        return item.studentId === this.leaderSelectId ? true : false
      })
      this.groupList[this.selectindex].leaderId = this.leaderSelectId
      if (leaderlist.length) {
        this.groupList[this.selectindex].leaderName = leaderlist[0].studentName
      } else {
        this.groupList[this.selectindex].leaderName = ''
      }
    },
    //显示选择组员弹窗
    showPersonModal(record, index) {
      this.selectindex = index
      this.personSelectList = deepClone(record.studentList)
      this.itempersonList = [
        ...this.personSelectList,
        ...deepClone(this.remainpersonList)
      ]
      this.personModalShow = true
    },
    //修改组员
    changeperson() {
      this.personModalShow = false
      this.groupList[this.selectindex].studentList = this.personSelectList
    },
    //显示删除弹窗
    showDelete(record) {
      record.del = true
    },
    //删除组次
    async confirmDelete(record, index) {
      record.del = false
      this.groupList.splice(index, 1)
    },
    //保存
    async save() {
      let groupList = []
      this.groupList.forEach((item, index) => {
        let studentIds = []
        item.studentList.forEach(items => {
          studentIds.push(items.studentId)
        })
        groupList.push({
          id: item.id,
          mutualGroupName: item.groupName,
          leaderId: item.leaderId,
          //sortNum: item.sortNum,
          studentIds: studentIds
        })
      })
      const {
        data: { success, msg }
      } = await this.$axios.post('/diathesis/mutualGroup/saveGroups', {
        classId: this.seclectClassId,
        groupList: groupList
      })
      if (success) {
        this.$warn.show({ title: '保存成功' })
        this.findMutualGroup()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/.ant-table-footer {
  padding: 0;
  background: #ffffff;
  border-top: 0;
}
/deep/.ant-table.ant-table-bordered .ant-table-footer {
  border: 1px solid #cccccc;
}
.addpointer {
  cursor: pointer;
}
.table_add {
  text-align: center;
  border-top: 0;
}
.mulual_body {
  padding: 0;
  height: 100%;
}
.mulual_body_left {
  width: 180px;
  height: 100%;
  border-right: 1px solid #cccccc;
  float: left;
  .wp-tree {
    font-size: 16px;
  }
}
.mulual_body_right {
  width: calc(100% - 180px);
  height: 100%;
  float: left;
  padding: 20px;
  .mulual_title {
    font-size: 14px;
    color: #666666;
    > span {
      margin-left: 10px;
      display: inline-block;
      font-size: 14px;
      line-height: 36px;
    }
    .mulual_title_num {
      font-size: 16px;
      color: #151515;
      line-height: 36px;
      font-weight: bold;
    }
    .mulual_title_error {
      font-size: 16px;
      color: #f31521;
      line-height: 36px;
      font-weight: bold;
    }
  }
  .mulual_body_table {
    padding-top: 10px;
    .mulual_label {
      margin-right: 10px;
      margin-bottom: 10px;
    }
    .edit_span {
      position: relative;
      top: -3px;
    }
  }
}
.addgroup_body span {
  line-height: 32px;
  font-size: 14px;
}
i {
  color: #e8e8e8;
}
</style>
