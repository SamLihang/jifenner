<!--  author:   Date:  -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-mixer class="student_body_search">
        <wp-input placeholder="请输入" width="108px" maxlength="10" v-model="searchKey"></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999"></wp-icon>
        </wp-button>
      </wp-mixer>
      <!-- <wp-scrollbar style="height: calc(100% - 60px)"> -->
      <wp-tree
        accordion
        height="100%"
        :data="unitList"
        :filter="searchKey"
        open_icon="angle-single-right"
        close_icon="angle-single-right"
        @select="treeSelectHandler"
        class="treeheight"
      ></wp-tree>
      <!-- </wp-scrollbar> -->
    </div>
    <transition name="page">
      <div class="wrapper_right" v-if="unitBaseinfo.unitId">
        <wp-row>
          <wp-col :span="5" align="right">
            <h4 class="title">单位基本信息</h4>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">单位名称:</wp-col>
          <wp-col :span="10" :offset=".2">{{unitBaseinfo.unitName}}</wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">单位性质:</wp-col>
          <wp-col :span="10" :offset=".2">{{unitBaseinfo.unitType}}</wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">行政区划:</wp-col>
          <wp-col :span="10" :offset=".2">{{unitBaseinfo.region}}</wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">负责人（电话）:</wp-col>
          <wp-col :span="10" :offset=".2">{{unitBaseinfo.principal}}</wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">
            <h4 class="title">权限管理</h4>
          </wp-col>
        </wp-row>
        <wp-row v-if="unitBaseinfo.type=== '1'">
          <wp-col :span="5" align="right">允许其对下级单位管控:</wp-col>
          <wp-col :span="10" :offset=".2">
            <wp-switch v-model="manageAuth" v-if="edited"></wp-switch>
            <p v-else>{{manageAuth?'开启': '关闭'}}</p>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">考评设置权限:</wp-col>
          <wp-col :span="10" :offset=".2">
            <wp-switch v-model="settingAuth" v-if="edited"></wp-switch>
            <p v-else>{{settingAuth?'开启': '关闭'}}</p>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">考评标准编辑权限:</wp-col>
          <wp-col :span="10" :offset=".2">
            <template v-if="edited">
              <wp-checkbox v-model="allAuth">所有权限</wp-checkbox>
              <wp-checkbox v-model="subAuth" :disabled="allAuth">允许编辑子项目</wp-checkbox>
              <wp-checkbox v-model="realisticAuth" :disabled="allAuth">允许编辑写实记录</wp-checkbox>
            </template>
            <p v-else-if="allAuth">所有权限</p>
            <p
              v-else-if="subAuth || realisticAuth"
            >{{`${subAuth?'允许编辑子项目': ''} ${realisticAuth?'允许编辑写实记录':''}`}}</p>
            <p v-else>关闭</p>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :offset="5.2" :span="10">
            <wp-button-group v-if="edited">
              <wp-button type="main" size="large" background="primary" @click="saveHandler">保存</wp-button>
              <wp-button type="second" background="rimary" size="large" @click="edited = false">取消</wp-button>
            </wp-button-group>
            <wp-button v-else type="main" size="large" @click="edited = true">修改</wp-button>
          </wp-col>
        </wp-row>
      </div>
    </transition>
  </div>
</template>

<script>
//判断树是否有子集，循环
function circulatesub(arr) {
  arr.forEach((item, index) => {
    item.label = item.name
    if (item.childList) {
      item.children = circulatesub(item.childList)
    }
  })
  return arr
}
export default {
  name: '',
  components: {},
  data() {
    return {
      searchKey: '',
      unitBaseinfo: {
        author: []
      },
      edited: false
    }
  },
  methods: {
    async treeSelectHandler(unit) {
      this.unitBaseinfo = { author: [] }
      // if (unit.parent && !unit.children) {
      //   const unitList = await this.$axios.$get(
      //     '/diathesis/setting/findUnitTree',
      //     { params: { unitId: unit.id } }
      //   )
      //   unitList.forEach(unit => {
      //     unit.label = unit.name
      //   })
      //   unit.children = unitList
      // }
      this.unitBaseinfo = await this.$axios.$get(
        '/diathesis/setting/findUnitInfo',
        { params: { unitId: unit.id } }
      )
      this.unitBaseinfo.type = unit.type
      this.unitBaseinfo.unitId = unit.id
      this.edited = false
    },
    async saveHandler() {
      const { success, msg } = await this.$axios.$post(
        '/diathesis/setting/saveChildUnitAuthor',
        {
          unitId: this.unitBaseinfo.unitId,
          authorList: this.unitBaseinfo.author
        }
      )
      this.edited = false
      this.$warn.show({ title: msg })
    }
  },

  async asyncData({ $axios }) {
    const unitlist = await $axios.$get('/diathesis/unitQuery/findUnitList')
    let treeData = circulatesub(unitlist)
    return { unitList: treeData }
  },
  computed: {
    // 下级单位管控
    manageAuth: {
      get: function() {
        return this.unitBaseinfo.author.includes(1)
      },
      set: function(newValue) {
        if (newValue) {
          this.unitBaseinfo.author = [
            ...new Set([...this.unitBaseinfo.author, 1, 2, 3])
          ]
        } else {
          this.unitBaseinfo.author = this.unitBaseinfo.author.filter(item => {
            return ![1].includes(item)
          })
        }
      }
    },
    // 考评设置权限
    settingAuth: {
      get: function() {
        return this.unitBaseinfo.author.includes(2)
      },
      set: function(newValue) {
        if (newValue) {
          this.unitBaseinfo.author = [
            ...new Set([...this.unitBaseinfo.author, 2])
          ]
        } else {
          this.unitBaseinfo.author = this.unitBaseinfo.author.filter(item => {
            return ![1, 2].includes(item)
          })
        }
      }
    },
    //考评标准编辑权限
    allAuth: {
      get: function() {
        return this.unitBaseinfo.author.includes(3)
      },
      set: function(newValue) {
        if (newValue) {
          this.unitBaseinfo.author = [
            ...new Set([...this.unitBaseinfo.author, 3, 4, 5])
          ]
        } else {
          this.unitBaseinfo.author = this.unitBaseinfo.author.filter(item => {
            return ![1, 3, 4, 5].includes(item)
          })
        }
      }
    },
    // 子项目设置
    subAuth: {
      get: function() {
        return this.unitBaseinfo.author.includes(4)
      },
      set: function(newValue) {
        if (newValue) {
          this.unitBaseinfo.author = [
            ...new Set([...this.unitBaseinfo.author, 4])
          ]
        } else {
          this.unitBaseinfo.author = this.unitBaseinfo.author.filter(item => {
            return ![4].includes(item)
          })
        }
      }
    },
    // 写实记录设置
    realisticAuth: {
      get: function() {
        return this.unitBaseinfo.author.includes(5)
      },
      set: function(newValue) {
        if (newValue) {
          this.unitBaseinfo.author = [
            ...new Set([...this.unitBaseinfo.author, 5])
          ]
        } else {
          this.unitBaseinfo.author = this.unitBaseinfo.author.filter(item => {
            return ![5].includes(item)
          })
        }
      }
    }
  },
  mounted() {}
}
</script>
<style lang='scss' scoped>
.title {
  display: inline-block;
  padding-left: 12px;
  margin-top: 30px;
  font-size: 18px;
  line-height: 18px;
}
.student_body_search {
  padding: 10px 20px;
}
.treeheight {
  height: calc(100% - 60px);
}
</style>