<template>
  <div class="wrapper">
    <div class="role_body">
      <div class="role_title">固定角色</div>
      <div>
        <div class="role_item role_item1"></div>
        <div class="role_item role_item2"></div>
        <div class="role_item role_item3"></div>
        <div class="role_item role_item4"></div>
      </div>
    </div>
    <div class="nocontent" v-if="roleList.length <= 0">
      <img src="~/assets/image/role/nocontent.png" />
      <div class="nocontent_title">除默认角色外，还可以自定义角色哦，试试吧~~~</div>
      <wp-button type="main" background="primary" @click.native="showAddRecord()">新增角色</wp-button>
    </div>
    <div class="role_body" v-if="roleList.length > 0">
      <div class="role_title">自定义角色</div>
      <a-table
        bordered
        :data-source="roleList"
        :columns="columns"
        row-key="roleId"
        :pagination="false"
        :locale="{emptyText: '暂无数据'}"
      >
        <div slot="user" slot-scope="text, record">
          <template
            v-if="record.roleName === '学生本人' || record.roleName === '班主任' || record.roleName === '年级组长'"
          >所属角色人员</template>
          <template v-else>
            <wp-tag
              type="hollow"
              border-color="#C1DDF2"
              color="#317EEB"
              background="#E7F3FC"
              style="margin-right: 10px;"
              v-for="minitem in text"
              :key="minitem.userId"
            >{{minitem.username}}</wp-tag>
          </template>
        </div>
        <div slot="operation" slot-scope="text, record" class="online">
          <template
            v-if="!(record.roleName === '学生本人' || record.roleName === '班主任' || record.roleName === '年级组长')"
          >
            <a href="javascript:void(0);" @click="addPersonHandler(record)">添加人员</a>
            <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
            <wp-popover :value="record.edit">
              <a href="javascript:;" @click="showEdit(record)">编辑名称</a>
              <div slot="content">
                <wp-input
                  v-model="editRoleName"
                  placeholder="请输入"
                  width="100%"
                  maxlength="20"
                  ref="rolename"
                ></wp-input>
                <div class="mt20 text-right">
                  <wp-button-group>
                    <wp-button
                      type="second"
                      size="small"
                      background="primary"
                      @click="cancelEdit(record)"
                    >取消</wp-button>
                    <wp-button
                      type="main"
                      size="small"
                      background="primary"
                      @click="confirmEdit(record)"
                    >确定</wp-button>
                  </wp-button-group>
                </div>
              </div>
            </wp-popover>
            <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
            <wp-popover :value="record.del">
              <a href="javascript:;" @click="showDelete(record)">删除</a>
              <div slot="content">
                <p>确定要删除吗？</p>
                <wp-button-group class="mt20">
                  <wp-button
                    type="second"
                    size="small"
                    background="primary"
                    @click="cancelDelete(record)"
                  >取消</wp-button>
                  <wp-button
                    type="main"
                    size="small"
                    background="primary"
                    @click="confirmDelete(record)"
                  >确定</wp-button>
                </wp-button-group>
              </div>
            </wp-popover>
          </template>
        </div>
      </a-table>
      <div class="role_add_btn">
        <wp-button type="second" background="primary" @click.native="showAddRecord()">+ 新增角色</wp-button>
      </div>
    </div>
    <wp-alert
      :visible="addrecord"
      title="新增"
      @confirm="confirmAddRecord()"
      @close="cancelAddRecord()"
    >
      <wp-row>
        <wp-col :span="5" align="right" class="mt5">角色名称：</wp-col>
        <wp-col :span="19">
          <wp-input v-model="roleName" placeholder="请输入" width="100%" maxlength="20" ref="addname"></wp-input>
        </wp-col>
      </wp-row>
    </wp-alert>
    <wp-alert
      :visible="pickerAlertShow"
      title="选择人员"
      width="600px"
      @close="pickerAlertShow = false"
      @confirm="pickerAlertConfirm"
    >
      <person-picker v-model="personList" :data="deptList" v-if="pickerAlertShow"></person-picker>
    </wp-alert>
  </div>
</template>

<script>
import personPicker from '../../components/personPicker.vue'
import { target } from '~/nuxt.config.js'
import { deleteIndex, deepClone } from '~/utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {
    personPicker
  },
  data() {
    return {
      personList: [], // 选人临时数据
      addrecord: false,
      roleName: '',
      roleId: '',
      deptList: [], // 部门列表
      editRoleName: '',
      pickerAlertShow: false, // 选人弹窗显示
      roleList: [],
      columns: [
        {
          title: '角色名称',
          dataIndex: 'roleName'
        },
        {
          title: '成员',
          dataIndex: 'user',
          scopedSlots: { customRender: 'user' }
        },
        {
          title: '操作',
          scopedSlots: { customRender: 'operation' }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let { data = [] } = await $axios.get('/diathesis/user/getAllRole')
    if (typeof data === 'string') {
      data = []
    }
    data.length &&
      data.forEach((item, index) => {
        item.edit = false
        item.del = false
      })
    return { roleList: data }
  },
  mounted() {},
  methods: {
    formatUser(users) {
      if (!users || !users.length) return '—'
      return Array.from(users, user => {
        return user.username
      }).join('，')
    },
    async getDate() {
      const { data = [] } = await this.$axios.get('/diathesis/user/getAllRole')
      data.length &&
        data.forEach((item, index) => {
          item.edit = false
          item.del = false
        })
      this.roleList = data
    },
    // 添加人员
    async addPersonHandler(record) {
      this.roleId = record.roleId
      this.pickerAlertShow = true
      this.deptList = await this.$axios.$get('/diathesis/user/getDepts')
      if (record.user) {
        this.personList = Array.from(record.user, user => {
          return {
            selected: true,
            userId: user.userId,
            username: user.username
          }
        })
      }
    },
    // 确认选人弹窗
    async pickerAlertConfirm() {
      const userIds = Array.from(this.personList, person => {
        return person.userId
      })
      const { success, msg } = await this.$axios.$post(
        '/diathesis/user/addUsers',
        { roleId: this.roleId, userIds }
      )
      this.pickerAlertShow = false
      if (success) {
        this.$warn.show({ title: '修改成功' })
        this.getDate()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    showAddRecord() {
      this.addrecord = true
      setTimeout(() => {
        this.$refs.addname.focus()
      }, 0)
    },
    async confirmAddRecord() {
      let reg = /^[A-Za-z0-9\u4e00-\u9fa5]{0,20}$/
      if (!reg.test(this.roleName)) {
        this.$warn.show({
          title: '请输入20位以内的由中文、英文或数字组成的角色名'
        })
        this.roleName = ''
        return
      }
      this.addrecord = false
      const {
        data: { success, msg }
      } = await this.$axios.post('/diathesis/user/addRole', {
        roleName: this.roleName
      })
      if (success) {
        this.$warn.show({ title: '添加成功' })
        this.getDate()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
      this.roleName = ''
    },
    cancelAddRecord() {
      this.addrecord = false
      this.roleName = ''
    },
    showEdit(record) {
      record.edit = true
      this.editRoleName = record.roleName
      this.$refs.rolename.focus()
    },
    async confirmEdit(record) {
      let reg = /^[A-Za-z0-9\u4e00-\u9fa5]{0,20}$/
      if (!reg.test(this.editRoleName)) {
        this.$warn.show({
          title: '请输入20位以内的由中文、英文或数字组成的角色名'
        })
        this.editRoleName = record.roleName
        return
      }
      record.edit = false
      const {
        data: { success, msg }
      } = await this.$axios.post('/diathesis/user/editRoleName', {
        roleId: record.roleId,
        roleName: this.editRoleName
      })
      if (success) {
        this.$warn.show({ title: '编辑成功' })
        this.getDate()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    cancelEdit(record) {
      record.edit = false
      this.editRoleName = ''
    },
    showDelete(record) {
      record.del = true
    },
    async confirmDelete(record) {
      record.del = false
      const {
        data: { success, msg }
      } = await this.$axios.get('/diathesis/user/deleteRole', {
        params: {
          roleId: record.roleId
        }
      })
      if (success) {
        this.$warn.show({ title: '删除成功' })
        this.getDate()
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    cancelDelete(record) {
      record.del = false
    }
  }
}
</script>

<style lang="scss" scoped>
.mt5 {
  margin-top: 5px;
}
.mt20 {
  float: right;
  margin-top: 10px;
}
.mb20 {
  margin-bottom: 20px;
}
.text-right {
  text-align: right;
}
.online {
  white-space: nowrap;
  & a:hover {
    text-decoration: underline;
  }
}
i {
  color: #e8e8e8;
}
.role_body {
  padding-bottom: 18px;
  .role_title {
    padding-bottom: 8px;
  }
  .role_item {
    width: 250px;
    height: 100px;
    margin-right: 20px;
    display: inline-block;
  }
  .role_item1 {
    background-image: url(~assets/image/role/student.png);
  }
  .role_item2 {
    background-image: url(~assets/image/role/director.png);
  }
  .role_item3 {
    background-image: url(~assets/image/role/leader.png);
  }
  .role_item4 {
    background-image: url(~assets/image/role/teacher.png);
  }
  .role_add_btn {
    margin-top: 11px;
  }
}
</style>
