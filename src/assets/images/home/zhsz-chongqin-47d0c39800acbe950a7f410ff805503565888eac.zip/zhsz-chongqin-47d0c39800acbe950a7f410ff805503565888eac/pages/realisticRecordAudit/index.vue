<!--  author: Li Hang   Date: 2019-4-1 -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-tree
        accordion
        :data="treeData"
        open_icon="arrow-line"
        close_icon="arrow-line"
        :default_select="treeData[firstIndex] && treeData[firstIndex].children[secondIndex]"
        @select="treeSelectHandler"
      ></wp-tree>
    </div>
    <div class="wrapper_right">
      <wp-tabbar v-model="selected" target="link" :datasource="tabbarData"></wp-tabbar>
      <nuxt-child
        v-if="transPage"
        :firstIndex="firstIndex"
        :secondIndex="secondIndex"
        :key="1"
        :data="childData"
        :project-id="projectId"
      ></nuxt-child>
      <nuxt-child
        v-else
        :key="2"
        :data="childData"
        :firstIndex="firstIndex"
        :secondIndex="secondIndex"
        :project-id="projectId"
      ></nuxt-child>
    </div>
  </div>
</template>

<script>
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      transPage: true,
      selected: this.$route.path,
      tabbarData: [
        { title: '待审核', link: '/realisticrecordaudit' },
        { title: '已审核', link: '/realisticrecordaudit/audited' }
      ]
    }
  },
  async asyncData({ $axios, route, query }) {
    const firstIndex = query.firstIndex || 0
    const secondIndex = query.secondIndex || 0
    let [
      treeData = [],
      { acadyearList = [], semesterList = [], acadyear = '', semester = '' }
    ] = await Promise.all([
      $axios.$get('/diathesis/getProjectList'),
      $axios.$get('/diathesis/getAcadSemList')
    ])
    if (typeof treeData === 'string') {
      treeData = []
    }
    treeData.forEach(element => {
      element.label = element.projectName
      element.children = element.childList
      element.children &&
        element.children.forEach(ele => {
          ele.label = ele.projectName
        })
    })
    const projectId =
      (treeData[0] &&
        treeData[0].childList[0] &&
        treeData[0].childList[0].id) ||
      ''
    const status =
      route.path.toLowerCase() === '/realisticrecordaudit' ? '0' : '1,2'
    let [
      {
        data: { recordList = [], structureList = [] }
      },
      { data: gradeList = [] }
    ] = await Promise.all([
      $axios.get(`/diathesis/getRecordList`, {
        params: {
          projectId,
          acadyear,
          semester,
          gradeId: '',
          classId: '',
          status: status,
          type: 2
        }
      }),
      $axios.get('/diathesis/getGradeClassList', {
        params: { projectId, type: 2 }
      })
    ])
    recordList.forEach(record => {
      record.auditAlert = true
      record.auditNotPassAlert = false
      record.localAuditOpinion = ''
    })
    if (typeof gradeList === 'string') {
      gradeList = []
    }
    gradeList.unshift({ gradeId: '', gradeName: '全部', classList: [] })
    gradeList.forEach(grade => {
      grade.classList &&
        grade.classList.unshift({ classId: '', className: '全部' })
    })
    const childData = {
      status,
      acadyearList,
      semesterList,
      acadyear,
      semester,
      gradeList,
      recordList,
      structureList
    }
    return {
      treeData,
      projectId,
      childData,
      firstIndex,
      secondIndex
    }
  },
  watch: {
    '$route.path'(newVal) {
      this.selected = newVal
      this.getData()
    }
  },
  computed: {},
  async mounted() {},
  methods: {
    treeSelectHandler(item) {
      if (this.projectId === item.id) return
      if (item.childList && item.childList.length) return
      this.transPage = !this.transPage
      this.projectId = item.id
      if (this.$route.path.toLowerCase() !== '/realisticrecordaudit') {
        this.$router.replace('/realisticrecordaudit')
      } else {
        this.getData()
      }
    },
    async getData() {
      const status =
        this.$route.path.toLowerCase() === '/realisticrecordaudit' ? '0' : '1,2'
      const [
        {
          data: { recordList = [], structureList = [] }
        },
        { data: gradeList = [] }
      ] = await Promise.all([
        this.$axios.get(`/diathesis/getRecordList`, {
          params: {
            projectId: this.projectId,
            acadyear: this.childData.acadyear,
            semester: this.childData.semester,
            gradeId: '',
            classId: '',
            status: status,
            type: 2
          }
        }),
        this.$axios.get('/diathesis/getGradeClassList', {
          params: { projectId: this.projectId, type: 2 }
        })
      ])
      recordList.forEach(record => {
        record.auditAlert = true
        record.auditNotPassAlert = false
        record.localAuditOpinion = ''
      })
      this.gradeList = gradeList
      this.childData.status = status
      this.childData.recordList = recordList
      this.childData.structureList = structureList
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_right {
  padding-top: 0;
}
/deep/.wp-tree,
/deep/.wp-tree__body {
  height: 100%;
}
</style>
