<!--  author:   Date:  -->
<template>
  <div>
    <div class="rra_head wp_clearfix">
      <div class="wp_fl">
        <span>年级：</span>
        <wp-select v-model="gradeId" :data="gradeList" value-key="gradeId" label-key="gradeName"></wp-select>
        <span style="margin-left: 20px">班级：</span>
        <wp-select v-model="classId" :data="classList" value-key="classId" label-key="className"></wp-select>
        <span style="margin-left: 20px">状态：</span>
        <wp-select v-model="status" :data="statusList" value-key="value" label-key="label"></wp-select>
      </div>
    </div>
    <a-table
      bordered
      style="white-space: nowrap"
      row-key="id"
      :columns="columns"
      :data-source="recordList"
      :locale="{emptyText: '暂无数据'}"
      :scroll="{x: '100%'}"
      :loading="loading"
      :pagination="false"
    >
      <div slot="status" slot-scope="text">
        <div class="status" :class="{pass: text === '1'}"></div>
        <p style="display: inline-block">{{text === '1' ? '已通过' : '未通过'}}</p>
      </div>
      <div slot="remark" slot-scope="text">{{text}}</div>
      <div slot="action" slot-scope="record">
        <wp-popover :value="record.auditAlert">
          <a
            href="javascript:;"
            @click="record.auditAlert = true"
          >{{record.status === '1' ? '不通过' : '通过'}}</a>
          <div slot="content">
            <template v-if="record.status === '1'">
              <span>请输入审核不通过的原因：</span>
              <wp-textarea v-model="record.localAuditOpinion" :height="60"></wp-textarea>
              <wp-button-group class="mt20">
                <wp-button type="second" background="primary" @click="record.auditAlert = false">取消</wp-button>
                <wp-button
                  type="main"
                  background="primary"
                  @click="aduitHandler(record, false, record.localAuditOpinion)"
                >确定</wp-button>
              </wp-button-group>
            </template>
            <template v-else>
              <p>确定要审核通过吗？</p>
              <wp-button-group class="mt20">
                <wp-button
                  type="second"
                  background="primary"
                  size="small"
                  @click.native="record.auditAlert = false"
                >取消</wp-button>
                <wp-button
                  type="main"
                  size="small"
                  background="primary"
                  @click="aduitHandler(record, true)"
                >确定</wp-button>
              </wp-button-group>
            </template>
          </div>
        </wp-popover>
      </div>
      <wp-row slot="expandedRowRender" slot-scope="record" style="margin: 0" wrap>
        <template v-if="Object.keys(record.recordInfoMap).length">
          <template v-for="item in structureList">
            <wp-col :key="item.id" :span="4" min-width="200px">
              <wp-col v-if="!+item.isShow" :span="2" min-width="100px" align="right">
                <p class="record_title" :title="item.title">{{ item.title }}：</p>
              </wp-col>
              <wp-col v-if="!+item.isShow" :span="2" min-width="100px">
                <template v-if="record.recordInfoMap[item.id][1] === '4'">
                  <a
                    class="record_title"
                    href="javascript:void(0)"
                    :title="record.recordInfoMap[item.id][0]"
                    @click="fileClickHandler(record.recordInfoMap[item.id])"
                  >{{record.recordInfoMap[item.id][0]}}</a>
                </template>
                <template v-else>
                  <p
                    class="record_title"
                    :title="record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—'"
                  >{{ record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—' }}</p>
                </template>
              </wp-col>
            </wp-col>
          </template>
        </template>
      </wp-row>
    </a-table>
  </div>
</template>

<script>
import { downloadFile } from '~/utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      grade: '',
      classes: '',
      status: '',
      gradeId: '',
      classId: '',
      selectedRowKeys: [],
      classList: [],
      loading: false,
      statusList: [
        { value: '1,2', label: '全部' },
        { value: '1', label: '已通过' },
        { value: '2', label: '未通过' }
      ]
    }
  },
  beforeRouteLeave(to, from, next) {
    to.query.firstIndex = this.firstIndex
    to.query.secondIndex = this.secondIndex
    next()
  },
  props: {
    data: {
      type: Object,
      required: true
    },
    projectId: {
      type: String,
      required: true
    },
    firstIndex: {
      type: Number,
      required: true
    },
    secondIndex: {
      type: Number,
      required: true
    }
  },
  watch: {
    data: {
      handler: function(newVal) {
        const {
          status,
          acadyear,
          semester,
          acadyearList,
          semesterList,
          gradeList,
          recordList,
          structureList
        } = newVal
        this.status = status
        this.acadyear = acadyear
        this.semester = semester
        this.acadyearList = acadyearList
        this.semesterList = semesterList
        this.gradeList = gradeList
        this.recordList = recordList
        this.structureList = structureList
      },
      deep: true,
      immediate: true
    },
    gradeId: {
      handler: function(newVal, oldVal) {
        this.gradeList.some(grade => {
          if (grade.gradeId === newVal) {
            this.classList = grade.classList
            this.classId = grade.classList[0].classId
            return true
          }
        })
        if (oldVal === undefined) return // 初始化数据时不重新获取数据
        this.getData()
      },
      immediate: true
    },
    classId: {
      handler: function(newVal) {
        this.getData()
      }
    },
    status: {
      handler: function(newVal) {
        this.getData()
      }
    }
  },
  computed: {
    columns() {
      const columns = [
        { title: '学生姓名', dataIndex: 'stuName' },
        { title: '班级', dataIndex: 'className' },
        { title: '录入时间', dataIndex: 'creationTime' },
        {
          title: '审核状态',
          dataIndex: 'status',
          scopedSlots: { customRender: 'status' }
        },
        {
          title: '备注',
          dataIndex: 'auditOpinion',
          scopedSlots: { customRender: 'remark' }
        },
        { title: '审核时间', dataIndex: 'auditTime' },
        { title: '审核人', dataIndex: 'auditor' },
        {
          title: '操作',
          scopedSlots: { customRender: 'action' }
        }
      ]
      this.structureList
        .filter(item => {
          return item.isShow === 1
        })
        .forEach((element, index) => {
          columns.splice(2 + index, 0, {
            title: element.title,
            dataIndex: `recordInfoMap[${element.id}]`,
            customRender: (text, record) => {
              if (!text) {
                return ''
              }
              if (text[1] === '4') {
                return {
                  children: this.$createElement('a', {
                    domProps: {
                      innerHTML: text[0],
                      href: 'javascript:void(0)'
                    },
                    on: {
                      click: () => {
                        this.fileClickHandler(text)
                      }
                    }
                  })
                }
              } else {
                return {
                  children: text[0]
                }
              }
            }
          })
        })
      return columns
    }
  },
  mounted() {},
  methods: {
    async aduitHandler(records, isPass, auditOpinion = '') {
      const { success, msg } = await this.$axios.$get(
        `/diathesis/updateRecordStatus?ids=${
          records ? records.id : this.selectedRowKeys.join(',')
        }&status=${isPass ? 1 : 2}&auditOpinion=${auditOpinion}`
      )
      records.auditAlert = false
      if (success) {
        this.getData()
        this.$warn.show({ title: '更新成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    async getData() {
      this.loading = true
      const {
        data: { recordList = [], structureList = [] }
      } = await this.$axios.get(`/diathesis/getRecordList`, {
        params: {
          projectId: this.projectId,
          acadyear: this.acadyear,
          semester: this.semester,
          gradeId: this.gradeId,
          classId: this.classId,
          status: this.status,
          type: 2
        }
      })
      structureList
        .filter(item => {
          return item.isShow === '1'
        })
        .forEach((element, index) => {
          columns.splice(3 + index, 0, {
            title: element.title,
            dataIndex: `recordInfoMap[${element.id}]`
          })
        })
      recordList.forEach(record => {
        record.auditAlert = false
        record.auditNotPassAlert = false
        record.localAuditOpinion = ''
      })
      this.loading = false
      this.recordList = recordList
      this.structureList = structureList
    },
    async fileClickHandler(text) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: '/diathesis/common/downloadFile',
        params: { filePath: text[2] },
        responseType: 'blob'
      })
      downloadFile(text[0], blob)
    }
  }
}
</script>
<style lang="scss" scoped>
.mt20 {
  float: right;
  margin-top: 10px;
}
.rra_head {
  padding: 20px 0 20px 20px;
}
.status {
  width: 8px;
  height: 8px;
  display: inline-block;
  border-radius: 50%;
  background: red;

  &.pass {
    background: green;
  }
}
.record_title {
  display: inline-block;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
