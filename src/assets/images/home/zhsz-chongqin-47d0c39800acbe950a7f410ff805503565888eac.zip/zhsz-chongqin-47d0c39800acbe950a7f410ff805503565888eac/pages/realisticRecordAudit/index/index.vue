<!--  author:   Date:  -->
<template>
  <div>
    <div class="rra_head">
      <wp-button-group>
        <wp-button @click="aduitHandler(_, true)" :disabled="!selectedRowKeys.length">审核通过</wp-button>
        <wp-button
          @click="aduitHandler(_, false)"
          :disabled="!selectedRowKeys.length"
          type="second"
        >审核不通过</wp-button>
      </wp-button-group>
      <div class="wp_fr">
        <span style="font-size:14px;">年级：</span>
        <wp-select v-model="gradeId" :data="gradeList" value-key="gradeId" label-key="gradeName"></wp-select>
        <span style="margin-left: 20px;font-size:14px;">班级：</span>
        <wp-select v-model="classId" :data="classList" value-key="classId" label-key="className"></wp-select>
      </div>
    </div>
    <a-table
      style="white-space: nowrap"
      :scroll="{x: '100%'}"
      :row-selection="{
        selectedRowKeys: selectedRowKeys,
        onChange: onSelectChange
      }"
      :columns="columns"
      row-key="id"
      :loading="loading"
      :data-source="recordList"
      :locale="{emptyText: '暂无数据'}"
      :pagination="false"
      bordered
    >
      <div slot="action" slot-scope="record">
        <wp-popover :value="record.auditAlert">
          <a href="javascript:;" @click="record.auditAlert = true">通过</a>
          <div slot="content">
            <p>确定要审核通过吗？</p>
            <wp-button-group class="mt20">
              <wp-button
                type="second"
                background="primary"
                size="small"
                @click.native="record.auditAlert = false"
              >取消</wp-button>
              <wp-button
                type="main"
                size="small"
                background="primary"
                @click="aduitHandler(record, true)"
              >确定</wp-button>
            </wp-button-group>
          </div>
        </wp-popover>
        <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
        <wp-popover :value="record.auditNotPassAlert">
          <a href="javascript:;" @click="record.auditNotPassAlert = true">不通过</a>
          <div slot="content">
            <span>请输入审核不通过的原因：</span>
            <wp-textarea v-model="record.localAuditOpinion" :height="60"></wp-textarea>
            <wp-button-group class="mt20">
              <wp-button
                type="second"
                background="primary"
                size="small"
                @click="record.auditNotPassAlert = false"
              >取消</wp-button>
              <wp-button
                type="main"
                size="small"
                background="primary"
                @click="aduitHandler(record, false, record.localAuditOpinion)"
              >确定</wp-button>
            </wp-button-group>
          </div>
        </wp-popover>
      </div>
      <wp-row slot="expandedRowRender" slot-scope="record" style="margin: 0" wrap>
        <template v-if="Object.keys(record.recordInfoMap).length">
          <template v-for="item in structureList">
            <wp-col :key="item.id" :span="4" min-width="200px">
              <wp-col v-if="!+item.isShow" :key="item.id" :span="2" min-width="100px" align="right">
                <p class="record_title" :title="item.title">{{ item.title }}：</p>
              </wp-col>
              <wp-col v-if="!+item.isShow" :key="item.id" :span="2" min-width="100px">
                <template v-if="record.recordInfoMap[item.id][1] === '4'">
                  <a
                    class="record_title"
                    href="javascript:void(0)"
                    :title="record.recordInfoMap[item.id][0]"
                    @click="fileClickHandler(record.recordInfoMap[item.id])"
                  >{{record.recordInfoMap[item.id][0]}}</a>
                </template>
                <template v-else>
                  <p
                    class="record_title"
                    :title=" record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—' "
                  >{{ record.recordInfoMap[item.id] ? record.recordInfoMap[item.id][0]:'—' }}</p>
                </template>
              </wp-col>
            </wp-col>
          </template>
        </template>
      </wp-row>
    </a-table>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { downloadFile } from '~/utils/tools'

export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      gradeId: '',
      classId: '',
      selectedRowKeys: [],
      classList: [],
      gradeList: [],
      recordList: [],
      structureList: [],
      loading: false
    }
  },
  beforeRouteLeave(to, from, next) {
    to.query.firstIndex = this.firstIndex
    to.query.secondIndex = this.secondIndex
    next()
  },
  props: {
    data: {
      type: Object,
      required: true
    },
    projectId: {
      type: String,
      required: true
    },
    firstIndex: {
      type: Number,
      required: true
    },
    secondIndex: {
      type: Number,
      required: true
    }
  },
  computed: {
    columns() {
      const columns = [
        { title: '学生姓名', dataIndex: 'stuName' },
        { title: '班级', dataIndex: 'className' },
        { title: '录入时间', dataIndex: 'creationTime' },
        { title: '录入人', dataIndex: 'operator' },
        {
          title: '操作',
          scopedSlots: { customRender: 'action' }
        }
      ]
      this.structureList
        .filter(item => {
          return item.isShow === 1
        })
        .forEach((element, index) => {
          columns.splice(2 + index, 0, {
            title: element.title,
            dataIndex: `recordInfoMap[${element.id}]`,
            customRender: (text, record) => {
              if (!text) {
                return ''
              }
              if (text[1] === '4') {
                return {
                  children: this.$createElement('a', {
                    domProps: {
                      innerHTML: text[0],
                      href: 'javascript:void(0)'
                    },
                    on: {
                      click: () => {
                        this.fileClickHandler(text)
                      }
                    }
                  })
                }
              } else {
                return {
                  children: text[0]
                }
              }
            }
          })
        })
      return columns
    }
  },
  watch: {
    data: {
      handler: function(newVal) {
        const {
          acadyear,
          semester,
          acadyearList,
          semesterList,
          gradeList,
          recordList,
          structureList
        } = newVal
        this.acadyear = acadyear
        this.semester = semester
        this.acadyearList = acadyearList
        this.semesterList = semesterList
        this.gradeList = gradeList
        this.recordList = recordList
        this.structureList = structureList
      },
      deep: true,
      immediate: true
    },
    gradeId: {
      handler: function(newVal, oldVal) {
        this.gradeList.some(grade => {
          if (grade.gradeId === newVal) {
            this.classList = grade.classList
            this.classId = grade.classList[0].classId
            return true
          }
        })
        if (oldVal === undefined) return // 初始化数据时不重新获取数据
        this.getData()
      },
      immediate: true
    },
    classId: {
      handler: function(newVal) {
        this.getData()
      }
    }
  },
  methods: {
    async aduitHandler(records, isPass, auditOpinion = '') {
      const { success, msg } = await this.$axios.$get(
        '/diathesis/updateRecordStatus',
        {
          params: {
            ids: records ? records.id : this.selectedRowKeys.join(','),
            status: isPass ? 1 : 2,
            auditOpinion
          }
        }
      )
      if (records) {
        records.auditAlert = false
        records.auditNotPassAlert = false
      }
      if (success) {
        this.getData()
        this.$warn.show({ title: '更新成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    async getData() {
      this.loading = true
      const {
        data: { recordList = [], structureList = [] }
      } = await this.$axios.get(`/diathesis/getRecordList`, {
        params: {
          projectId: this.projectId,
          acadyear: this.acadyear,
          semester: this.semester,
          gradeId: this.gradeId,
          classId: this.classId,
          status: 0,
          type: 2
        }
      })
      structureList
        .filter(item => {
          return item.isShow === '1'
        })
        .forEach((element, index) => {
          columns.splice(3 + index, 0, {
            title: element.title,
            dataIndex: `recordInfoMap[${element.id}]`
          })
        })
      recordList.forEach(record => {
        record.auditAlert = false
        record.auditNotPassAlert = false
        record.auditOpinion = ''
      })
      this.recordList = recordList
      this.structureList = structureList
      this.loading = false
    },
    onSelectChange(selectedRowKeys) {
      this.selectedRowKeys = selectedRowKeys
    },
    async fileClickHandler(text) {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: '/diathesis/common/downloadFile',
        params: { filePath: text[2] },
        responseType: 'blob'
      })
      downloadFile(text[0], blob)
    }
  }
}
</script>
<style lang="scss" scoped>
.rra_head {
  padding: 20px 0 20px 0;
  .rra_head_right {
    float: right;
  }
}
.mt20 {
  float: right;
  margin-top: 10px;
}
.record_title {
  display: inline-block;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
