<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <a-table
      bordered
      row-key="index"
      :columns="columns"
      :data-source="dataSource"
      :pagination="false"
      :locale="{emptyText: '暂无数据'}"
    >
      <template slot="rowOperation" slot-scope="text, record">
        <router-link
          v-if="record.importTime && checkImportTime(record.importTime) && record.scoreType=== '1'"
          :to="{
            path: '/stuComprehensivequalityentry/entry',
            query: { ...record }
          }"
        >
          <p class="link">去录入</p>
        </router-link>
        <p v-else class="placehoder">去录入</p>
      </template>
    </a-table>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      setTimeAlertShow: false,
      temporaryTimeSetting: {}, // 临时的时间设置
      columns: [
        {
          title: '级别',
          dataIndex: 'year',
          key: 'year',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '年级',
          dataIndex: 'gradeName',
          key: 'gradeName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '学期',
          dataIndex: 'semesterName',
          key: 'semesterName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: index % this.scoreNum === 0 ? this.scoreNum : 0
              }
            }
          }
        },
        {
          title: '评价类型',
          dataIndex: 'scoreName',
          key: 'scoreName'
        },
        {
          title: '录入时间',
          dataIndex: 'importTime',
          key: 'importTime',
          customRender: (text, row, index) => {
            return {
              children: text || <p class="placehoder">管理员未设置录入时间</p>
            }
          }
        },
        {
          title: '操作',
          scopedSlots: { customRender: 'rowOperation' }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    const { gradeList = [] } = await $axios.$get(
      '/diathesis/comprehensive/quality/gradeList'
    )
    let scoreNum = 0
    const dataSource = []
    gradeList.forEach((grade, index) => {
      scoreNum = grade.scoreList.length
      grade.scoreList.forEach((score, i) => {
        dataSource.push({
          index: `${index}${i}`,
          gradeId: grade.gradeId,
          gradeCode: grade.gradeCode,
          year: grade.year,
          gradeName: grade.gradeName,
          semester: grade.semester,
          scoreName: score.scoreName,
          semesterName: grade.semesterName,
          scoreType: score.scoreType,
          scoreId: score.scoreId,
          importTime: score.importTime
        })
      })
    })
    return { dataSource, scoreNum, gradeList }
  },
  mounted() {},
  methods: {
    // 检测是否在录入时间范围内
    checkImportTime(importTime) {
      if (importTime) {
        let importTimeArr = importTime.split('~')
        let startTime =
          +new Date(importTimeArr[0]) +
          new Date().getTimezoneOffset() * 60 * 1000
        let endTime =
          +new Date(importTimeArr[1]) +
          new Date().getTimezoneOffset() * 60 * 1000 +
          1 * 24 * 60 * 60 * 1000
        let nowTime = +new Date()
        if (nowTime >= startTime && nowTime < endTime) {
          return true
        }
      }
      return false
    }
  }
}
</script>
<style lang="scss" scoped>
.link {
  color: #1890ff;
  cursor: pointer;
}
.placehoder {
  color: #999;
}
</style>
