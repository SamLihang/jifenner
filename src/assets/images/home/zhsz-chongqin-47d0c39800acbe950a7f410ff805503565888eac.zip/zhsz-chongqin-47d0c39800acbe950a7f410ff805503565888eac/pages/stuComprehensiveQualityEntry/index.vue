<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <div class="stucom_center_box">
      <div class="stucom_center">
        <template v-for="(item,index) in dataSource" )>
          <div
            class="stucom_item"
            v-if="item.scoreType === '1' || (item.scoreType === '3' && mutualshow)"
            :key="index"
          >
            <div class="qua_subitem_tage">
              <div class="qua_sunitem_child">
                <rings-percentage :percentNum="item.percentage"></rings-percentage>
              </div>
            </div>
            <div class="stucom_item_title">{{item.scoreName}}</div>
            <div class="stucom_item_time">限时：{{item.importTime ? item.importTime : '管理员未设置录入时间'}}</div>
            <router-link
              :to="{
            path: '/stuComprehensivequalityentry/entry',
            query: { ...item }
          }"
              v-if="checkImportTime(item.importTime) && item.scoreType === '1'"
            >
              <wp-button>去录入</wp-button>
            </router-link>
            <router-link
              :to="{
            path: '/stuComprehensivequalityentry/mutualEvaluation',
            query: { ...item }
          }"
              v-else-if="checkImportTime(item.importTime) && item.scoreType === '3'"
            >
              <wp-button>去录入</wp-button>
            </router-link>
            <wp-button v-else disabled>去录入</wp-button>
          </div>
        </template>
      </div>
    </div>
    <div class="stucom_back"></div>
    <div class="stucom_down"></div>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
import ringsPercentage from '../../components/ringsPercentage'
export default {
  name: '',
  scrollToTop: true,
  components: {
    ringsPercentage
  },
  data() {
    return {
      setTimeAlertShow: false,
      temporaryTimeSetting: {}, // 临时的时间设置
      columns: []
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    const { gradeList = [] } = await $axios.$get(
      '/diathesis/comprehensive/quality/gradeList'
    )
    let studentlist = await $axios.$get(
      '/diathesis/mutualGroup/findMutualStudent'
    )
    let mutualshow = false
    if (studentlist && studentlist.length > 0) {
      mutualshow = true
    }
    let scoreNum = 0
    const dataSource = []
    gradeList.forEach((grade, index) => {
      scoreNum = grade.scoreList.length
      grade.scoreList.forEach((score, i) => {
        dataSource.push({
          index: `${index}${i}`,
          gradeId: grade.gradeId,
          gradeCode: grade.gradeCode,
          year: grade.year,
          gradeName: grade.gradeName,
          semester: grade.semester,
          scoreName: score.scoreName,
          semesterName: grade.semesterName,
          scoreType: score.scoreType,
          scoreId: score.scoreId,
          importTime: score.importTime,
          percentage: score.percentage
        })
      })
    })
    return { dataSource, scoreNum, gradeList, mutualshow }
  },
  mounted() {},
  methods: {
    // 检测是否在录入时间范围内
    checkImportTime(importTime) {
      if (importTime) {
        let importTimeArr = importTime.split('~')
        let startTime =
          +new Date(importTimeArr[0]) +
          new Date().getTimezoneOffset() * 60 * 1000
        let endTime =
          +new Date(importTimeArr[1]) +
          new Date().getTimezoneOffset() * 60 * 1000 +
          1 * 24 * 60 * 60 * 1000
        let nowTime = +new Date()
        if (nowTime >= startTime && nowTime < endTime) {
          return true
        }
      }
      return false
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper {
  text-align: center;
}
.stucom_center_box {
  width: 100%;
  position: absolute;
  z-index: 100;
}
.stucom_center {
  text-align: center;
  padding: 15% 0;
  margin: 0 auto;
  display: inline-block;
  .stucom_item {
    width: 240px;
    height: 300px;
    background: #ffffff;
    border: 1px solid #d4e5fa;
    border-radius: 4px;
    position: relative;
    bottom: 0;
    transition: bottom 0.5s;
    margin: 0 10px;
    float: left;
    padding-top: 30px;
    margin-bottom: 20px;
    .qua_subitem_tage {
      width: 130px;
      height: 130px;
      display: inline-block;
      padding: 2px;
      position: relative;
      background: linear-gradient(#ecf4fd, #d4e5fa);
      border-radius: 50%;
      .qua_sunitem_child {
        width: 126px;
        height: 126px;
        background: #fff;
        border-radius: 50%;
        padding: 8px;
      }
    }
    .stucom_item_title {
      font-size: 16px;
      font-weight: bold;
      margin-top: 12px;
    }
    .stucom_item_time {
      line-height: 20px;
      margin-bottom: 20px;
    }
  }
  .stucom_item:hover {
    box-shadow: 0 0 10px 0 rgba(29, 95, 191, 0.1);
    bottom: 10px;
  }
}
.stucom_down {
  position: absolute;
  width: 100%;
  background: url('~assets/image/studenteva/back1.png') center center no-repeat;
  height: 177px;
  bottom: 0;
  left: 0;
  right: 0;
}
.stucom_back {
  position: absolute;
  width: 100%;
  background: url('~assets/image/studenteva/background.png') center center
    no-repeat;
  height: 312px;
  bottom: 0;
  left: 0;
  right: 0;
}
</style>
