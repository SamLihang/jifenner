<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <wp-button-group>
        <wp-button @click="saveHandler">保存</wp-button>
      </wp-button-group>
      <div class="wp_fr">
        <p style="display: inline-block">学期：</p>
        <wp-select :data="acadyearName" v-model="acadyear"></wp-select>
      </div>
    </wp-row>
    <wp-row>
      <a-table
        bordered
        class="table"
        key="thirdDiathesisId"
        :data-source="diathesisList"
        :columns="columns"
        :locale="{emptyText: '暂无数据'}"
        :pagination="false"
        :loading="loading"
      >
        <template slot="remark" slot-scope="text, record">
          <wp-tooltip v-if="record.remark">
            <a href="javacript:void(0)" style="white-space: nowrap">查看</a>
            <p slot="content" style="max-width: 250px">{{ record.remark }}</p>
          </wp-tooltip>
          <p v-else>—</p>
        </template>
        <div slot="selfEvaluation" slot-scope="text, record">
          <template v-if="text === '/' || +scoreTypeIds[0] === 0">{{text}}</template>
          <template v-else-if="inputValueType === 'S'">
            <wp-number-input
              class="datainput"
              type="number"
              width="80"
              v-model="record.selfEvaluation"
              :max="100"
              :mimn="0"
            ></wp-number-input>
          </template>
          <template v-else>
            <wp-select width="80px" :data="rankItems" v-model="record.selfEvaluation">{{record}}</wp-select>
          </template>
        </div>
      </a-table>
    </wp-row>
  </div>
</template>

<script>
import { formatGradeCode, formatSemesterName } from '~/utils/format'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      timeout: null,
      searchKey: '',
      loading: false,
      dataInputList: ['selfEvaluation'],
      columns: [
        {
          title: '一级指标',
          dataIndex: 'diathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.diathesisLength || 0
              }
            }
          }
        },
        {
          title: '二级指标',
          dataIndex: 'secondDiathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.secondDiathesisLength || 0
              }
            }
          }
        },
        {
          title: '三级指标',
          dataIndex: 'thirdDiathesisName'
        },
        {
          title: '备注',
          dataIndex: 'remark',
          scopedSlots: {
            customRender: 'remark'
          }
        },
        {
          title: '学生自评',
          dataIndex: 'selfEvaluation',
          scopedSlots: { customRender: 'selfEvaluation' }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios, query }) {
    const { gradeCode = '', semester = '' } = query
    const { studentId } = await $axios.$get('/diathesis/student/getStudentInfo')
    let {
      diathesisList = [],
      inputValueType = '',
      rankItems = [],
      scoreTypeIds = [],
      acadyearName = []
    } = await $axios.$get('/diathesis/comprehensive/quality/student/detail', {
      params: {
        gradeId: query.gradeId,
        studentId: studentId,
        gradeCode: gradeCode,
        semester: semester
      }
    })
    const arr = []
    if (diathesisList.length) {
      diathesisList.forEach((diathesis, diathesisIndex) => {
        if (diathesis.subList && diathesis.subList.length) {
          diathesis.subList.forEach((secondDiathesis, secondDiathesisIndex) => {
            if (secondDiathesis.subList && secondDiathesis.subList.length) {
              const secondDiathesisLength = secondDiathesis.subList.length
              secondDiathesis.subList.forEach(
                (thirdDiathesis, thirdDiathesisIndex) => {
                  arr.push({
                    diathesisId: diathesis.diathesisId,
                    diathesisName: diathesis.diathesisName,
                    secondDiathesisId: secondDiathesis.diathesisId,
                    secondDiathesisName: secondDiathesis.diathesisName,
                    thirdDiathesisId: thirdDiathesis.diathesisId,
                    thirdDiathesisName: thirdDiathesis.diathesisName,
                    remark: thirdDiathesis.remark,
                    selfEvaluation:
                      thirdDiathesis.scoreList[0] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[0],
                    teacherEvaluation:
                      thirdDiathesis.scoreList[1] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[1],
                    studentEvaluation:
                      thirdDiathesis.scoreList[2] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[2],
                    tutorEvaluation:
                      thirdDiathesis.scoreList[3] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[3],
                    headTeacherEvaluation:
                      thirdDiathesis.scoreList[4] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[4],
                    diathesisLength:
                      secondDiathesisIndex === 0 && thirdDiathesisIndex === 0
                        ? diathesis.subList.reduce((pre, cur) => {
                            return pre + cur.subList.length
                          }, 0)
                        : 0,
                    secondDiathesisLength:
                      thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                  })
                }
              )
            } else {
              arr.push()
            }
          })
        }
      })
      diathesisList = arr
    }
    const acadyear = formatGradeCode(gradeCode) + formatSemesterName(semester)
    return {
      studentId,
      diathesisList,
      arr,
      inputValueType,
      rankItems,
      scoreTypeIds,
      acadyear,
      acadyearName
    }
  },
  mounted() {},
  methods: {
    async saveHandler() {
      const { scoreType } = this.$route.query
      const conTxt = []
      this.diathesisList.forEach(diathesis => {
        const contextList = []
        this.dataInputList.forEach(item => {
          if (diathesis[item] !== '' && diathesis[item] !== '/') {
            contextList.push(
              `${diathesis.thirdDiathesisId}_${this.scoreTypeIds[0]}_${1}-${
                diathesis[item]
              }`
            )
          }
        })
        if (contextList.join('~')) {
          conTxt.push(contextList.join('~'))
        }
      })
      if (!conTxt.length) {
        this.$warn.show({ title: '请先维护数据' })
        return
      }
      const { success, msg } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/student/setScore',
        { params: { studentId: this.studentId, params: conTxt.join('~') } }
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    async getData(studentId) {
      this.loading = true
      let {
        diathesisList = [],
        inputValueType = '',
        rankItems = [],
        scoreTypeIds = [],
        acadyearName = []
      } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/student/detail',
        {
          params: {
            gradeId: this.$route.query.gradeId,
            studentId: this.studentId,
            gradeCode: this.gradeCode,
            semester: this.semester
          }
        }
      )
      const arr = []
      if (diathesisList && diathesisList.length) {
        diathesisList.forEach((diathesis, diathesisIndex) => {
          if (diathesis.subList.length) {
            diathesis.subList.forEach(
              (secondDiathesis, secondDiathesisIndex) => {
                if (secondDiathesis.subList.length) {
                  const secondDiathesisLength = secondDiathesis.subList.length
                  secondDiathesis.subList.forEach(
                    (thirdDiathesis, thirdDiathesisIndex) => {
                      arr.push({
                        diathesisId: diathesis.diathesisId,
                        diathesisName: diathesis.diathesisName,
                        secondDiathesisId: secondDiathesis.diathesisId,
                        secondDiathesisName: secondDiathesis.diathesisName,
                        thirdDiathesisId: thirdDiathesis.diathesisId,
                        thirdDiathesisName: thirdDiathesis.diathesisName,
                        remark: thirdDiathesis.remark,
                        selfEvaluation:
                          thirdDiathesis.scoreList[0] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[0],
                        teacherEvaluation:
                          thirdDiathesis.scoreList[1] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[1],
                        studentEvaluation:
                          thirdDiathesis.scoreList[2] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[2],
                        tutorEvaluation:
                          thirdDiathesis.scoreList[3] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[3],
                        headTeacherEvaluation:
                          thirdDiathesis.scoreList[4] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[4],
                        diathesisLength:
                          secondDiathesisIndex === 0 &&
                          thirdDiathesisIndex === 0
                            ? diathesis.subList.reduce((pre, cur) => {
                                return pre + cur.subList.length
                              }, 0)
                            : 0,
                        secondDiathesisLength:
                          thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                      })
                    }
                  )
                } else {
                  arr.push()
                }
              }
            )
          }
        })
      }
      this.diathesisList = arr
      this.inputValueType = inputValueType
      this.rankItems = rankItems
      this.scoreTypeIds = scoreTypeIds
      this.acadyearName = acadyearName
      this.loading = false
    }
  },
  watch: {
    acadyear(newVal) {
      let gradeCodeName = newVal.slice(0, 2)
      let semestername = newVal.slice(2)
      this.gradeCode = formatGradeCode(gradeCodeName)
      this.semester = formatSemesterName(semestername)
      this.getData()
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_left {
  padding-top: 20px;
  padding-left: 10px;
  padding-right: 10px;
}
.content_right {
  width: 70%;
  float: right;
}
.datainput {
  width: 50px;
}
/deep/.wp-select__input {
  background: none;
}
</style>
