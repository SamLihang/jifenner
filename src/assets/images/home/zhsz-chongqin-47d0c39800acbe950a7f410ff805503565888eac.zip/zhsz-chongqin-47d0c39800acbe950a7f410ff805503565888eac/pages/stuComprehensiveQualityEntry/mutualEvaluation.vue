<!--  author:   Date:  -->
<template>
  <div class="wrapper_colums" style="background:#fff;">
    <div class="wrapper_left" v-if="studentList.length > 0">
      <wp-tree
        accordion
        :data="studentList"
        open_icon="arrow-line"
        close_icon="arrow-line"
        :default_select="studentList[0]"
        @select="treeSelectHandler"
        ref="studenttree"
        class="treeheight"
      ></wp-tree>
      <wp-button-group style="margin-left:1px;">
        <wp-button type="main" background="primary" style="width:74px;" @click="moveup">上一个</wp-button>
        <wp-button type="main" background="primary" style="width:74px;" @click="movedown">下一个</wp-button>
      </wp-button-group>
    </div>
    <div class="wrapper_right" v-if="studentList.length > 0">
      <wp-row>
        <a-table
          bordered
          class="table"
          key="thirdDiathesisId"
          :data-source="diathesisList"
          :columns="columns"
          :locale="{emptyText: '暂无数据'}"
          :pagination="false"
          :loading="loading"
        >
          <div slot="studentEvaluation" slot-scope="text, record">
            <template v-if="text === '/' || +scoreTypeIds[1] === 0">{{text}}</template>
            <template v-else-if="inputValueType === 'S'">
              <wp-number-input
                class="datainput"
                type="number"
                width="80"
                v-model="record.studentEvaluation"
                :max="100"
                :mimn="0"
              ></wp-number-input>
            </template>
            <template v-else>
              <wp-radio
                v-model="record.studentEvaluation"
                :label="radioitem"
                type="button"
                v-for="radioitem in rankItems"
                :key="radioitem"
              >{{radioitem}}</wp-radio>
            </template>
          </div>
        </a-table>
      </wp-row>
      <wp-row>
        <wp-button @click="saveHandler">保存</wp-button>
      </wp-row>
    </div>
    <div class="nocontent" v-else>
      <img src="~assets/image/subject/nocontent.png" />
      <div class="nocontent_title">暂无数据，等待班主任添加</div>
    </div>
  </div>
</template>

<script>
import { formatGradeCode, formatSemesterName } from '~/utils/format'
import { chargeObjectEqual } from '~/utils/tools'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      timeout: null,
      searchKey: '',
      loading: false,
      dataInputList: ['studentEvaluation'],
      columns: [
        {
          title: '一级指标',
          dataIndex: 'diathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.diathesisLength || 0
              }
            }
          }
        },
        {
          title: '二级指标',
          dataIndex: 'secondDiathesisName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.secondDiathesisLength || 0
              }
            }
          }
        },
        {
          title: '三级指标',
          dataIndex: 'thirdDiathesisName'
        },
        {
          title: '学生互评',
          dataIndex: 'studentEvaluation',
          scopedSlots: { customRender: 'studentEvaluation' },
          width: 200
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios, query }) {
    let studentList = await $axios.$get(
      '/diathesis/mutualGroup/findMutualStudent'
    )
    let studentId = ''
    studentList.length > 0 &&
      studentList.forEach(item => {
        item.id = item.studentId
        item.label = item.studentName
      })
    if (studentList.length > 0) {
      studentId = studentList[0].id
    } else {
      return false
    }

    const { gradeCode = '', semester = '' } = query
    //const { studentId } = await $axios.$get('/diathesis/student/getStudentInfo')
    let {
      diathesisList = [],
      inputValueType = '',
      rankItems = [],
      scoreTypeIds = [],
      acadyearName = []
    } = await $axios.$get('/diathesis/comprehensive/quality/student/detail', {
      params: {
        gradeId: query.gradeId,
        studentId: studentId,
        gradeCode: gradeCode,
        semester: semester
      }
    })
    const arr = []
    console.log(diathesisList)
    if (diathesisList && diathesisList.length) {
      diathesisList.forEach((diathesis, diathesisIndex) => {
        if (diathesis.subList && diathesis.subList.length) {
          diathesis.subList.forEach((secondDiathesis, secondDiathesisIndex) => {
            if (secondDiathesis.subList && secondDiathesis.subList.length) {
              const secondDiathesisLength = secondDiathesis.subList.length
              secondDiathesis.subList.forEach(
                (thirdDiathesis, thirdDiathesisIndex) => {
                  arr.push({
                    diathesisId: diathesis.diathesisId,
                    diathesisName: diathesis.diathesisName,
                    secondDiathesisId: secondDiathesis.diathesisId,
                    secondDiathesisName: secondDiathesis.diathesisName,
                    thirdDiathesisId: thirdDiathesis.diathesisId,
                    thirdDiathesisName: thirdDiathesis.diathesisName,
                    remark: thirdDiathesis.remark,
                    selfEvaluation:
                      thirdDiathesis.scoreList[0] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[0],
                    studentEvaluation:
                      thirdDiathesis.scoreList[1] === 'null'
                        ? ''
                        : thirdDiathesis.scoreList[1],
                    diathesisLength:
                      secondDiathesisIndex === 0 && thirdDiathesisIndex === 0
                        ? diathesis.subList.reduce((pre, cur) => {
                            return pre + cur.subList.length
                          }, 0)
                        : 0,
                    secondDiathesisLength:
                      thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                  })
                }
              )
            } else {
              arr.push()
            }
          })
        }
      })
      diathesisList = arr
    }
    const acadyear = formatGradeCode(gradeCode) + formatSemesterName(semester)
    return {
      studentId,
      diathesisList,
      arr,
      inputValueType,
      rankItems,
      scoreTypeIds,
      acadyear,
      acadyearName,
      studentList
    }
  },
  mounted() {},
  methods: {
    //下一个
    movedown() {
      let selectshow = false
      for (let i = 0; i < this.studentList.length; i++) {
        if (
          chargeObjectEqual(
            this.studentList[i],
            this.$refs.studenttree.selected
          ) &&
          !selectshow
        ) {
          selectshow = true
        } else if (selectshow) {
          this.$refs.studenttree.selected = this.studentList[i]
          return false
        }
      }
    },
    //上一个
    moveup() {
      let selectshow = false
      for (let i = this.studentList.length - 1; i > -1; i--) {
        if (
          chargeObjectEqual(
            this.studentList[i],
            this.$refs.studenttree.selected
          ) &&
          !selectshow
        ) {
          selectshow = true
        } else if (selectshow) {
          this.$refs.studenttree.selected = this.studentList[i]
          return false
        }
      }
    },
    async treeSelectHandler(item) {
      this.studentId = item.id
      this.getData(this.studentId)
    },
    async saveHandler() {
      const { scoreType } = this.$route.query
      const conTxt = []
      this.diathesisList.forEach(diathesis => {
        const contextList = []
        this.dataInputList.forEach(item => {
          if (diathesis[item] !== '' && diathesis[item] !== '/') {
            if (diathesis[item] !== undefined) {
              contextList.push(
                `${diathesis.thirdDiathesisId}_${this.scoreTypeIds[1]}_${3}-${
                  diathesis[item]
                }`
              )
            }
          }
        })
        if (contextList.join('~')) {
          conTxt.push(contextList.join('~'))
        }
      })
      if (!conTxt.length) {
        this.$warn.show({ title: '请先维护数据' })
        return
      }
      const { success, msg } = await this.$axios.$post(
        '/diathesis/comprehensive/quality/student/setScore',
        { studentId: this.studentId, params: conTxt.join('~') }
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    async getData(studentId) {
      this.loading = true
      let {
        diathesisList = [],
        inputValueType = '',
        rankItems = [],
        scoreTypeIds = [],
        acadyearName = []
      } = await this.$axios.$get(
        '/diathesis/comprehensive/quality/student/detail',
        {
          params: {
            gradeId: this.$route.query.gradeId,
            studentId: this.studentId,
            gradeCode: this.gradeCode,
            semester: this.semester
          }
        }
      )
      const arr = []
      if (diathesisList && diathesisList.length) {
        diathesisList.forEach((diathesis, diathesisIndex) => {
          if (diathesis.subList && diathesis.subList.length) {
            diathesis.subList.forEach(
              (secondDiathesis, secondDiathesisIndex) => {
                if (secondDiathesis.subList && secondDiathesis.subList.length) {
                  const secondDiathesisLength = secondDiathesis.subList.length
                  secondDiathesis.subList.forEach(
                    (thirdDiathesis, thirdDiathesisIndex) => {
                      arr.push({
                        diathesisId: diathesis.diathesisId,
                        diathesisName: diathesis.diathesisName,
                        secondDiathesisId: secondDiathesis.diathesisId,
                        secondDiathesisName: secondDiathesis.diathesisName,
                        thirdDiathesisId: thirdDiathesis.diathesisId,
                        thirdDiathesisName: thirdDiathesis.diathesisName,
                        remark: thirdDiathesis.remark,
                        selfEvaluation:
                          thirdDiathesis.scoreList[0] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[0],
                        studentEvaluation:
                          thirdDiathesis.scoreList[1] === 'null'
                            ? ''
                            : thirdDiathesis.scoreList[1],
                        diathesisLength:
                          secondDiathesisIndex === 0 &&
                          thirdDiathesisIndex === 0
                            ? diathesis.subList.reduce((pre, cur) => {
                                return pre + cur.subList.length
                              }, 0)
                            : 0,
                        secondDiathesisLength:
                          thirdDiathesisIndex === 0 ? secondDiathesisLength : 0
                      })
                    }
                  )
                } else {
                  arr.push()
                }
              }
            )
          }
        })
      }
      this.diathesisList = arr
      this.inputValueType = inputValueType
      this.rankItems = rankItems
      this.scoreTypeIds = scoreTypeIds
      this.acadyearName = acadyearName
      this.loading = false
    }
  },
  watch: {
    acadyear(newVal) {
      let gradeCodeName = newVal.slice(0, 2)
      let semestername = newVal.slice(2)
      this.gradeCode = formatGradeCode(gradeCodeName)
      this.semester = formatSemesterName(semestername)
      this.getData()
    }
  }
}
</script>
<style lang='scss' scoped>
/deep/.wp-radio--button {
  padding: 6px 11px;
}
.treeheight {
  height: calc(100% - 70px);
  margin-bottom: 10px;
}
/deep/ .wp-radio--button {
  width: 32px;
  height: 32px;
  padding: 0;
  text-align: center;
}
/deep/ .wp-radio__text {
  line-height: 30px;
}
/deep/ .wp-radio + .wp-radio {
  margin-left: 10px;
}
</style>