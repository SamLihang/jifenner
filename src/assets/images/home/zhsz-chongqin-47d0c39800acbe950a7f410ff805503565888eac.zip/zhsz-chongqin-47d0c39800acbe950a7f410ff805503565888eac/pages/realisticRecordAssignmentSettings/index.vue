<template>
  <div class="realistic_record_setting">
    <wp-button type="main" background="primary" @click="saveHandler">保存</wp-button>
    <a-table :columns="columns" row-key="id" :dataSource="dataSource" bordered :pagination="false">
      <template slot="accordingTo" slot-scope="record">
        <wp-radio v-model="record.scoreType" label="0">按项目</wp-radio>
        <wp-radio
          v-if="record.structureList && record.structureList.length>0"
          v-model="record.scoreType"
          label="1"
        >按级别</wp-radio>
        <wp-select
          style="marginLeft: 20px;"
          v-if="record.scoreType == 1"
          width="100px"
          v-model="record.scoreStructureId"
          :data="record.structureList"
          value-key="id"
          label-key="title"
        ></wp-select>
      </template>
      <template slot="scorePer" slot-scope="record">
        <div v-if="record.scoreType == 1">
          <div v-for="(optionItem, index) in record.structureList" :key="index">
            <template v-if="optionItem.id == record.scoreStructureId">
              <div class="leveloption" v-for="(item, idx) in optionItem.option" :key="idx">
                <span>{{item.contentTxt}}:</span>
                <a-input-number v-model="item.score" :max="100" :min="0"></a-input-number>
              </div>
            </template>
          </div>
        </div>
        <a-input-number v-else v-model="record.score" :max="100" :min="0"></a-input-number>
      </template>
      <template slot="semester" slot-scope="record">
        <wp-input width="100px" maxlength="10" v-model="record.semesterMax"></wp-input>
      </template>
      <template slot="all" slot-scope="record">
        <wp-input width="100px" maxlength="10" v-model="record.allMax"></wp-input>
      </template>
    </a-table>
  </div>
</template>
<script>
import { deepClone, chargeObjectEqual } from '../../utils/tools'
export default {
  name: '',
  data() {
    return {
      columns: [
        {
          title: '类别',
          dataIndex: 'projectType',
          width: '10%',
          align: 'center',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.index == 0 ? row.scoreNum : 0
              }
            }
          }
        },
        {
          title: '项目名称',
          dataIndex: 'projectName',
          width: '15%'
        },
        {
          title: '赋分依据',
          width: '25%',
          scopedSlots: { customRender: 'accordingTo' }
        },
        {
          title: '分值/次',
          width: '30%',
          scopedSlots: { customRender: 'scorePer' }
        },
        {
          title: '满分/学期',
          width: '10%',
          scopedSlots: { customRender: 'semester' }
        },
        {
          title: '在校得分上限',
          width: '10%',
          scopedSlots: { customRender: 'all' }
        }
      ],
      realisticRecordData: {
        childList: []
      }
    }
  },
  async asyncData({ $axios }) {
    const recordProject = await $axios.$get(
      '/diathesis/project/getRecordProject'
    )
    if (typeof recordProject === 'string') {
      recordProject = []
    }
    const dataSource = []
    recordProject.forEach((project, index) => {
      project.childList.forEach((item, idx) => {
        dataSource.push({
          index: `${idx}`,
          id: item.id,
          scoreNum: project.childList.length,
          projectType: project.projectName,
          projectName: item.projectName,
          scoreType: item.scoreType,
          structureList: item.structureList,
          scoreStructureId: item.scoreStructureId,
          score: item.score,
          semesterMax: item.semesterMax,
          allMax: item.allMax
        })
      })
    })
    return {
      recordProject,
      dataSource
    }
  },
  watch: {
    dataSource: {
      handler: function(newVal) {
        this.dataSource = newVal
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    formatData() {
      let data = []
      this.dataSource.forEach((item, index) => {
        if (item.structureList && item.structureList.length > 0) {
          item.structureList.forEach((optionItem, idx) => {
            if (item.scoreStructureId == optionItem.id) {
              item.optionList = optionItem.option
            }
          })
        }
        data.push({
          id: item.id,
          score: item.score,
          semesterMax: item.semesterMax,
          allMax: item.allMax,
          scoreType: item.scoreType,
          scoreStructureId: item.scoreStructureId,
          optionList: item.optionList
        })
      })
      this.realisticRecordData.childList = data
    },
    async saveHandler() {
      this.formatData()
      const { msg, success } = await this.$axios.$post(
        '/diathesis/project/saveRecordScoreSetting',
        this.realisticRecordData
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    }
  }
}
</script>
<style lang='scss'>
.realistic_record_setting {
  position: relative;
  width: 100%;
  min-height: 100%;
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 1px 3px rgba(207, 210, 212, 0.6);
  .ant-table {
    line-height: 3;
    margin-top: 20px;
    .leveloption {
      display: inline-block;
      width: 200px;
      & > span {
        display: inline-block;
        width: 30px;
        text-align: center;
      }
    }
  }
}
</style>


