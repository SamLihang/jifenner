<template>
  <div class="elvaluation_standard">
    <wp-button type="main" background="primary" @click="handleMaskShow">考评标准设置</wp-button>
    <wp-button type="second" background="primary" @click="enterRealisticRecord">写实记录赋分设置</wp-button>
    <ul class="projectlist">
      <li
        class="liItem"
        v-for="project in projectList"
        :key="project.id"
        @click="enterProjectsetting(project.id)"
      >
        <div class="top">{{project.name}}</div>
        <div class="bottom">
          <span>
            <p>{{project.childProjectCount}}</p>
            <p>考评项目</p>
          </span>
          <span>
            <p>{{project.childRecordCount}}</p>
            <p>写实记录</p>
          </span>
        </div>
      </li>
    </ul>
    <wp-alert
      width="500px"
      class="first_project_setting"
      :visible="category_alert_show"
      title="考评标准设置"
      @close="category_alert_show = false"
      @confirm="alertConfirm"
    >
      <sort-table :columns="['类目名称', '排序', '操作']" :data-source="alertData"></sort-table>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
import sortTable from '../../components/sortTable'
export default {
  name: '',
  components: {
    sortTable
  },
  data() {
    return {
      category_alert_show: false,
      alertData: [],
      newProjectName: '',
      addStatus: true
    }
  },
  async asyncData({ $axios, store, route, query }) {
    let projectList =
      (await $axios.$get('/diathesis/project/findProjectDetial')) || []
    if (typeof projectList === 'string') {
      projectList = []
    }
    return {
      projectList
    }
  },
  methods: {
    enterRealisticRecord() {
      this.$router.push('/realisticRecordAssignmentSettings')
    },
    enterProjectsetting(id) {
      this.$router.push(`/projectsetting?projectId=${id}`)
    },
    handleMaskShow() {
      this.alertData = deepClone(this.projectList)
      this.category_alert_show = true
    },
    handleAdd() {
      this.addStatus = false
    },
    async alertConfirm() {
      // 一级目录设置 确认
      if (JSON.stringify(this.alertData) !== JSON.stringify(this.projectList)) {
        const { success, msg } = await this.$axios.$post(
          '/diathesis/project/updateTopProjects',
          {
            diathesisIdAndNameDtoList: this.alertData
          }
        )
        if (success) {
          this.projectList = await this.$axios.$get(
            '/diathesis/project/findProjectDetial'
          )
          this.$warn.show({ title: '修改成功' })
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
      this.category_alert_show = false
    }
  }
}
</script>
<style lang='scss'>
.elvaluation_standard {
  position: relative;
  width: 100%;
  min-height: 100%;
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 1px 3px rgba(207, 210, 212, 0.6);
  // transform: translate(0, 0);
  .projectlist {
    width: 100%;
    margin-top: 20px;
    overflow: hidden;
    & > .liItem {
      cursor: pointer;
      float: left;
      margin-right: 20px;
      margin-bottom: 20px;
      width: 210px;
      height: 180px;
      border-radius: 4px;
      & > .top {
        width: 100%;
        height: 120px;
        background: url('../../assets/image/subject/projectbackground.png')
          no-repeat;
        color: #fff;
        font-family: PingFangSC-Regular;
        font-size: 22px;
        text-align: center;
        line-height: 120px;
      }
      & > .bottom {
        width: 100%;
        height: 60px;
        border: 1px solid #cccccc;
        border-top: none;
        padding: 8px 5px;
        & > span {
          display: inline-block;
          width: 96px;
          text-align: center;
          & > p:nth-of-type(1) {
            font-family: PingFangSC-Regular;
            font-size: 16px;
            color: #317eeb;
          }
          & > p:nth-of-type(2) {
            font-family: PingFangSC-Regular;
            font-size: 14px;
            color: #333333;
          }
          &:nth-of-type(1) {
            border-right: 1px solid #cccccc;
          }
        }
      }
    }
  }
  .first_project_setting {
    /deep/ td {
      padding: 3px 10px !important;
    }
    /deep/ th {
      font-weight: 600;
      padding: 9px 10px !important;
    }
    /deep/ .ant-table-footer {
      padding: 8px;
      background: #fff;
    }
  }
}
</style>


