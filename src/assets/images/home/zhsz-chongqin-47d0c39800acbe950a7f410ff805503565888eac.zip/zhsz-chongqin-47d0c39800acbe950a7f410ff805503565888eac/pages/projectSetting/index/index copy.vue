<!--  author:   Date:  -->
<template>
  <div class="project_setting">
    <wp-button-group>
      <wp-button @click="saveHandler">保存</wp-button>
      <wp-button type="second" @click="proportionsSettingShowHandler">各类评价值占比设置</wp-button>
    </wp-button-group>
    <div class="project_setting_list">
      <div
        v-for="(project, index) of diathesisChildProjectDtos"
        :key="index"
        class="project_setting_item"
      >
        <wp-row>
          <span class="second_project_title">二级类目：</span>
          <wp-input
            v-model="project.projectName"
            :title="project.projectName"
            class="second_project_inp"
            maxlength="20"
          ></wp-input>
          <i>若名称为空，则不进行分类</i>
          <wp-icon
            v-if="diathesisChildProjectDtos.length>1"
            class="wp_fr"
            style="margin-top: 8px;cursor: pointer"
            fill="#aaa"
            name="close"
            @click.native.stop="delHandler(index)"
          ></wp-icon>
        </wp-row>
        <wp-row>
          <table border="1" class="project_setting_table">
            <colgroup>
              <col width="150px">
              <col>
              <col width="100px">
            </colgroup>
            <tbody>
              <tr v-for="(second_project, i) in project.childProjectList" :key="i">
                <td>
                  <input
                    v-model="second_project.projectName"
                    class="project_name"
                    type="text"
                    autofocus
                    :title="second_project.projectName"
                    placeholder="请输入项目"
                  >
                </td>
                <td>
                  <p style="display: inline-block">
                    评价类型：{{
                    formateEvaluationTypes(second_project.evaluationTypes)
                    }}
                  </p>
                  <wp-popover v-model="second_project.typeAlert">
                    <a
                      href="javascript: void(0)"
                      @click="changeTypeHandler(second_project.evaluationTypes)"
                    >修改</a>
                    <div slot="content" style="width: 275px">
                      <wp-checkbox-group v-model="typeSelect" :min="1">
                        <wp-checkbox
                          v-for="item in evaluation"
                          :key="item.id"
                          :label="item.id"
                          class="alert_checkbox"
                        >{{ item.name }}</wp-checkbox>
                      </wp-checkbox-group>
                      <wp-button-group class="alert_btns">
                        <wp-button
                          type="second"
                          size="small"
                          @click="second_project.typeAlert = false"
                        >取消</wp-button>
                        <wp-button size="small" @click="typeAlertConfirm(second_project)">确认</wp-button>
                      </wp-button-group>
                    </div>
                  </wp-popover>
                </td>
                <td class="project_operations">
                  <wp-popover v-model="second_project.remarkAlert">
                    <a
                      href="javascript: void(0)"
                      @click="changeRemarkHandler(second_project.remark)"
                    >{{ second_project.remark ? '修改备注' : '添加备注' }}</a>
                    <template slot="content">
                      <wp-textarea
                        v-model="remarkContent"
                        placeholder="请输入备注内容"
                        width="200px"
                        :height="70"
                        style="margin-bottom: 10px"
                      ></wp-textarea>
                      <wp-button-group class="alert_btns">
                        <wp-button
                          type="second"
                          size="small"
                          @click="second_project.remarkAlert = false"
                        >取消</wp-button>
                        <wp-button size="small" @click="remarkAlertConfirm(second_project)">确认</wp-button>
                      </wp-button-group>
                    </template>
                  </wp-popover>
                  <i
                    style="color: #d9d9d9"
                    v-if="project.childProjectList && project.childProjectList.length>1"
                  >&nbsp;|&nbsp;</i>
                  <wp-popover
                    v-model="second_project.delAlert"
                    v-if="project.childProjectList && project.childProjectList.length>1"
                  >
                    <a href="javascript: void(0)">删除</a>
                    <div slot="content">
                      <p>确定要删除吗？</p>
                      <wp-button-group style="margin-top: 10px" class="alert_btns">
                        <wp-button
                          type="second"
                          background="primary"
                          size="small"
                          @click="second_project.delAlert = false"
                        >取消</wp-button>
                        <wp-button
                          type="main"
                          size="small"
                          background="primary"
                          @click="
                            delSubProjectHandler(project, i, second_project)
                          "
                        >确定</wp-button>
                      </wp-button-group>
                    </div>
                  </wp-popover>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" align="center" @click="addSubProjectHandler(project)">
                  <wp-icon name="add-pure" font-size="12" fill="#347ee9"></wp-icon>&nbsp;
                  <a href="javascript: void(0)">新增子项目</a>
                </td>
              </tr>
            </tfoot>
          </table>
        </wp-row>
      </div>
    </div>
    <wp-button class="addBtn" type="second" @click="addHandler">新增二级类目</wp-button>
    <wp-alert
      title="各类评价值占比设置"
      width="600px"
      :visible="proportionsSettingShow"
      class="proportions_alert"
      @close="proportionsSettingShow = false"
      @confirm="proportionsSettingConfirmHandler"
    >
      <wp-row>
        <wp-col :span="5" align="right">
          <p style="margin-top: 10px">各类评价值占比：</p>
        </wp-col>
        <wp-col :span="19">
          <table border="1" class="proportions_table">
            <tbody>
              <tr v-for="(proportion, index) in evaluation" :key="proportion.id">
                <td>{{ proportion.name }}</td>
                <td>
                  <wp-input
                    v-model="temporaryProportions[index]"
                    width="100px"
                    type="number"
                    maxlength="20"
                  ></wp-input>&nbsp;&nbsp;%
                </td>
              </tr>
            </tbody>
          </table>
          <wp-icon name="warning" fill="#faad14" style="margin-right: 10px"></wp-icon>
          <i>占比值需是整数，总和应为100%</i>
        </wp-col>
      </wp-row>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone, chargeObjectEqual } from '../../../utils/tools'
const defaultProject = {
  id: '',
  projectName: '',
  parentId: '',
  projectType: '',
  sortNumber: '',
  childProjectList: [
    {
      id: '',
      projectName: '',
      parentId: '',
      projectType: '',
      sortNumber: '',
      evaluationTypes: ['1', '2', '3', '4', '5'],
      remark: '',
      typeAlert: false,
      remarkAlert: false,
      delAlert: false
    }
  ]
}
const defaultSecondProject = {
  id: '',
  projectName: '',
  parentId: '',
  projectType: '',
  sortNumber: '',
  evaluationTypes: ['1', '2', '3', '4', '5'],
  remark: '',
  typeAlert: false,
  remarkAlert: false,
  delAlert: false
}
export default {
  beforeRouteLeave(to, from, next) {
    to.query.projectId = this.projectId
    this.checkSaveHandler(next)
  },
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: {},
  props: {
    projectId: {
      type: String,
      required: true
    },
    childProjectList: {
      type: Array,
      required: true
    },
    proportions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      typeSelect: [],
      remarkContent: '',
      proportionsSettingShow: false, // 评价值占比弹框展示
      diathesisChildProjectDtos: [],
      localProportions: [],
      temporaryProportions: [],
      evaluation: [
        // 学生自评 2:家长评价 3:学生互评 4:导师评价 5:班主任评价
        { id: '1', name: '学生自评' },
        { id: '2', name: '家长评价' },
        { id: '3', name: '学生互评' },
        { id: '4', name: '导师评价' },
        { id: '5', name: '班主任评价' }
      ]
    }
  },
  computed: {},
  watch: {
    childProjectList: {
      handler: function(newVal) {
        if (!this.childProjectList.length) {
          this.diathesisChildProjectDtos = []
          this.diathesisChildProjectDtos.push(deepClone(defaultProject))
        } else {
          this.diathesisChildProjectDtos = deepClone(this.childProjectList)
        }
      },
      deep: true,
      immediate: true
    },
    proportions: {
      handler: function(newVal) {
        this.localProportions = deepClone(newVal)
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {},
  created() {},
  methods: {
    proportionsSettingShowHandler() {
      this.proportionsSettingShow = true
      this.temporaryProportions = deepClone(this.localProportions)
    },
    proportionsSettingConfirmHandler() {
      let percent = 0
      let isInt = this.temporaryProportions.every(item => {
        if (parseInt(item) !== +item) {
          return false
        }
        percent += +item
        return true
      })
      if (!isInt) {
        this.$warn.show({ title: '占比值需是整数' })
        return
      }
      if (percent !== 100) {
        this.$warn.show({ title: '总和应为100%' })
        return
      }
      this.localProportions = this.temporaryProportions
      this.proportionsSettingShow = false
    },
    // 新增二级类目
    addHandler() {
      this.diathesisChildProjectDtos.push(deepClone(defaultProject))
    },
    // 新增子项目
    addSubProjectHandler(project) {
      project.childProjectList.push({
        ...defaultSecondProject,
        index: project.childProjectList.length
      })
    },
    delHandler(index) {
      this.$alert.show({
        type: 'warning',
        title: '确认删除',
        message: '确认删除此二级类目吗？',
        description: '删除后点击保存则删除此二级类目的信息。',
        closeCallBack: () => {
          this.$alert.hide()
        },
        confirmCallBack: () => {
          this.diathesisChildProjectDtos.splice(index, 1)
          this.$alert.hide()
        }
      })
    },
    delSubProjectHandler(project, index, secondProject) {
      project.childProjectList.splice(index, 1)
      secondProject.delAlert = false
    },
    changeTypeHandler(types) {
      this.typeSelect = deepClone(types)
    },
    changeRemarkHandler(remark) {
      this.remarkContent = deepClone(remark) || ''
    },
    typeAlertConfirm(secondProject) {
      secondProject.evaluationTypes = this.typeSelect
      secondProject.typeAlert = false
    },
    remarkAlertConfirm(secondProject) {
      secondProject.remark = this.remarkContent
      secondProject.remarkAlert = false
    },
    // 转换评价类型
    formateEvaluationTypes(evaluationTypes) {
      if (evaluationTypes.length === 5) return '默认'
      let _evaluationTypes = deepClone(evaluationTypes)
      _evaluationTypes = _evaluationTypes.join(',')
      this.evaluation.forEach(item => {
        _evaluationTypes = _evaluationTypes.replace(item.id, item.name)
      })
      return _evaluationTypes
    },
    // 保存前清洗数据把空值删除
    formData() {
      this.diathesisChildProjectDtos = this.diathesisChildProjectDtos.filter(
        childProject => {
          if (!chargeObjectEqual(defaultProject, childProject)) {
            // 再对子项进行清洗
            childProject.childProjectList = childProject.childProjectList.filter(
              project => {
                this.$delete(project, 'index')
                if (!chargeObjectEqual(defaultSecondProject, project)) {
                  return true
                }
                return false
              }
            )
            return true
          }
          return false
        }
      )
    },
    // 保存
    async saveHandler() {
      this.formData()
      const { success, msg } = await this.$axios.$post(
        '/diathesis/project/saveChildProject',
        {
          parentId: this.projectId,
          proportions: this.localProportions,
          childProjectList: this.diathesisChildProjectDtos
        }
      )
      if (success) {
        this.$warn.show({
          title: '保存成功'
        })
        this.$emit('reset')
      } else {
        this.$warn.show({
          title: msg
        })
      }
    },
    // 确认是否需要保存
    checkSaveHandler(next) {
      // 判断是否修改了初始值
      if (
        !chargeObjectEqual(
          this.diathesisChildProjectDtos,
          this.childProjectList.length
            ? this.childProjectList
            : [defaultProject]
        ) ||
        !chargeObjectEqual(this.proportions, this.localProportions)
      ) {
        this.$alert.show({
          type: 'warning',
          description: '当前页面数据未保存，需要保存吗？',
          closeCallBack: () => {
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          },
          confirmCallBack: async () => {
            await this.saveHandler()
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          }
        })
      } else if (next) {
        next()
      } else {
        this.$emit('next')
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.project_setting {
  padding-top: 20px;
  .project_setting_list {
    .project_setting_item {
      .second_project_title {
        font-size: 14px;
        color: #333333;
      }
      .second_project_inp {
        margin-right: 10px;
      }
      margin-top: 20px;
      padding: 20px;
      background: #f2faff;
      i {
        color: #999999;
        vertical-align: bottom;
      }
      .project_setting_table {
        width: 100%;
        border: 1px solid #cccccc;
        background: #fff;
        i {
          color: #d9d9d9;
        }
        td {
          padding: 10px;
          font-size: 14px;
        }
        .project_name {
          border: none;
          background: none;
          outline: none;
        }
        .project_operations {
          white-space: nowrap;
        }
      }
    }
  }
  .addBtn {
    margin-top: 20px;
  }
}
.proportions_alert {
  .proportions_table {
    border: 1px solid #cccccc;
    margin-bottom: 5px;
    width: 100%;
    td {
      padding: 3px 10px;
    }
  }
  i {
    color: #999999;
    font-size: 14px;
  }
}
.alert_btns {
  float: right;
}
.alert_checkbox {
  margin-left: 0;
  margin-right: 10px;
  margin-bottom: 20px;
}
</style>
