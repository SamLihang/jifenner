<!--  author:   Date:  -->
<template>
  <div class="project_setting">
    <wp-button-group style="display: block;marginBottom: 10px;">
      <wp-button @click="saveHandler">保存</wp-button>
    </wp-button-group>
    <div class="project_setting_name">
      <wp-button
        type="second"
        background="primary"
        @click="editProjectHandler"
        v-if="author.includes(3) || author.includes(5)"
      >
        <wp-icon name="bianji" font-size="12px" fill="#999" style="marginRight: 5px"></wp-icon>写实项目
      </wp-button>
      <wp-radio
        v-model="recordProjectSelected"
        :label="record.id"
        type="button"
        v-for="record in localRecordProjectList"
        :key="record.id"
      >{{record.name.substring(0,8)}}{{record.name.length > 8 ? '...' : ''}}</wp-radio>
    </div>
    <div class="project_setting_all">
      <div class="project_setting_base">
        <h6>基本设置</h6>
        <div class="project_setting_input">
          <span>录入人:</span>
          <wp-checkbox-group v-model="localRecordSetting.inputTypes" class="checkbox_group">
            <wp-checkbox
              v-for="(item, index) of localRecordSetting.peopleTypesMap ? Object.keys(
                    localRecordSetting.peopleTypesMap
                  ) : {}"
              :key="index"
              :label="item"
            >{{ localRecordSetting.peopleTypesMap[item] }}</wp-checkbox>
          </wp-checkbox-group>
        </div>
        <div class="project_setting_auditor">
          <span>审核人:</span>
          <wp-checkbox-group v-model="localRecordSetting.auditorTypes" class="checkbox_group">
            <wp-checkbox
              v-for="(item, index) in 
                    localRecordSetting.peopleTypesMap?
                  Object.keys(
                    localRecordSetting.peopleTypesMap
                  ) : {}"
              :key="index"
              :label="item"
            >{{ localRecordSetting.peopleTypesMap[item] }}</wp-checkbox>
          </wp-checkbox-group>
        </div>
        <div class="project_setting_countType">
          <span>统计形式:</span>
          <wp-radio v-model="localRecordSetting.countType" label="0">逐条展示</wp-radio>
          <wp-radio v-model="localRecordSetting.countType" label="1">按次数统计</wp-radio>
        </div>
      </div>
      <h6>录入项目设置</h6>
      <table border="1" class="project_setting_table" v-if="recordProjectSelected">
        <colgroup>
          <col style="width: 100px" />
        </colgroup>
        <tbody class="project_setting_tbody">
          <tr>
            <td class="project_setting_td structure">
              <template v-if="recordProjectSelected">
                <table
                  class="structure_table"
                  border="1"
                  cellspacing="0"
                  cellpadding="0"
                  rules="rows"
                >
                  <tbody>
                    <tr v-for="(structure, index) in localRecordSetting.structure" :key="index">
                      <td class="structure_name">
                        <input
                          v-model="structure.title"
                          type="text"
                          placeholder="字段名称，10个字"
                          class="structure_name_inp"
                          :disabled="author.includes(3) || author.includes(5) ? false : true"
                        />
                        <wp-checkbox
                          style="margin-right: 10px"
                          :value="Boolean(+structure.isMust)"
                          @input="
                        val => {
                          structure.isMust = +val
                        }"
                        >必填</wp-checkbox>
                        <wp-checkbox
                          :value="Boolean(+structure.isShow)"
                          @input="
                        val => {
                          structure.isShow = +val
                        }
                      "
                        >显示在列表</wp-checkbox>
                      </td>
                      <td class="twotd">
                        录入：
                        <wp-select
                          v-model="structure.dataType"
                          width="80px"
                          :data="structureTypes"
                          value-key="id"
                          label-key="type"
                          :disabled="author.includes(3) || author.includes(5) ? false : true"
                        ></wp-select>
                        <div v-if="['2', '3'].includes(structure.dataType)" class="options">
                          <p>
                            <span class="pro_check">选项：</span>
                            <span class="label_more_box" ref="labelbox" v-show="structure.option">
                              <span v-for="(item,index) in structure.option" :key="index">
                                <wp-tag
                                  type="hollow"
                                  border-color="#C1DDF2"
                                  color="#317EEB"
                                  background="#E7F3FC"
                                  style="margin-right: 5px;word-break: break-all;"
                                >{{item.contentTxt}}</wp-tag>
                              </span>
                            </span>
                            <wp-popover trigger="hover" class="label_more">
                              <wp-tag
                                type="hollow"
                                border-color="#C1DDF2"
                                color="#317EEB"
                                background="#E7F3FC"
                                style="cursor:pointer;"
                                class="more-tip"
                              >...</wp-tag>
                              <div slot="content">
                                <p class="more_p">
                                  全部：
                                  <span
                                    v-for="(item,minindex) in structure.option"
                                    :key="minindex"
                                  >
                                    <wp-tag
                                      type="hollow"
                                      border-color="#C1DDF2"
                                      color="#317EEB"
                                      background="#E7F3FC"
                                      style="margin-right: 5px;margin-bottom:4px;word-break: break-all;"
                                    >{{item.contentTxt}}</wp-tag>
                                  </span>
                                </p>
                              </div>
                            </wp-popover>
                          </p>
                          <a
                            href="javascript: void(0)"
                            class="ver_center"
                            @click="optionsAlertHandler(structure)"
                            v-if="author.includes(3) || author.includes(5)"
                          >{{ structure.option && structure.option.length ? '修改' : '设置' }}</a>
                        </div>
                      </td>
                      <td style="width: 50px;" v-if="author.includes(3) || author.includes(5)">
                        <a href="javascript:void(0)" @click="delHandler(index)">
                          <wp-icon name="shanchu" class="delete_icon" fill="#999999"></wp-icon>
                        </a>
                      </td>
                    </tr>
                  </tbody>
                  <tfoot v-if="author.includes(3) || author.includes(5)">
                    <tr>
                      <td colspan="3" class @click="addHandler">
                        <wp-icon name="add-pure" fill="#347ee9" font-size="12"></wp-icon>&nbsp;
                        <a href="javascript:void(0)">新增</a>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 选项设置弹窗 -->
    <wp-alert
      width="500px"
      :visible="optionsAlertShow"
      title="选项设置"
      @close="optionsAlertShow = false"
      @confirm="optionsAlertConfirm"
    >
      <sort-table :columns="['选项名称', '排序', '操作']" :data-source="optionsAlertData"></sort-table>
    </wp-alert>
    <!-- 项目编辑弹窗 -->
    <wp-alert
      width="500px"
      :visible="editProjectAlertShow"
      title="项目编辑"
      @close="editProjectAlertShow = false"
      @confirm="editProjectAlertConfirm"
    >
      <sort-table :columns="['选项名称', '排序', '操作']" :data-source="editProjectAlertData"></sort-table>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone, chargeObjectEqual } from '../../../utils/tools'
import sortTable from '../../../components/sortTable'
const defaultStructure = {
  id: '',
  isShow: '0',
  dataType: '1',
  title: '',
  colNo: '',
  option: [],
  isMust: 1
}
export default {
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: { sortTable },
  props: {
    projectId: {
      type: String,
      required: true
    },
    recordSetting: {
      type: Object,
      required: true
    },
    recordProjectList: {
      type: Array,
      required: true
    },
    author: {
      type: Array,
      required: true
    }
  },
  beforeRouteLeave(to, from, next) {
    to.query.projectId = this.projectId
    this.checkSaveHandler(next)
  },
  data() {
    return {
      optionsAlertShow: false,
      optionsAlertData: [],
      editProjectAlertShow: false,
      editProjectAlertData: [],
      temperaterOpertions: [],
      recordProjectSelected: null,
      localRecordProjectList: this.recordProjectList,
      localRecordSetting: this.recordSetting,
      structureTypes: [
        {
          id: '1',
          type: '文本'
        },
        {
          id: '2',
          type: '单选'
        },
        {
          id: '3',
          type: '多选'
        },
        {
          id: '4',
          type: '附件'
        },
        {
          id: '5',
          type: '数值'
        }
      ]
    }
  },
  computed: {},
  watch: {
    recordSetting: {
      handler: function(newVal) {
        this.localRecordSetting = deepClone(newVal)
        let that = this
        setTimeout(function() {
          that.temp()
        }, 10)
      },
      deep: true,
      immediate: true
    },
    recordProjectList: {
      handler: function(newVal) {
        if (newVal.length > 0) {
          this.localRecordProjectList = newVal
          this.recordProjectSelected = newVal[0].id
        }
      },
      deep: true,
      immediate: true
    },
    recordProjectSelected: {
      handler: function(newVal) {
        this.$emit('project-select', newVal)
      },
      deep: true
    }
  },
  mounted() {
    let that = this
    setTimeout(function() {
      that.temp()
    }, 10)
    window.onresize = function temp() {
      that.$refs.labelbox &&
        that.$refs.labelbox.forEach((v, index) => {
          let boxwidth = v.getBoundingClientRect().width
          let showuindex = 0
          let islong = false
          let addwidth = 0
          for (let i = 0; i < v.children.length; i++) {
            addwidth = addwidth + v.children[i].getBoundingClientRect().width
            if (addwidth > boxwidth - 32) {
              islong = true
              showuindex = i - 1
              addwidth = addwidth - v.children[i].getBoundingClientRect().width
              break
            }
          }
          if (showuindex === 0 && !islong) {
            v.nextElementSibling.style.display = 'none'
          } else {
            v.nextElementSibling.style.display = 'inline-block'
          }
          v.nextElementSibling.style.left = addwidth + 67 + 'px'
        })
    }
  },
  methods: {
    temp() {
      let that = this
      that.$refs.labelbox &&
        that.$refs.labelbox.forEach((v, index) => {
          let boxwidth = v.getBoundingClientRect().width
          let showuindex = 0
          let islong = false
          let addwidth = 0
          for (let i = 0; i < v.children.length; i++) {
            addwidth = addwidth + v.children[i].getBoundingClientRect().width
            if (addwidth > boxwidth - 32) {
              islong = true
              showuindex = i - 1
              addwidth = addwidth - v.children[i].getBoundingClientRect().width
              break
            }
          }
          if (showuindex === 0 && !islong) {
            v.nextElementSibling.style.display = 'none'
          } else {
            v.nextElementSibling.style.display = 'inline-block'
          }
          v.nextElementSibling.style.left = addwidth + 67 + 'px'
        })
    },
    formatOption(structure) {
      if (!structure.option) structure.option = []
      return Array.from(structure.option, option => {
        return option.contentTxt
      }).join(',')
    },
    // 编辑项目名称
    editProjectHandler() {
      // console.log(this.recordProjectList)
      this.editProjectAlertData = deepClone(this.recordProjectList)
      this.editProjectAlertShow = true
    },
    optionsAlertHandler(structure) {
      if (structure.option) {
        this.optionsAlertData = Array.from(structure.option, item => {
          return { id: item.id, name: item.contentTxt, colNo: item.colNo }
        })
      } else {
        this.optionsAlertData = []
      }
      this.optionsAlertShow = true
      this.temperaterOpertions = structure
    },
    optionsAlertConfirm() {
      let istrue = false
      this.optionsAlertData.forEach(item => {
        if (item.name == '') {
          this.optionsAlertShow = false
          this.$warn.show({ title: '名称不能为空' })
          istrue = true
          return
        }
      })
      if (istrue) {
        return
      }
      this.temperaterOpertions.option = Array.from(
        this.optionsAlertData,
        item => {
          return {
            id: item.id || '',
            contentTxt: item.name,
            colNo: item.colNo || ''
          }
        }
      )
      this.optionsAlertShow = false
      let that = this
      setTimeout(function() {
        that.temp()
      }, 10)
    },
    // 确定保存写实记录项目设置
    async editProjectAlertConfirm() {
      this.editProjectAlertShow = false
      if (
        chargeObjectEqual(this.editProjectAlertData, this.recordProjectList)
      ) {
        return
      }
      const { success, msg } = await this.$axios.$post(
        '/diathesis/project/updateRecords',
        {
          parentId: this.projectId,
          diathesisIdAndNameDtoList: this.editProjectAlertData
        }
      )
      if (success) {
        this.$emit('get-records')
        this.$warn.show({ title: '修改成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    addHandler() {
      this.localRecordSetting.structure.push(deepClone(defaultStructure))
    },
    delHandler(index) {
      this.localRecordSetting.structure.splice(index, 1)
    },
    // 检测是否需要保存
    checkSaveHandler(next) {
      this.localRecordSetting.structure &&
        this.localRecordSetting.structure.forEach(item => {
          if (item.option && !item.option.length) {
            delete item.option
          }
        })
      if (!chargeObjectEqual(this.localRecordSetting, this.recordSetting)) {
        this.$alert.show({
          type: 'warning',
          description: '当前页面数据未保存，需要保存吗？',
          closeCallBack: () => {
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          },
          confirmCallBack: async () => {
            await this.saveHandler()
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          }
        })
      } else if (next) {
        next()
      } else {
        this.$emit('next')
      }
    },
    // 删除多余数据(空数据)
    formatData() {
      this.localRecordSetting.structure = this.localRecordSetting.structure.filter(
        item => {
          if (
            item.title.trim() === '' &&
            (!item.option || !item.option.length)
          ) {
            return false
          }
          if (chargeObjectEqual(item, defaultStructure)) {
            return false
          } else {
            return true
          }
        }
      )
    },
    async saveHandler() {
      this.formatData()
      const { msg, success } = await this.$axios.$post(
        '/diathesis/setting/saveRecord',
        this.localRecordSetting
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
        this.$emit('project-select', this.recordSetting.id)
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.project_setting {
  padding-top: 20px;
  overflow: hidden;
  /deep/ .wp-radio--button {
    height: 32px;
    padding: 0 10px 0 0;
    border-radius: 0;
    line-height: 28px;
    border: none;
    display: block;
    text-align: right;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    &:hover {
      background: #e7f3fc;
      color: #333;
    }
  }
  /deep/ .project_setting_name > .is-active {
    &:hover {
      background: #347ee9;
      color: #fff;
    }
  }
  /deep/.wp-radio--button .wp-radio__text {
    font-size: 14px;
    line-height: 14px;
  }
  /deep/.wp-radio + .wp-radio--button {
    margin-left: 10px;
    margin-bottom: 4px;
  }
  /deep/.wp-checkbox__text {
    padding-left: 0;
  }
  .project_setting_name {
    float: left;
    width: 12%;
    min-height: 840px;
    border-right: 1px solid #cccccc;
    & > button {
      width: 95%;
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #333333;
      margin-bottom: 10px;
    }
  }
  .project_setting_all {
    width: 87%;
    margin-left: 1%;
    float: left;
    & > h6 {
      font-family: PingFangSC-Semibold;
      font-size: 16px;
      color: #333333;
      padding-left: 10px;
      margin: 15px 0;
    }
    .project_setting_base {
      width: 100%;
      & > h6 {
        font-family: PingFangSC-Semibold;
        font-size: 16px;
        color: #333333;
        padding-left: 15px;
      }
      .project_setting_input,
      .project_setting_auditor,
      .project_setting_countType {
        padding: 9px 10px 11px 10px;
        .wp-checkbox-group .wp-checkbox {
          margin-right: 20px;
          margin-bottom: 0;
          vertical-align: bottom;
        }
        & > span {
          display: inline-block;
          width: 70px;
          text-align: right;
          font-family: PingFangSC-Regular;
          font-size: 14px;
          color: #333333;
        }
      }
      .project_setting_countType {
        & > span {
          margin-right: 10px;
        }
      }
      .checkbox_group {
        display: inline-block;
        margin-left: 10px;
      }
    }
    .project_setting_table {
      width: 100%;
      border: 1px solid #cccccc;
      background: #fff;
      .project_setting_tbody {
        .project_setting_td {
          vertical-align: top;
          .project_setting_input {
            border-bottom: 1px solid #cccccc;
          }
          .project_setting_project_name {
            cursor: pointer;
            border-bottom: 1px solid #cccccc;
            padding: 15px 10px;
            &:hover {
              color: var(--primary-color);
            }
            &.active {
              background: #347ee9;
              color: #fff;
              border-bottom: none;
            }
          }
          .options {
            width: calc(100% - 140px);
            min-width: 200px;
            display: inline-block;
            p {
              display: inline-block;
              max-width: 83%;
              overflow: hidden;
              text-overflow: ellipsis;
              vertical-align: middle;
              position: relative;
              white-space: nowrap;
            }
            .wp-tag--hollow {
              margin-bottom: 4px;
            }
          }
          .structure_table {
            width: 100%;
            border-left: none;
            border-right: none;
            border-color: #cccccc;
            .pro_check {
              font-size: 14px;
              color: #333333;
              padding-left: 20px;
              vertical-align: middle;
            }
            tbody {
              td {
                padding: 4px 10px;
                &.twotd {
                  min-width: 355px;
                }
                &.structure_name {
                  width: 330px;
                  min-width: 330px;
                  .structure_name_inp {
                    width: 135px;
                    height: 32px;
                    padding: 5px;
                    border-radius: 4px;
                    border: 1px solid #ccc;
                    outline: none;
                    margin-right: 4px;
                  }
                  .wp-checkbox {
                    vertical-align: text-bottom;
                  }
                }
              }
            }
            tfoot {
              td {
                text-align: center;
                cursor: pointer;
                padding: 9px;
              }
            }
          }
        }
      }
    }
  }
}
.edit_pro {
  display: inline-block;
  width: 32px;
  height: 32px;
  background: #ffffff;
  border: 1px solid #cccccc;
  border-radius: 16px;
  cursor: pointer;
  text-align: center;
  line-height: 28px;
}
.edit_pro:hover {
  fill: #347ee9;
  border-color: #347ee9;
}
.delete_icon {
  cursor: pointer;
}
.delete_icon:hover {
  fill: #347ee9;
}
.ver_center {
  vertical-align: middle;
}
a:hover {
  text-decoration: underline;
}
.label_more_box {
  display: inline-block;
  height: 28px;
  overflow: hidden;
  vertical-align: middle;
  padding-right: 32px;
  width: calc(100% - 66px);
  white-space: initial;
}
.label_more {
  position: absolute;
  top: 0;
}
.more_p {
  max-width: 600px;
}
</style>
