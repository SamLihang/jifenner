<!--  author:   Date:  -->
<template>
  <div class="project_setting">
    <wp-button-group>
      <wp-button @click="saveHandler">保存</wp-button>
    </wp-button-group>
    <table border="1" class="project_setting_table">
      <colgroup>
        <col style="width: 100px" />
      </colgroup>
      <thead class="project_setting_thead">
        <tr>
          <td class="project_setting_td">
            项目名称
            <wp-button
              size="small"
              type="second"
              style="margin-left: 20px"
              @click="editProjectHandler"
            >编辑</wp-button>
          </td>
          <td class="project_setting_td">字段</td>
        </tr>
      </thead>
      <tbody class="project_setting_tbody">
        <tr>
          <td class="project_setting_td">
            <ul>
              <li
                v-for="record in localRecordProjectList"
                :key="record.id"
                class="project_setting_project_name"
                :class="{ active: recordProjectSelected === record }"
                @click="selectHandler(record)"
              >{{ record.name }}</li>
            </ul>
          </td>
          <td class="project_setting_td structure">
            <template v-if="recordProjectSelected">
              <div class="project_setting_input">
                录入人:
                <wp-checkbox-group v-model="localRecordSetting.inputTypes" class="checkbox_group">
                  <wp-checkbox
                    v-for="(item, index) of localRecordSetting.inputTypesMap ? Object.keys(
                    localRecordSetting.inputTypesMap
                  ) : {}"
                    :key="index"
                    :label="item"
                  >{{ localRecordSetting.inputTypesMap[item] }}</wp-checkbox>
                </wp-checkbox-group>
              </div>
              <div class="project_setting_auditor">
                审核人:
                <wp-checkbox-group v-model="localRecordSetting.auditorTypes" class="checkbox_group">
                  <wp-checkbox
                    v-for="(item, index) in 
                    localRecordSetting.auditorTypesMap?
                  Object.keys(
                    localRecordSetting.auditorTypesMap
                  ) : {}"
                    :key="index"
                    :label="item"
                  >{{ localRecordSetting.auditorTypesMap[item] }}</wp-checkbox>
                </wp-checkbox-group>
              </div>
              <table border="1" class="structure_table">
                <tbody>
                  <tr v-for="(structure, index) in localRecordSetting.structure" :key="index">
                    <td class="structure_name">
                      <input
                        v-model="structure.title"
                        type="text"
                        placeholder="字段名称，10个字"
                        class="structure_name_inp"
                      />
                      <wp-checkbox
                        style="margin-right: 10px"
                        :value="Boolean(+structure.isMust)"
                        @input="
                        val => {
                          structure.isMust = +val
                        }"
                      >必填</wp-checkbox>
                      <wp-checkbox
                        :value="Boolean(+structure.isShow)"
                        @input="
                        val => {
                          structure.isShow = +val
                        }
                      "
                      >显示在列表</wp-checkbox>
                    </td>
                    <td>
                      录入：
                      <wp-select
                        v-model="structure.dataType"
                        width="80px"
                        :data="structureTypes"
                        value-key="id"
                        label-key="type"
                      ></wp-select>
                      <div v-if="['2', '3'].includes(structure.dataType)" class="options">
                        <p>选项：{{ formatOption(structure) }}</p>
                        <a
                          href="javascript: void(0)"
                          @click="optionsAlertHandler(structure)"
                        >{{ structure.option && structure.option.length ? '修改' : '设置' }}</a>
                      </div>
                    </td>
                    <td style="width: 50px" @click="delHandler(index)">
                      <a href="javascript:void(0)">删除</a>
                    </td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr>
                    <td colspan="3" class @click="addHandler">
                      <wp-icon name="add-pure" fill="#347ee9" font-size="12"></wp-icon>&nbsp;
                      <a href="javascript:void(0)">新增</a>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </template>
          </td>
        </tr>
      </tbody>
    </table>
    <!-- 选项设置弹窗 -->
    <wp-alert
      width="500px"
      :visible="optionsAlertShow"
      title="选项设置"
      @close="optionsAlertShow = false"
      @confirm="optionsAlertConfirm"
    >
      <sort-table :columns="['选项名称', '排序', '操作']" :data-source="optionsAlertData"></sort-table>
    </wp-alert>
    <!-- 项目编辑弹窗 -->
    <wp-alert
      width="500px"
      :visible="editProjectAlertShow"
      title="项目编辑"
      @close="editProjectAlertShow = false"
      @confirm="editProjectAlertConfirm"
    >
      <sort-table :columns="['选项名称', '排序', '操作']" :data-source="editProjectAlertData"></sort-table>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone, chargeObjectEqual } from '../../../utils/tools'
import sortTable from '../../../components/sortTable'
const defaultStructure = {
  id: '',
  isShow: '0',
  dataType: '1',
  title: '',
  colNo: '',
  option: [],
  isMust: 1
}
export default {
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: { sortTable },
  props: {
    projectId: {
      type: String,
      required: true
    },
    recordSetting: {
      type: Object,
      required: true
    },
    recordProjectList: {
      type: Array,
      required: true
    }
  },
  beforeRouteLeave(to, from, next) {
    to.query.projectId = this.projectId
    this.checkSaveHandler(next)
  },
  data() {
    return {
      optionsAlertShow: false,
      optionsAlertData: [],
      editProjectAlertShow: false,
      editProjectAlertData: [],
      temperaterOpertions: [],
      recordProjectSelected: null,
      localRecordProjectList: this.recordProjectList,
      localRecordSetting: this.recordSetting,
      structureTypes: [
        {
          id: '1',
          type: '文本'
        },
        {
          id: '2',
          type: '单选'
        },
        {
          id: '3',
          type: '多选'
        },
        {
          id: '4',
          type: '附件'
        }
      ]
    }
  },
  computed: {},
  watch: {
    recordSetting: {
      handler: function(newVal) {
        this.localRecordSetting = deepClone(newVal)
      },
      deep: true,
      immediate: true
    },
    recordProjectList: {
      handler: function(newVal) {
        if (newVal) {
          this.localRecordProjectList = newVal
          this.recordProjectSelected = newVal[0]
        }
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {},
  methods: {
    formatOption(structure) {
      if (!structure.option) structure.option = []
      return Array.from(structure.option, option => {
        return option.contentTxt
      }).join(',')
    },
    // 编辑项目名称
    editProjectHandler() {
      // console.log(this.recordProjectList)
      this.editProjectAlertData = deepClone(this.recordProjectList)
      this.editProjectAlertShow = true
    },
    optionsAlertHandler(structure) {
      this.optionsAlertData = Array.from(structure.option, item => {
        return { id: item.id, name: item.contentTxt, colNo: item.colNo }
      })
      this.optionsAlertShow = true
      this.temperaterOpertions = structure
    },
    optionsAlertConfirm() {
      this.temperaterOpertions.option = Array.from(
        this.optionsAlertData,
        item => {
          return {
            id: item.id || '',
            contentTxt: item.name,
            colNo: item.colNo || ''
          }
        }
      )
      this.optionsAlertShow = false
    },
    // 确定保存写实记录项目设置
    async editProjectAlertConfirm() {
      this.editProjectAlertShow = false
      if (
        chargeObjectEqual(this.editProjectAlertData, this.recordProjectList)
      ) {
        return
      }
      const { success, msg } = await this.$axios.$post(
        '/diathesis/project/updateRecords',
        {
          parentId: this.projectId,
          diathesisIdAndNameDtoList: this.editProjectAlertData
        }
      )
      if (success) {
        this.$emit('get-records')
        this.$warn.show({ title: '修改成功' })
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    // 选择项目名称
    selectHandler(record) {
      this.checkSaveHandler(() => {
        this.$emit('project-select', record.id)
        this.recordProjectSelected = record
      })
    },
    addHandler() {
      this.localRecordSetting.structure.push(deepClone(defaultStructure))
    },
    delHandler(index) {
      this.localRecordSetting.structure.splice(index, 1)
    },
    // 检测是否需要保存
    checkSaveHandler(next) {
      this.localRecordSetting.structure &&
        this.localRecordSetting.structure.forEach(item => {
          if (item.option && !item.option.length) {
            delete item.option
          }
        })
      if (!chargeObjectEqual(this.localRecordSetting, this.recordSetting)) {
        this.$alert.show({
          type: 'warning',
          description: '当前页面数据未保存，需要保存吗？',
          closeCallBack: () => {
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          },
          confirmCallBack: async () => {
            await this.saveHandler()
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          }
        })
      } else if (next) {
        next()
      } else {
        this.$emit('next')
      }
    },
    // 删除多余数据(空数据)
    formatData() {
      this.localRecordSetting.structure = this.localRecordSetting.structure.filter(
        item => {
          if (
            item.title.trim() === '' &&
            (!item.option || !item.option.length)
          ) {
            return false
          }
          if (chargeObjectEqual(item, defaultStructure)) {
            return false
          } else {
            return true
          }
        }
      )
    },
    async saveHandler() {
      this.formatData()
      const { msg, success } = await this.$axios.$post(
        '/diathesis/setting/saveRecord',
        this.localRecordSetting
      )
      if (success) {
        this.$warn.show({ title: '保存成功' })
        this.$emit('project-select', this.recordSetting.id)
      } else {
        this.$warn.show({ title: msg || '请求失败' })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.project_setting {
  padding-top: 20px;
  .project_setting_table {
    width: 100%;
    margin-top: 20px;
    border: 1px solid #cccccc;
    background: #fff;
    .project_setting_thead {
      .project_setting_td {
        padding: 10px;
        white-space: nowrap;
      }
    }
    .project_setting_tbody {
      .project_setting_td {
        vertical-align: top;
        &.structure {
          padding: 10px;
        }
        .project_setting_input,
        .project_setting_auditor {
          margin-bottom: 10px;
        }
        .checkbox_group {
          display: inline-block;
        }
        .project_setting_project_name {
          cursor: pointer;
          border-bottom: 1px solid #cccccc;
          padding: 15px 10px;
          &:hover {
            color: var(--primary-color);
          }
          &.active {
            background: #347ee9;
            color: #fff;
            border-bottom: none;
          }
        }
        .options {
          width: calc(100% - 140px);
          min-width: 100px;
          display: inline-block;
          white-space: nowrap;
          p {
            display: inline-block;
            width: 83%;
            overflow: hidden;
            text-overflow: ellipsis;
            vertical-align: bottom;
          }
        }
        .structure_table {
          width: 100%;
          border: 1px solid #cccccc;
          tbody {
            td {
              padding: 3px 10px;
              &.structure_name {
                width: 330px;
                .structure_name_inp {
                  width: 135px;
                  height: 32px;
                  padding: 5px;
                  border-radius: 4px;
                  border: 1px solid #ccc;
                  outline: none;
                  margin-right: 4px;
                }
              }
            }
          }
          tfoot {
            td {
              text-align: center;
              cursor: pointer;
              padding: 9px;
            }
          }
        }
      }
    }
  }
}
</style>
