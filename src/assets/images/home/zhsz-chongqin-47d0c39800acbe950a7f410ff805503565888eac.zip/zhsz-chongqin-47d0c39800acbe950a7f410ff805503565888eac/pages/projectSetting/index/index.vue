<!--  author:   Date:  -->
<template>
  <div class="project_setting">
    <wp-button-group>
      <wp-button @click="saveHandler">保存</wp-button>
      <wp-button type="second" @click="proportionsSettingShowHandler">占比设置</wp-button>
    </wp-button-group>
    <div class="project_setting_list">
      <div
        v-for="(project, index) of diathesisChildProjectDtos"
        :key="index"
        class="project_setting_item"
      >
        <wp-row v-if="author.includes(3) || author.includes(4)">
          <span class="second_project_title">二级类目：</span>
          <wp-input
            v-model="project.projectName"
            :title="project.projectName"
            class="second_project_inp"
            maxlength="20"
          ></wp-input>
          <i>若名称为空，则不进行分类</i>
          <wp-icon
            v-if="diathesisChildProjectDtos.length>1"
            class="wp_fr remove_icon"
            style="margin-top: 8px;cursor: pointer;margin-right:10px;"
            name="shanchu"
            fill="#999"
            @click.native.stop="delHandler(index)"
          ></wp-icon>
        </wp-row>
        <wp-row v-else>
          <span class="second_project_title">二级类目：{{project.projectName}}</span>
        </wp-row>
        <wp-row>
          <table border="1" class="project_setting_table">
            <colgroup>
              <col />
              <col width="500px" />
              <col width="100px" v-if="author.includes(3) || author.includes(4)" />
            </colgroup>
            <tbody>
              <tr v-for="(second_project, i) in project.childProjectList" :key="i">
                <td>
                  <!-- <input
                    autofocus
                    type="text"
                    class="project_name"
                    placeholder="请输入项目"
                    :title="second_project.projectName"
                    v-model="second_project.projectName"
                    style="width: 100%"
                  />-->
                  <wp-textarea
                    class="project_name"
                    placeholder="请输入项目"
                    v-model="second_project.projectName"
                    :maxheight="45"
                    resize="none"
                    :disabled="!author.includes(3) && !author.includes(4)"
                  ></wp-textarea>
                </td>
                <td>
                  <p style="display: inline-block">
                    评价类型：
                    <span
                      v-for="(inputType,index) in formateEvaluationTypes(second_project.evaluationTypes)"
                      :key="index"
                    >
                      <wp-tag
                        type="hollow"
                        border-color="#C1DDF2"
                        color="#317EEB"
                        background="#E7F3FC"
                        style="margin-right: 10px;margin-bottom:4px;"
                      >{{inputType}}</wp-tag>
                    </span>
                  </p>
                  <wp-popover v-model="second_project.typeAlert">
                    <a
                      href="javascript: void(0)"
                      @click="changeTypeHandler(second_project.evaluationTypes)"
                      class="ver_center"
                    >修改</a>
                    <div slot="content" style="width: 275px">
                      <wp-checkbox-group v-model="typeSelect" :min="1">
                        <wp-checkbox
                          v-for="item in evaluation"
                          :key="item.id"
                          :label="item.id"
                          class="alert_checkbox"
                        >{{ item.name }}</wp-checkbox>
                      </wp-checkbox-group>
                      <wp-button-group class="alert_btns">
                        <wp-button
                          type="second"
                          size="small"
                          @click="second_project.typeAlert = false"
                        >取消</wp-button>
                        <wp-button size="small" @click="typeAlertConfirm(second_project)">确认</wp-button>
                      </wp-button-group>
                    </div>
                  </wp-popover>
                </td>
                <td class="project_operations" v-if="author.includes(3) || author.includes(4)">
                  <wp-popover
                    v-model="second_project.delAlert"
                    v-if="project.childProjectList && project.childProjectList.length>1"
                  >
                    <a href="javascript: void(0)">删除</a>
                    <div slot="content">
                      <p>确定要删除吗？</p>
                      <wp-button-group style="margin-top: 10px" class="alert_btns">
                        <wp-button
                          type="second"
                          background="primary"
                          size="small"
                          @click="second_project.delAlert = false"
                        >取消</wp-button>
                        <wp-button
                          type="main"
                          size="small"
                          background="primary"
                          @click="
                            delSubProjectHandler(project, i, second_project)
                          "
                        >确定</wp-button>
                      </wp-button-group>
                    </div>
                  </wp-popover>
                </td>
              </tr>
            </tbody>
            <tfoot v-if="author.includes(3) || author.includes(4)">
              <tr>
                <td colspan="3" align="center" @click="addSubProjectHandler(project)">
                  <wp-icon name="add-pure" font-size="12" fill="#347ee9"></wp-icon>&nbsp;
                  <a href="javascript: void(0)" class="ver_center">新增子项目</a>
                </td>
              </tr>
            </tfoot>
          </table>
        </wp-row>
      </div>
    </div>
    <div class="nocontent" v-if="diathesisChildProjectDtos.length <= 0">
      <img src="~/assets/image/subject/nocontent.png" />
      <div class="nocontent_title">暂无二级类目，点击新增哟</div>
    </div>
    <wp-button
      class="addBtn"
      type="second"
      @click="addHandler"
      v-if="author.includes(3) || author.includes(4)"
    >
      <wp-icon name="add-pure" font-size="12" class="add_btn_i"></wp-icon>&nbsp;新增
    </wp-button>
    <wp-alert
      title="占比设置"
      width="500px"
      :visible="proportionsSettingShow"
      class="proportions_alert"
      @close="proportionsSettingShow = false"
      @confirm="proportionsSettingConfirmHandler"
    >
      <wp-row>
        <wp-col
          :span="12"
          v-for="(proportion, index) in evaluation"
          :key="proportion.id"
          class="proport_item"
        >
          {{ proportion.name }}:
          <wp-input
            v-model="temporaryProportions[index]"
            width="100px"
            type="number"
            maxlength="20"
            class="proport_tem"
          ></wp-input>&nbsp;&nbsp;%
        </wp-col>
        <wp-col :span="24" style="margin-top:-10px;">
          <wp-icon name="warning" fill="#faad14" style="margin-right: 2px" font-size="12px"></wp-icon>
          <i class="proport_tip">占比值需是整数，总和应为100%</i>
        </wp-col>
      </wp-row>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone, chargeObjectEqual } from '../../../utils/tools'
const defaultProject = {
  id: '',
  projectName: '',
  parentId: '',
  projectType: '',
  sortNumber: '',
  childProjectList: [
    {
      id: '',
      projectName: '',
      parentId: '',
      projectType: '',
      sortNumber: '',
      evaluationTypes: ['1', '2', '3', '4', '5'],
      typeAlert: false,
      delAlert: false
    }
  ]
}
const defaultSecondProject = {
  id: '',
  projectName: '',
  parentId: '',
  projectType: '',
  sortNumber: '',
  evaluationTypes: ['1', '2', '3', '4', '5'],
  typeAlert: false,
  delAlert: false
}
export default {
  beforeRouteLeave(to, from, next) {
    to.query.projectId = this.projectId
    this.checkSaveHandler(next)
  },
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: {},
  props: {
    projectId: {
      type: String,
      required: true
    },
    childProjectList: {
      type: Array,
      required: true
    },
    proportions: {
      type: Array,
      required: true
    },
    author: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      typeSelect: [],
      proportionsSettingShow: false, // 评价值占比弹框展示
      diathesisChildProjectDtos: [],
      localProportions: [],
      temporaryProportions: [],
      evaluation: [
        // 学生自评 2:家长评价 3:学生互评 4:导师评价 5:班主任评价
        { id: '1', name: '学生自评' },
        { id: '2', name: '家长评价' },
        { id: '3', name: '学生互评' },
        { id: '4', name: '导师评价' },
        { id: '5', name: '班主任评价' }
      ]
    }
  },
  computed: {},
  watch: {
    childProjectList: {
      handler: function(newVal) {
        if (!this.childProjectList.length) {
          this.diathesisChildProjectDtos = []
          this.diathesisChildProjectDtos.push(deepClone(defaultProject))
        } else {
          this.diathesisChildProjectDtos = deepClone(this.childProjectList)
        }
      },
      deep: true,
      immediate: true
    },
    proportions: {
      handler: function(newVal) {
        this.localProportions = deepClone(newVal)
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {},
  created() {},
  methods: {
    proportionsSettingShowHandler() {
      this.proportionsSettingShow = true
      this.temporaryProportions = deepClone(this.localProportions)
    },
    proportionsSettingConfirmHandler() {
      let percent = 0
      let isInt = this.temporaryProportions.every(item => {
        if (parseInt(item) !== +item) {
          return false
        }
        percent += +item
        return true
      })
      if (!isInt) {
        this.$warn.show({ title: '占比值需是整数' })
        return
      }
      if (percent !== 100) {
        this.$warn.show({ title: '总和应为100%' })
        return
      }
      this.localProportions = this.temporaryProportions
      this.proportionsSettingShow = false
    },
    // 新增二级类目
    addHandler() {
      this.diathesisChildProjectDtos.push(deepClone(defaultProject))
    },
    // 新增子项目
    addSubProjectHandler(project) {
      project.childProjectList.push({
        ...defaultSecondProject,
        index: project.childProjectList.length
      })
    },
    delHandler(index) {
      this.$alert.show({
        type: 'warning',
        title: '确认删除',
        message: '确认删除此二级类目吗？',
        description: '删除后点击保存则删除此二级类目的信息。',
        closeCallBack: () => {
          this.$alert.hide()
        },
        confirmCallBack: () => {
          this.diathesisChildProjectDtos.splice(index, 1)
          this.$alert.hide()
        }
      })
    },
    delSubProjectHandler(project, index, secondProject) {
      project.childProjectList.splice(index, 1)
      secondProject.delAlert = false
    },
    changeTypeHandler(types) {
      this.typeSelect = deepClone(types)
    },
    typeAlertConfirm(secondProject) {
      secondProject.evaluationTypes = this.typeSelect
      secondProject.typeAlert = false
    },
    // 转换评价类型
    formateEvaluationTypes(evaluationTypes) {
      if (evaluationTypes.length === 5) return ['默认']
      let _evaluationTypes = deepClone(evaluationTypes)
      _evaluationTypes = _evaluationTypes.join(',')
      this.evaluation.forEach(item => {
        _evaluationTypes = _evaluationTypes.replace(item.id, item.name)
      })
      _evaluationTypes = _evaluationTypes.split(',')
      return _evaluationTypes
    },
    // 保存前清洗数据把空值删除
    formData() {
      this.diathesisChildProjectDtos = this.diathesisChildProjectDtos.filter(
        childProject => {
          if (!chargeObjectEqual(defaultProject, childProject)) {
            // 再对子项进行清洗
            childProject.childProjectList = childProject.childProjectList.filter(
              project => {
                this.$delete(project, 'index')
                if (!chargeObjectEqual(defaultSecondProject, project)) {
                  return true
                }
                return false
              }
            )
            return true
          }
          return false
        }
      )
    },
    // 保存
    async saveHandler() {
      this.formData()
      const { success, msg } = await this.$axios.$post(
        '/diathesis/project/saveChildProject',
        {
          parentId: this.projectId,
          proportions: this.localProportions,
          childProjectList: this.diathesisChildProjectDtos
        }
      )
      if (success) {
        this.$warn.show({
          title: '保存成功'
        })
        this.$emit('reset')
      } else {
        this.$warn.show({
          title: msg
        })
      }
    },
    // 确认是否需要保存
    checkSaveHandler(next) {
      // 判断是否修改了初始值
      if (
        !chargeObjectEqual(
          this.diathesisChildProjectDtos,
          this.childProjectList.length
            ? this.childProjectList
            : [defaultProject]
        ) ||
        !chargeObjectEqual(this.proportions, this.localProportions)
      ) {
        this.$alert.show({
          type: 'warning',
          description: '当前页面数据未保存，需要保存吗？',
          closeCallBack: () => {
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          },
          confirmCallBack: async () => {
            await this.saveHandler()
            this.$alert.hide()
            if (next) {
              next()
            } else {
              this.$emit('next')
            }
          }
        })
      } else if (next) {
        next()
      } else {
        this.$emit('next')
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.project_setting {
  padding-top: 20px;
  .project_setting_list {
    .project_setting_item {
      .second_project_title {
        font-size: 16px;
        color: #333333;
        font-weight: bold;
        vertical-align: middle;
      }
      .second_project_inp {
        margin-right: 10px;
      }
      padding: 10px 0 0 0;
      i {
        color: #999999;
        vertical-align: middle;
        font-size: 12px;
      }
      .project_setting_table {
        width: 100%;
        border: 1px solid #cccccc;
        background: #fff;
        i {
          color: #d9d9d9;
        }
        td {
          padding: 10px;
          font-size: 14px;
        }
        .project_name {
          border: none;
          background: none;
          outline: none;
        }
        .project_operations {
          white-space: nowrap;
        }
      }
    }
  }
  .addBtn {
    margin-top: 10px;
  }
  .addBtn:hover svg {
    fill: #347ee9;
  }
  .add_btn_i {
    position: relative;
    top: -2px;
  }
}
.proportions_alert {
  i {
    color: #999999;
    font-size: 14px;
  }
  .proport_tem {
    margin-left: 4px;
  }
  .proport_item {
    margin-bottom: 20px;
  }
  .proport_tip {
    font-size: 12px;
    color: #faad14;
    vertical-align: middle;
  }
}
.alert_btns {
  float: right;
}
.alert_checkbox {
  margin-left: 0;
  margin-right: 10px;
  margin-bottom: 20px;
}
.ver_center {
  vertical-align: middle;
}
.remove_icon:hover {
  fill: #347ee9;
}
a:hover {
  text-decoration: underline;
}
</style>
