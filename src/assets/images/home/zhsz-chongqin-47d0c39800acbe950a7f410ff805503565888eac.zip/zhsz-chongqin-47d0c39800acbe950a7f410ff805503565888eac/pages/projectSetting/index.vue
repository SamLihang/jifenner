<!--  author:   Date:  -->
<template>
  <div class="wrapper_colums">
    <div class="wrapper_left">
      <wp-button
        type="second"
        class="category_etting_btn"
        @click="showAlert"
        v-if="author.includes(3)"
      >一级类目设置</wp-button>
      <ul class="project_list">
        <wp-scrollbar style="height:100%">
          <li
            v-for="project in projectList"
            :key="project.id"
            class="project_item"
            :class="{ active: projectId === project.id }"
            @click="beforeProjectChangeHandler(project.id)"
          >
            <h5 :title="project.name">{{ project.name }}</h5>
          </li>
        </wp-scrollbar>
      </ul>
    </div>
    <div class="wrapper_right" style="padding-top: 0;overflow-x:auto;">
      <wp-tabbar v-model="selected" :datasource="tabbarData" width="100%" target="link"></wp-tabbar>
      <nuxt-child
        v-if="transPage"
        :key="1"
        ref="nuxtChild"
        :project-id="projectId"
        :child-project-list="childProjectList"
        :record-setting="recordSetting"
        :proportions="proportions"
        :record-project-list="recordProjectList"
        :author="author"
        @next="nextHandler"
        @reset="getData"
        @get-records="getRecords"
        @project-select="projdectSelectHandler"
      />
      <nuxt-child
        v-else
        :key="2"
        ref="nuxtChild"
        :project-id="projectId"
        :child-project-list="childProjectList"
        :record-setting="recordSetting"
        :proportions="proportions"
        :record-project-list="recordProjectList"
        :author="author"
        @next="nextHandler"
        @reset="getData"
        @get-records="getRecords"
        @project-select="projdectSelectHandler"
      />
    </div>
    <wp-alert
      width="500px"
      class="first_project_setting"
      :visible="category_alert_show"
      title="一级类目设置"
      @close="category_alert_show = false"
      @confirm="alertConfirm"
    >
      <sort-table :columns="['类目名称', '排序', '操作']" :data-source="alertData"></sort-table>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone } from '../../utils/tools'
import sortTable from '../../components/sortTable'
export default {
  name: '',
  scrollToTop: true,
  transition: 'left',
  components: {
    sortTable
  },
  data() {
    return {
      transPage: true,
      category_alert_columns: [
        {
          title: '类目名称',
          scopedSlots: { customRender: 'name' }
        },
        {
          title: '排序',
          scopedSlots: { customRender: 'sort' }
        },
        {
          title: '操作',
          customRender: (text, row, index) => {
            return {
              children: '删除'
            }
          }
        }
      ],
      category_alert_show: false,
      selected: this.$route.path,
      tabbarData: [
        {
          title: '子项目设置',
          link: '/projectsetting'
        },
        {
          title: '写实记录设置',
          link: '/projectsetting/realisticrecordsetting'
        }
      ],
      alertData: [],
      localProjectId: this.projectId
    }
  },
  computed: {},
  watch: {
    selected(newVal) {
      this.getData(newVal)
    },
    async projectId(newVal) {
      await this.getData()
    },
    '$route.path': {
      handler: function(newVal) {
        this.selected = newVal
      }
    }
  },
  async asyncData({ $axios, store, route, query }) {
    const author = await $axios.$get('/diathesis/setting/findAuthorList')
    let projectList =
      (await $axios.$get('/diathesis/project/findTopProject')) || []
    if (typeof projectList === 'string') {
      projectList = []
    }

    const projectId = query.projectId
      ? query.projectId
      : projectList.length
      ? projectList[0].id
      : ''
    if (route.path.toLowerCase() === '/projectsetting') {
      let { childProjectList = [], proportions = [] } = await $axios.$get(
        `/diathesis/project/findChildProject?parentId=${projectId}`
      )
      const arr = []
      childProjectList.forEach(project => {
        if (project.parentId === projectId) {
          const alive = arr.some(item => {
            if (item.id === project.id) {
              item = { ...item, ...project }
              return true
            }
          })
          if (!alive) {
            arr.push({
              ...project,
              childProjectList: []
            })
          }
        } else {
          const alive = arr.some(item => {
            if (item.id === project.parentId) {
              item.childProjectList.push({
                ...project,
                typeAlert: false,
                remarkAlert: false,
                delAlert: false
              })
              return true
            }
          })
          if (!alive) {
            arr.push({
              id: project.parentId,
              projectName: '',
              childProjectList: [
                {
                  ...project,
                  typeAlert: false,
                  remarkAlert: false,
                  delAlert: false
                }
              ]
            })
          }
        }
      })
      childProjectList = arr
      const recordSetting = {}
      const recordProjectList = []
      return {
        projectList,
        projectId,
        childProjectList,
        recordSetting,
        proportions,
        recordProjectList,
        author
      }
    } else {
      let recordProjectList =
        (await $axios.$get(
          `/diathesis/project/findRecordsByParentId?parentId=${projectId}`
        )) || []
      if (!recordProjectList.length) {
        recordProjectList = []
      }
      // 如果有写实记录项目列表
      let recordSetting = {}
      if (recordProjectList.length > 0) {
        recordSetting =
          (await $axios.$get(
            `/diathesis/setting/findRecord?projectId=${recordProjectList[0] &&
              recordProjectList[0].id}`
          )) || {}
      }

      if (typeof recordProjectList === 'string') {
        recordProjectList = []
      }
      if (typeof recordSetting === 'string') {
        recordSetting = {}
      }
      const childProjectList = []
      const proportions = []
      return {
        projectList,
        projectId,
        childProjectList,
        recordSetting,
        proportions,
        recordProjectList,
        author
      }
    }
  },
  mounted() {},
  methods: {
    showAlert() {
      this.alertData = deepClone(this.projectList)
      this.category_alert_show = true
    },
    beforeProjectChangeHandler(id) {
      this.localProjectId = id
      this.$refs.nuxtChild &&
        this.$refs.nuxtChild.checkSaveHandler &&
        this.$refs.nuxtChild.checkSaveHandler()
    },
    nextHandler() {
      this.projectId = this.localProjectId
      this.transPage = !this.transPage
    },
    async getRecords() {
      let recordProjectList, recordSetting
      recordProjectList = await this.$axios.$get(
        `/diathesis/project/findRecordsByParentId?parentId=${this.projectId}`
      )
      if (recordProjectList.length) {
        // 获取写实记录项目第一项的记录
        recordSetting = await this.$axios.$get(
          `/diathesis/setting/findRecord?projectId=${recordProjectList[0].id}`
        )
      } else {
        recordProjectList = []
        recordSetting = {}
      }
      this.recordProjectList = recordProjectList
      this.recordSetting = recordSetting
    },
    async projdectSelectHandler(id) {
      const recordSetting = await this.$axios.$get(
        `/diathesis/setting/findRecord?projectId=${id}`
      )
      this.recordSetting = recordSetting
    },
    async getData(route = this.$route.path.toLowerCase()) {
      if (route === '/projectsetting') {
        let { childProjectList, proportions } = await this.$axios.$get(
          `/diathesis/project/findChildProject?parentId=${this.projectId}`
        )
        const arr = []
        childProjectList.forEach(project => {
          if (project.parentId === this.projectId) {
            const alive = arr.some(item => {
              if (item.id === project.id) {
                item.projectName = project.projectName
              }
            })
            if (!alive) {
              arr.push({
                id: project.id,
                projectName: project.projectName,
                childProjectList: []
              })
            }
          } else {
            const alive = arr.some(item => {
              if (item.id === project.parentId) {
                item.childProjectList.push({
                  ...project,
                  typeAlert: false,
                  remarkAlert: false,
                  delAlert: false
                })
                return true
              }
            })
            if (!alive) {
              arr.push({
                id: project.parentId,
                projectName: '',
                childProjectList: [
                  {
                    ...project,
                    typeAlert: false,
                    remarkAlert: false,
                    delAlert: false
                  }
                ]
              })
            }
          }
        })
        childProjectList = arr
        this.childProjectList = childProjectList
        this.proportions = proportions
      } else if (route === '/projectsetting/realisticrecordsetting') {
        let recordProjectList, recordSetting
        recordProjectList = await this.$axios.$get(
          `/diathesis/project/findRecordsByParentId?parentId=${this.projectId}`
        )
        // 如果有写实记录项目列表
        if (recordProjectList.length) {
          recordSetting = await this.$axios.$get(
            `/diathesis/setting/findRecord?projectId=${recordProjectList[0].id}`
          )
        } else {
          recordProjectList = []
          recordSetting = {}
        }
        if (typeof recordProjectList === 'string') {
          recordSetting = []
        }
        if (typeof recordSetting === 'string') {
          recordSetting = {}
        }
        this.recordProjectList = recordProjectList
        this.recordSetting = recordSetting
      }
    },
    async alertConfirm() {
      // 一级目录设置 确认
      if (JSON.stringify(this.alertData) !== JSON.stringify(this.projectList)) {
        const { success, msg } = await this.$axios.$post(
          '/diathesis/project/updateTopProjects',
          {
            diathesisIdAndNameDtoList: this.alertData
          }
        )
        if (success) {
          this.projectList = await this.$axios.$get(
            '/diathesis/project/findTopProject'
          )
          this.$warn.show({ title: '修改成功' })
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
      this.category_alert_show = false
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper_left {
  .category_etting_btn {
    margin: 20px;
  }
  .project_list {
    width: 100%;
    height: calc(100% - 72px);
    position: relative;
    .project_item {
      width: 100%;
      height: 55px;
      line-height: 55px;
      font-size: 16px;
      text-align: center;
      padding: 0 20px;
      cursor: pointer;
      &:hover {
        color: var(--primary-color);
      }
      h5 {
        width: 100%;
        height: 100%;
        box-sizing: content-box;
        border-top: 1px solid #e8e8e8;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      &.active {
        background: #347ee9;
        color: #fff;
        h5 {
          border-top: none;
        }
      }
      &:last-child {
        h5 {
          border-bottom: 1px solid #e8e8e8;
        }
      }
    }
  }
}
.first_project_setting {
  /deep/ td {
    padding: 3px 10px !important;
  }
  /deep/ th {
    font-weight: 600;
    padding: 9px 10px !important;
  }
  /deep/ .ant-table-footer {
    padding: 8px;
    background: #fff;
  }
}
</style>
