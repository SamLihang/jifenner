<template>
  <div class="wrapper">
    <global-setting
      platform="education"
      :rankItems="rankItems"
      :inputValueType="inputValueType"
      :inputTypes="inputTypes"
      :auditorTypes="auditorTypes"
      :peopleTypesMap="peopleTypesMap"
      :scoreType="scoreType"
      :rankValues="rankValues"
      :scoreScopes="scoreScopes"
    ></global-setting>
  </div>
</template>

<script>
import globalSetting from '~/components/globalSetting/index'
export default {
  name: '',
  scrollToTop: true,
  components: {
    globalSetting
  },
  data() {
    return {}
  },
  computed: {},
  async asyncData({ store, $axios }) {
    const {
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')
    return {
      rankItems,
      inputValueType,
      inputTypes,
      auditorTypes,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
    }
  },
  mounted() {},
  created() {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
  line-height: 32px;
}
</style>