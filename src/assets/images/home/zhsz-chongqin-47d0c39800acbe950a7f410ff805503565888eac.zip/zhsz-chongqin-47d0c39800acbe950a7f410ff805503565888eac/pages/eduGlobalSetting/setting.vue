<template>
  <div class="wrapper">
    <setting
      platform="education"
      :author="author"
      :rankItems="rankItems"
      :inputValueType="inputValueType"
      :mutualType="mutualType"
      :inputTypes="inputTypes"
      :auditorTypes="auditorTypes"
      :peopleTypesMap="peopleTypesMap"
      :scoreType="scoreType"
      :rankValues="rankValues"
      :scoreScopes="scoreScopes"
    ></setting>
  </div>
</template>

<script>
import setting from '~/components/globalSetting/setting'
export default {
  name: '',
  scrollToTop: true,
  components: {
    setting
  },
  data() {
    return {}
  },
  computed: {},
  watch: {},
  async asyncData({ store, $axios }) {
    const { unitType = '' } = await $axios.$get(
      '/diathesis/setting/findUserInfo'
    )
    const {
      id = '',
      author = [],
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      mutualType = '',
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')

    return {
      id,
      author,
      rankItems,
      inputValueType,
      mutualType,
      inputTypes,
      auditorTypes,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
    }
  },
  mounted() {}
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
  line-height: 32px;
}
</style>
