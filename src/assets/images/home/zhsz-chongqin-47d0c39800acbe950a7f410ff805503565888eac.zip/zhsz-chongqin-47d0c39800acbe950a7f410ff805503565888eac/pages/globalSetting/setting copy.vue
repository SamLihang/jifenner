<template>
  <div class="wrapper">
    <template v-if="showFlag">
      <wp-row>
        <wp-col :span="5" align="right">
          <h4 class="title">基本设置</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">最终评价值展示形式:</wp-col>
        <wp-col :span="10" :offset=".2">等第</wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">等第值类型:</wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-input v-model="rankItem" placeholder="录入时用/隔开。例如:A/B/C" width="100%" maxlength="20"></wp-input>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">评价值录入形式:</wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-radio v-model="inputValueType" label="G">等第</wp-radio>
          <wp-radio v-model="inputValueType" label="S">分值</wp-radio>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">
          <h4 class="title">写实记录录入设置</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">学生互评录入形式:</wp-col>
        <wp-col :span="18" :offset=".2">
          <wp-radio v-model="mutualEvaType" label="1">组内人员互评</wp-radio>
          <wp-radio v-model="mutualEvaType" label="2">小组长评价</wp-radio>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">录入人:</wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-checkbox-group v-model="inputTypes">
            <wp-checkbox
              :label="inputType"
              v-for="(inputType,index) in Object.keys(peopleTypesMap)"
              :key="index"
            >
              <span class="f16">{{peopleTypesMap[inputType]}}</span>
            </wp-checkbox>
          </wp-checkbox-group>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">审核人:</wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-checkbox-group v-model="auditorTypes">
            <wp-checkbox
              :label="auditorType"
              v-for="(auditorType,index) in Object.keys(peopleTypesMap)"
              :key="index"
            >
              <span class="f16">{{peopleTypesMap[auditorType]}}</span>
            </wp-checkbox>
          </wp-checkbox-group>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :offset="5.2" :span="10">
          <wp-button-group>
            <wp-button
              type="main"
              size="large"
              background="primary"
              :disabled="firstDisabledFlag"
              @click="next"
            >下一步</wp-button>
            <nuxt-link v-if="$store.state.globalSetting" to="/globalSetting">
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>
          </wp-button-group>
        </wp-col>
      </wp-row>
    </template>
    <template v-if="!showFlag">
      <wp-row>
        <wp-col :span="5" align="right">
          <h4 class="title">转换设置</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">等第分值转换（单项）:</wp-col>
        <wp-col :span="10" :offset=".2">
          <a-table
            :columns="columns"
            :data-source="scoreList"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template v-for="(col, index) in rankItems" :slot="col">
              <div :key="index">
                <wp-input
                  maxlength="20"
                  v-model="rankValues[index]"
                  @input="checkHandler(rankValues[index], index)"
                ></wp-input>
              </div>
            </template>
          </a-table>
          <p class="tip">
            <wp-icon name="warning" fill="#faad14" style="float:left;margin:8px 5px 0 0;"></wp-icon>分值需是正整数
          </p>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="5" align="right">
          一级指标转换依据
          <wp-tooltip position="right">
            <wp-icon name="info" fill="#faad14"></wp-icon>
            <p slot="content">转换需基于各评价人针对各一级指标的评价平均分</p>
          </wp-tooltip> :
        </wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-radio v-model="scoreType" label="S">按分数段</wp-radio>
          <wp-radio v-model="scoreType" label="P">按分数排名比例</wp-radio>
        </wp-col>
      </wp-row>
      <wp-row v-if="scoreType === 'S'">
        <wp-col :span="5" align="right">一级指标转换设置:</wp-col>
        <wp-col :span="10" :offset=".2">
          <p class="tip mb10">各评价人针对各一级指标的评价平均分转等第。</p>
          <a-table
            :columns="anotherColumns"
            :data-source="anotherData"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template slot="score" slot-scope="text, record, index">
              <div>
                <template v-if="index < anotherData.length -1">
                  <wp-input
                    v-model="scoreScope[index+1]"
                    width="150px"
                    maxlength="20"
                    type="number"
                    @input="checkInpHandler(scoreScope[index+1], index+1)"
                  ></wp-input>
                </template>
                <template v-else>
                  <p class="start_score">0</p>
                </template>
                含 -
                <wp-input
                  v-model="scoreScope[index]"
                  width="150px"
                  maxlength="20"
                  type="number"
                  @input="checkInpHandler(scoreScope[index], index)"
                ></wp-input>
              </div>
            </template>
          </a-table>
        </wp-col>
      </wp-row>
      <wp-row v-else-if="scoreType === 'P'">
        <wp-col :span="5" align="right">一级指标转换设置:</wp-col>
        <wp-col :span="10" :offset=".2">
          <a-table
            :columns="persentColumns"
            :data-source="anotherData"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template slot="score" slot-scope="text, record, index">
              <div>
                <template v-if="index > 0">
                  <wp-input
                    v-model="scoreScope[index-1]"
                    width="150px"
                    maxlength="20"
                    type="number"
                    @input="checkInpHandler(scoreScope[index], index-1)"
                  >
                    <p slot="suffix">%</p>
                  </wp-input>
                </template>
                <template v-else-if="index === 0">
                  <p class="start_score">0%</p>
                </template>
                - 含
                <wp-input
                  v-if="index < anotherData.length -1"
                  v-model="scoreScope[index]"
                  width="150px"
                  maxlength="20"
                  type="number"
                  @input="checkInpHandler(scoreScope[index], index)"
                >
                  <p slot="suffix">%</p>
                </wp-input>
                <p v-else class="start_score">100%</p>
              </div>
            </template>
          </a-table>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :offset="5.2" :span="10">
          <wp-button-group>
            <wp-button
              type="main"
              size="large"
              background="primary"
              :disabled="secondDisabledFlag"
              @click="save"
            >保存</wp-button>
            <wp-button type="second" background="primary" size="large" @click="prev">上一步</wp-button>
            <nuxt-link v-if="$store.state.globalSetting" to="/globalSetting">
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>
          </wp-button-group>
        </wp-col>
      </wp-row>
    </template>
  </div>
</template>

<script>
import { deepClone } from '~/utils/tools'
const anotherColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '对应评价平均分（保留1位小数）',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]
const persentColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '排名比例',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]

export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      showFlag: true,
      rankItem: '',
      columns: [],
      data: [],
      anotherColumns,
      persentColumns,
      anotherData: [],
      scoreScope: [],
      localScoreScope: []
    }
  },
  computed: {
    firstDisabledFlag() {
      if (
        this.rankItems.length &&
        this.inputValueType.length &&
        this.mutualEvaType.length &&
        this.inputTypes.length &&
        this.auditorTypes.length
      ) {
        return false
      } else {
        return true
      }
    },
    secondDisabledFlag() {
      if (this.rankValues.length && this.scoreScopes.length) {
        return false
      } else {
        return true
      }
    },
    scoreList() {
      const temp = []
      const map = {
        key: '0'
      }
      if (this.rankItems.length) {
        this.rankItems.forEach(item => {
          map[item] = ``
        })
      }
      temp.push(map)
      return temp
    }
  },
  watch: {
    scoreType(newVal, oldVal) {
      if (newVal) {
        this.scoreScope = []
      } else {
        this.scoreType = oldVal
      }
    },
    rankItem(newValue) {
      //firfox donot work
      // this.rankItems = newValue.match(/(?<=\/|^).{1,}?(?=\/|$)/gi) || []
      this.rankItems = newValue.split('/').filter(item => {
        return item
      })
    },
    rankItems: {
      handler: function(newValue, oldValue) {
        if (newValue.toString() === oldValue.toString()) return
        this.rankValues = []
        this.anotherData = []
        this.scoreScope = []
        this.columns = []
        newValue.forEach((item, index) => {
          this.columns.push({
            // 列标题
            title: item,
            // dataIndex的值与数据数组的名一一对应
            dataIndex: item,
            // 使用名为this.rankItems[i]的插槽来填充dataIndex的值对应的数据数组的名
            scopedSlots: { customRender: item }
          })
          this.anotherData.push({
            key: index,
            rank: item,
            score: ``
          })
        })
      }
    }
  },
  async asyncData({ store, $axios }) {
    const {
      id = '',
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      mutualEvaType = '', //学生互评录入形式
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')

    return {
      id,
      rankItems,
      inputValueType,
      mutualEvaType, //学生互评录入形式
      inputTypes,
      auditorTypes,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
    }
  },
  mounted() {},
  created() {
    this.initData()
  },
  methods: {
    initData() {
      this.rankItem = this.rankItems.join('/')
      this.$nextTick(() => {
        this.rankItems.forEach((item, index) => {
          this.columns.push({
            // 列标题
            title: item,
            // dataIndex的值与数据数组的名一一对应
            dataIndex: item,
            // 使用名为this.rankItems[i]的插槽来填充dataIndex的值对应的数据数组的名
            scopedSlots: { customRender: item }
          })
          this.anotherData.push({
            key: index,
            rank: item,
            score: ``,
            persent: ''
          })
          if (this.scoreType === 'P' && index === this.rankItems.length - 1) {
            return
          } else {
            this.scoreScope.push(
              Number(this.scoreScopes[index].split('-')[1]).toFixed(1)
            )
          }
        })
      })
    },
    next() {
      if (!this.firstDisabledFlag) {
        this.showFlag = false
      }
    },
    prev() {
      this.showFlag = true
    },
    async save() {
      if (!this.secondDisabledFlag) {
        console.log(
          JSON.stringify({
            id: this.id,
            rankItems: this.rankItems,
            rankValues: this.rankValues,
            inputValueType: this.inputValueType,
            mutualEvaType: this.mutualEvaType, //学生互评录入形式
            inputTypes: this.inputTypes,
            auditorTypes: this.auditorTypes,
            scoreScopes: this.scoreScopesHander(),
            scoreType: this.scoreType
          })
        )
        const { success, msg } = await this.$axios.$post(
          '/diathesis/setting/saveGlobal',
          {
            id: this.id,
            rankItems: this.rankItems,
            rankValues: this.rankValues,
            inputValueType: this.inputValueType,
            mutualEvaType: this.mutualEvaType, //学生互评录入形式
            inputTypes: this.inputTypes,
            auditorTypes: this.auditorTypes,
            scoreScopes: this.scoreScopesHander(),
            scoreType: this.scoreType
          }
        )
        if (success) {
          this.$warn.show({ title: '修改成功' })
          this.$router.replace({
            path: '/globalSetting'
          })
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
    },
    scoreScopesHander() {
      const temp = []
      if (this.scoreType === 'S') {
        for (let i = 0; i < this.scoreScope.length - 1; i++) {
          temp.push(`${this.scoreScope[i + 1]}-${this.scoreScope[i]}`)
        }
        temp.push(`0-${this.scoreScope[this.scoreScope.length - 1]}`)
      } else if (this.scoreType === 'P') {
        temp.push(`0-${this.scoreScope[0]}`)
        for (let i = 0; i < this.scoreScope.length - 1; i++) {
          temp.push(`${this.scoreScope[i]}-${this.scoreScope[i + 1]}`)
        }
        temp.push(`${this.scoreScope[this.scoreScope.length - 1]}-100`)
      }
      return temp
    },
    checkHandler(val, index) {
      let reg = /^[1-9]\d*$/
      if (!reg.test(val)) {
        this.$warn.show({ title: '分值需是正整数，请重新输入' })
        this.rankValues[index] = ''
      }
    },
    checkInpHandler(val, index) {
      if (!val) return
      let reg = /^\d*\.?\d?$/
      if (!reg.test(val)) {
        this.$warn.show({
          title: '平均分需是正浮点数且保留1位小数，请重新输入'
        })
        this.scoreScope[index] = ''
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
  line-height: 32px;
}
.title {
  display: inline-block;
  padding-left: 12px;
  margin-top: 30px;
  border-left: 5px solid var(--primary-color);
  font-size: 18px;
  line-height: 18px;
}
.tip {
  color: #999;
}
.mb10 {
  margin-bottom: 10px;
}
.f16 {
  font-size: 14px;
}
.start_score {
  display: inline-block;
  width: 150px;
  padding-left: 10px;
}
</style>
