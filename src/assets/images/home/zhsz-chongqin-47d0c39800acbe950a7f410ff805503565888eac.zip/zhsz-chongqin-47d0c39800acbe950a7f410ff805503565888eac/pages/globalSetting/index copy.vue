<template>
  <div class="wrapper">
    <wp-row>
      <wp-col :span="5" align="right">
        <h4 class="title">基本设置</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">最终评价值展示形式:</wp-col>
      <wp-col :span="10" :offset="0.2">等第</wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">等第值类型:</wp-col>
      <wp-col :span="10" :offset="0.2">{{ rankItems.join('/') }}</wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">评价值录入形式:</wp-col>
      <wp-col :span="10" :offset="0.2">
        {{
        inputValueType.replace('S', '分值').replace('G', '等第')
        }}
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">
        <h4 class="title">写实记录录入设置</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">录入人:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <span class="f16" v-for="(inputType,index) in inputTypes" :key="index">
          {{peopleTypesMap[inputType]}}
          <span v-if="index < inputTypes.length-1">，</span>
        </span>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">审核人:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <span class="f16" v-for="(auditorType,index) in auditorTypes" :key="index">
          {{peopleTypesMap[auditorType]}}
          <span v-if="index < auditorTypes.length-1">，</span>
        </span>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">
        <h4 class="title">转换设置</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">等第分值转换（单项）:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <a-table
          :columns="columns"
          :data-source="data"
          :pagination="false"
          bordered
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">
        一级指标转换依据
        <wp-tooltip position="right">
          <wp-icon name="info" fill="#faad14"></wp-icon>
          <p slot="content">转换需基于各评价人针对各一级指标的评价平均分</p>
        </wp-tooltip> :
      </wp-col>
      <wp-col :span="10" :offset="0.2">
        <p v-if="scoreType === 'S'">按分数段</p>
        <p v-else-if="scoreType === 'P'">按分数排名比例</p>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="5" align="right">一级指标转换设置:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <p class="tip mb10">各评价人针对各一级指标的评价平均分转等第。</p>
        <a-table
          v-if="scoreType === 'S'"
          :columns="anotherColumns"
          :data-source="anotherData"
          :pagination="false"
          bordered
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
        <a-table
          v-if="scoreType === 'P'"
          :columns="persentColumns"
          :data-source="anotherData"
          :pagination="false"
          bordered
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :offset="5.2" :span="5">
        <nuxt-link to="/globalSetting/setting">
          <wp-button type="main" background="primary" size="large">修改</wp-button>
        </nuxt-link>
      </wp-col>
    </wp-row>
  </div>
</template>

<script>
const anotherColumns = [
  {
    title: '等第',
    dataIndex: 'rank'
  },
  {
    title: '对应评价平均分（保留1位小数）',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]

const persentColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '排名比例',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]

export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      anotherColumns,
      persentColumns
    }
  },
  computed: {
    columns() {
      const temp = []
      this.rankItems.forEach(item => {
        temp.push({
          title: item,
          dataIndex: item,
          scopedSlots: { customRender: item }
        })
      })
      return temp
    },
    data() {
      const temp = []
      const map = Object.create(null)
      for (let i = 0; i < this.rankItems.length; i++) {
        map[this.rankItems[i]] = this.rankValues[i]
      }
      temp.push(map)
      return temp
    },
    anotherData() {
      const temp = []
      if (this.scoreType === 'S') {
        for (let i = 0; i < this.rankItems.length; i++) {
          temp.push({
            key: i,
            rank: this.rankItems[i],
            score: this.scoreScopes[i]
          })
        }
      } else if (this.scoreType === 'P') {
        for (let i = 0; i < this.rankItems.length; i++) {
          let score = this.scoreScopes[i]
            .split('-')
            .map(item => {
              return `${item}%`
            })
            .join('-')
          temp.push({
            key: i,
            rank: this.rankItems[i],
            score: score
          })
        }
      }
      return temp
    },
  },
  async asyncData({ store, $axios }) {
    const {
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')
    return {
      rankItems,
      inputValueType,
      inputTypes,
      auditorTypes,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
    }
  },
  mounted() {},
  created() {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
  line-height: 32px;
}
.title {
  padding-left: 12px;
  margin-top: 30px;
  border-left: 5px solid var(--primary-color);
  font-size: 18px;
  line-height: 18px;
  display: inline-block;
}
.tip {
  color: #999;
}
.mb10 {
  margin-bottom: 10px;
}
.f16 {
  font-size: 14px;
}
</style>
