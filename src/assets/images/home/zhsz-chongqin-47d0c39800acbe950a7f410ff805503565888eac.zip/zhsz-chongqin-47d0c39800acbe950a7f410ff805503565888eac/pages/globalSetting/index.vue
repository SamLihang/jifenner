<template>
  <div class="wrapper">
    <global-setting
      platform="school"
      :author="author"
      :rankItems="rankItems"
      :inputValueType="inputValueType"
      :inputTypes="inputTypes"
      :mutualType="mutualType"
      :auditorTypes="auditorTypes"
      :peopleTypesMap="peopleTypesMap"
      :scoreType="scoreType"
      :rankValues="rankValues"
      :scoreScopes="scoreScopes"
    ></global-setting>
  </div>
</template>

<script>
import globalSetting from '~/components/globalSetting/index'
export default {
  name: '',
  scrollToTop: true,
  components: {
    globalSetting
  },
  data() {
    return {}
  },
  computed: {},
  async asyncData({ store, $axios }) {
    const {
      author = [],
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      mutualType = 'M',
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')
    return {
      author,
      rankItems,
      inputValueType,
      inputTypes,
      auditorTypes,
      mutualType,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
    }
  },
  mounted() {},
  created() {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
  line-height: 32px;
}
</style>
