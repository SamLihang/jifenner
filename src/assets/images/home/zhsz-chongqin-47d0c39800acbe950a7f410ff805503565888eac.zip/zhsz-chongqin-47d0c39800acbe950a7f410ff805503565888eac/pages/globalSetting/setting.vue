<template>
  <div class="wrapper">
    <setting
      platform="school"
      :author="author"
      :rankItems="rankItems"
      :inputValueType="inputValueType"
      :mutualType="mutualType"
      :inputTypes="inputTypes"
      :auditorTypes="auditorTypes"
      :peopleTypesMap="peopleTypesMap"
      :scoreType="scoreType"
      :rankValues="rankValues"
      :scoreScopes="scoreScopes"
    ></setting>
  </div>
</template>

<script>
import setting from '~/components/globalSetting/setting'
export default {
  name: '',
  scrollToTop: true,
  components: {
    setting
  },
  data() {
    return {}
  },
  computed: {},
  watch: {},
  async asyncData({ store, $axios }) {
    // let platform = 'school'
    // const { unitType = '' } = await $axios.$get(
    //   '/diathesis/setting/findUserInfo'
    // )
    // if (unitType === '1') {
    //   platform = 'education'
    // } else {
    //   platform = 'school'
    // }
    const {
      id = '',
      author = [],
      rankItems = [],
      rankValues = [],
      inputValueType = '',
      mutualType = '',
      inputTypes = [],
      auditorTypes = [],
      peopleTypesMap = {},
      scoreType = 'S',
      scoreScopes = []
    } = await $axios.$get('/diathesis/setting/findGlobal')

    return {
      id,
      author,
      rankItems,
      inputValueType,
      mutualType,
      inputTypes,
      auditorTypes,
      peopleTypesMap,
      scoreType,
      rankValues,
      scoreScopes
      //platform
    }
  },
  methods: {}
}
</script>

<style lang="scss" scoped>
.wrapper {
  font-size: 14px;
}
.title {
  display: inline-block;
  padding-left: 12px;
  margin-top: 30px;
  border-left: 5px solid var(--primary-color);
  font-size: 18px;
  line-height: 18px;
}
.tip {
  color: #999;
}
.mb10 {
  margin-bottom: 10px;
}
.f16 {
  font-size: 14px;
}
.start_score {
  display: inline-block;
  width: 150px;
  padding-left: 10px;
}
</style>
