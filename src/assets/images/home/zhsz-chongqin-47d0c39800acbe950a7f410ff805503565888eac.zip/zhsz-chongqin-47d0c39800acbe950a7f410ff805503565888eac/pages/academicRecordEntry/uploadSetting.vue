<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <!-- 头部搜索 -->
    <div class="subject_title">
      <div class="subject_title_btn">
        <wp-button-group related>
          <wp-button>导入成绩</wp-button>
          <wp-button @click="btnulshow = true" v-clickoutside="handleClose">
            <wp-icon name="angle-single-down" fill="#fff"></wp-icon>
          </wp-button>
        </wp-button-group>
        <ul class="subject_btn_ul" v-show="btnulshow">
          <li @click="getsubject">获取考试成绩</li>
          <li @click="alert_credit">获取学分</li>
          <li @click="alert_credit">获取负责人</li>
        </ul>
      </div>
      <div class="subject_title_item">年级：高一(2011级)</div>
      <div class="subject_title_item">类型：必修课</div>
      <div class="subject_title_item">学期：高一上</div>
      <div class="subject_title_item">
        <span>班级：</span>
        <wp-select width="100px" v-model="slected" size="base" :data="selectData1"></wp-select>
      </div>
      <wp-mixer>
        <wp-select width="100px" v-model="slected" size="base" :data="selectData1"></wp-select>
        <wp-input placeholder="请输入" width="150px" maxlength="10"></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999"></wp-icon>
        </wp-button>
      </wp-mixer>
    </div>
    <!-- 表格 -->
    <div class="subject_body">
      <a-table :columns="columns" bordered :dataSource="scoredata" :scroll="{ x: '130%'}"></a-table>
      <div class="subject_no_content">
        <img src="~/assets/image/subject/nocontent.png" />
        <div class="subject_no_title">录入成绩科目按以上表格内容信息展示，也可自定义设置</div>
        <div>
          <wp-button type="second" background="primary" @click="changeinstall">去设置</wp-button>
          <wp-button>导入成绩</wp-button>
        </div>
      </div>
    </div>
    <!-- 科目设置 -->
    <div class="subject_install_box clearfix" :style="installshow ? 'right: 0' : 'right: -380px'">
      <div class="subject_install_left">
        <wp-button style="width: 100px;" @click="changeinstall">&gt; 科目设置</wp-button>
      </div>
      <div class="subject_install_right">
        <div class="subject_install_title">
          <wp-row>
            <wp-col class="col install_title_left" :span="12">录入科目设置</wp-col>
            <wp-col class="col" :span="12">
              <div class="install_title_right">
                <wp-icon name="info" fill="#FAAD14" style="font-size:12px;"></wp-icon>
                <span>每项至少选择1个</span>
              </div>
            </wp-col>
          </wp-row>
        </div>
        <wp-scrollbar style="height: 540px">
          <div class="install_content_title">科目：</div>
          <div>
            <wp-checkbox
              v-for="item in subjectList"
              :key="item.courseId"
              v-model="item.slected"
              type="button"
            >{{item.courseName}}</wp-checkbox>
          </div>
          <div class="install_content_title">类型：</div>
          <div>
            <wp-checkbox
              v-for="item in typeList"
              :key="item.id"
              v-model="item.slected"
              type="button"
            >{{item.name}}</wp-checkbox>
          </div>
          <wp-button type="block" background="primary" class="install_content_btn">确定</wp-button>
        </wp-scrollbar>
      </div>
    </div>
    <div class="subject_install_body" v-show="installshow" @click="installshow = false"></div>
    <wp-alert
      :visible="get_subject_show"
      title="获取考试成绩"
      @close="get_subject_show = false"
      @confirm="get_subject_show = false"
      width="600px"
    >
      <div slot="default">
        <div class="subject_modal_top">
          <wp-radio v-model="radio_subject" :label="1" type="button">2015-2016学年第一学期高一期中考试</wp-radio>
          <wp-radio v-model="radio_subject" :label="2" type="button">2015-2016学年第一学期高一期中考试</wp-radio>
          <wp-radio v-model="radio_subject" :label="3" type="button">2015-2016学年第一学期高一期中考试</wp-radio>
        </div>
        <div class="subject_modal_down">包含科目：</div>
        <div class="subject_modal_span">
          <wp-tag
            type="hollow"
            border-color="#C1DDF2"
            color="#317EEB"
            background="#E7F3FC"
            v-for="item in subject_score_list"
            :key="item.id"
          >{{item.name}}</wp-tag>
        </div>
      </div>
    </wp-alert>
  </div>
</template>

<script>
const clickoutside = {
  // 初始化指令
  bind(el, binding, vnode) {
    function documentHandler(e) {
      // 这里判断点击的元素是否是本身，是本身，则返回
      if (el.contains(e.target)) {
        return false
      }
      // 判断指令中是否绑定了函数
      if (binding.expression) {
        // 如果绑定了函数 则调用那个函数，此处binding.value就是handleClose方法
        binding.value(e)
      }
    }
    // 给当前元素绑定个私有变量，方便在unbind中可以解除事件监听
    el.__vueClickOutside__ = documentHandler
    document.addEventListener('click', documentHandler)
  },
  update() {},
  unbind(el, binding) {
    // 解除事件监听
    document.removeEventListener('click', el.__vueClickOutside__)
    delete el.__vueClickOutside__
  }
}
export default {
  components: {},
  directives: { clickoutside },
  data() {
    return {
      installshow: false, //录入科目设置弹窗
      btnulshow: false, //按钮弹窗
      get_subject_show: false, //获取成绩弹窗
      radio_subject: 1, //获取成绩的学期
      subject_score_list: [
        {
          name: '物理',
          id: 1
        },
        {
          name: '英语',
          id: 2
        },
        {
          name: '生物',
          id: 3
        }
      ],
      selectData1: ['选项一', '选项二', '选项三', '选项四', '选项五'],
      slected: '',
      //表格头部
      columns: [
        {
          title: '序号',
          dataIndex: 'index',
          fixed: 'left',
          width: 100
        },
        {
          title: '学生姓名',
          dataIndex: 'studentName',
          fixed: 'left',
          width: 100
        },
        {
          title: '学号',
          dataIndex: 'studentNumber',
          fixed: 'left',
          width: 100
        },
        {
          title: '性别',
          dataIndex: 'sex',
          fixed: 'left',
          width: 100
        },
        {
          title: '班级',
          dataIndex: 'class',
          fixed: 'left',
          width: 100
        },
        {
          title: '语文',
          children: [
            {
              title: '成绩',
              dataIndex: 'yuscore'
            },
            {
              title: '学分',
              dataIndex: 'yucredit'
            }
          ]
        },
        {
          title: '数学',
          children: [
            {
              title: '成绩',
              dataIndex: 'shuscore'
            },
            {
              title: '学分',
              dataIndex: 'shucredit'
            }
          ]
        },
        {
          title: '英语',
          children: [
            {
              title: '成绩',
              dataIndex: 'yinscore'
            },
            {
              title: '学分',
              dataIndex: 'yincredit'
            }
          ]
        },
        {
          title: '物理',
          children: [
            {
              title: '成绩',
              dataIndex: 'wuscore'
            },
            {
              title: '学分',
              dataIndex: 'wucredit'
            }
          ]
        },
        {
          title: '化学',
          children: [
            {
              title: '成绩',
              dataIndex: 'huascore'
            },
            {
              title: '学分',
              dataIndex: 'huacredit'
            }
          ]
        }
      ],
      //表格数据
      scoredata: [
        // {
        //   index: 1,
        //   studentName: '姥姥',
        //   studentNumber: '001',
        //   sex: '男',
        //   class: '一班',
        //   yuscore: 11,
        //   yucredit: 22,
        //   shuscore: 11,
        //   shucredit: 22
        // }
      ],
      subjectList: [
        {
          courseName: '语文',
          courseId: 1,
          slected: true
        },
        {
          courseName: '数学',
          courseId: 2,
          slected: true
        },
        {
          courseName: '英语',
          courseId: 3,
          slected: false
        },
        {
          courseName: '英语',
          courseId: 4,
          slected: false
        },
        {
          courseName: '英语',
          courseId: 5,
          slected: false
        }
      ],
      typeList: [
        {
          id: 1,
          name: '成绩',
          slected: true
        },
        {
          id: 2,
          name: '学分',
          slected: true
        },
        {
          id: 3,
          name: '绩点',
          slected: true
        },
        {
          id: 4,
          name: '负责人',
          slected: false
        }
      ]
    }
  },
  computed: {},
  async mounted() {},
  methods: {
    //关闭导入成绩弹窗
    handleClose(e) {
      this.btnulshow = false
    },
    //获取考试成绩
    getsubject() {
      this.get_subject_show = true
    },
    //录入科目设置弹窗
    changeinstall() {
      this.installshow = !this.installshow
    },
    //获取学分
    alert_credit() {
      this.$alert.show({
        width: 450,
        type: 'warning',
        title: '提示',
        message: '存在2门科目数据未获取成功',
        description: '物理、化学',
        closeCallBack: () => {
          this.$alert.hide()
        },
        confirmCallBack: () => {
          this.$alert.hide()
        }
      })
    }
  },
  watch: {}
}
</script>
<style lang="scss">
.iframe-outter {
  overflow: hidden !important;
}
.wp-radio--button .wp-radio__text {
  font-size: 14px;
  line-height: 14px;
}
.wp-radio + .wp-radio--button {
  margin-left: 0;
  margin-bottom: 4px;
}
.wp-checkbox__text {
  padding-left: 0;
}
.wp-radio--button {
  padding: 5px 16px;
}
</style>
<style lang="scss" scoped>
.wrapper {
  position: initial;
}
.subject_title {
  .subject_title_item {
    line-height: 32px;
    float: left;
    margin-right: 20px;
    > span {
      font-size: 14px;
    }
  }
  .subject_title_btn {
    margin-right: 20px;
    float: left;
    position: relative;
    padding-left: 10px;
    .subject_btn_ul {
      position: absolute;
      background: #ffffff;
      border: 1px solid #cccccc;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
      border-radius: 4px;
      width: 112px;
      left: 0px;
      top: 36px;
      z-index: 100;
      > li {
        height: 32px;
        padding-left: 9px;
        line-height: 32px;
        cursor: pointer;
      }
      > li:hover {
        background: #e7f3fc;
      }
    }
  }
}
.subject_body {
  margin-top: 10px;
}

.subject_install_body {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 999;
  background: rgba(0, 0, 0, 0.5);
}
.subject_install_box {
  height: 620px;
  position: absolute;
  top: 20px;
  right: -20px;
  transition: all 0.8s;
  z-index: 1000;
  .subject_install_left {
    float: left;
    padding-top: 10px;
  }
  .subject_install_right {
    float: left;
    background: #ffffff;
    box-shadow: 0 1px 4px 0 #cfd2d4;
    border-radius: 4px 0 0 4px;
    width: 380px;
    height: 100%;
    padding: 20px;
    .subject_install_title {
      border-bottom: 1px solid #e8e8e8;
      padding-bottom: 16px;
      .install_title_left {
        font-size: 16px;
        color: #333333;
      }
      .install_title_right {
        font-size: 12px;
        color: #faad14;
        text-align: right;
        line-height: 24px;
        > span {
          position: relative;
          top: 1px;
        }
      }
    }
    .install_content_title {
      font-size: 14px;
      color: #333333;
      padding: 16px 0 8px 0;
    }
    .wp-checkbox {
      margin-right: 10px;
      .wp-checkbox__text {
        padding-left: 0;
      }
    }
    .install_content_btn {
      margin-top: 30px;
    }
  }
}
.subject_modal_top > div {
  margin-bottom: 10px;
}
.subject_modal_down {
  font-size: 14px;
  color: #999999;
  padding: 8px 0;
}
.subject_modal_span > span {
  margin-right: 5px;
}
.ant-table td {
  white-space: nowrap;
}
.subject_no_content {
  text-align: center;
  padding-top: 60px;
  background: #ffffff;
  position: relative;
  width: 100%;
  top: -55px;
  z-index: 99;
  .subject_no_title {
    color: #999999;
    padding: 15px 0 12px 0;
  }
}
</style>
