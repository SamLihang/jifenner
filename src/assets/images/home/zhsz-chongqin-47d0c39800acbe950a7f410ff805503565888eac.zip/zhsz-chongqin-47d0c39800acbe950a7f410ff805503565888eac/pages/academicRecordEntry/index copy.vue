<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <wp-col>
        <p class="notice">每学年学期每种类型仅限录一份成绩，多次录入将覆盖之前的成绩。</p>
      </wp-col>
    </wp-row>
    <wp-row>
      <a-table
        bordered
        key="gradeId"
        :columns="columns"
        :data-source="gradeList"
        :pagination="false"
        :locale="{emptyText: '暂无数据'}"
      >
        <template slot="entry" slot-scope="text, record">
          <router-link
            :to="{path: 'academicrecordentry/upload', query: {gradeId: record.gradeId ,scoreType: record.scoreType}}"
          >导入</router-link>
        </template>
      </a-table>
    </wp-row>
  </div>
</template>

<script>
import { formatSemester, formatScoreType } from '~/utils/format'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      columns: [
        {
          title: '年级',
          dataIndex: 'gradeName',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        },
        {
          title: '级别',
          dataIndex: 'year',
          customRender: (text, row, index) => {
            return {
              children: text,
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        },
        {
          title: '学期',
          dataIndex: 'semester',
          customRender: (text, row, index) => {
            return {
              children: formatSemester(text),
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        },
        {
          title: '类型',
          dataIndex: 'scoreType',
          customRender: text => {
            return { children: formatScoreType(text) }
          }
        },
        {
          title: '考试成绩',
          dataIndex: 'scoreName',
          customRender: text => {
            return {
              children: text === '无' ? <p style="color: #999">{text}</p> : text
            }
          }
        },
        {
          title: '录入时间',
          dataIndex: 'importTime',
          customRender: text => {
            return { children: text ? text : <p style="color: #999">—</p> }
          }
        },
        { title: '导入成绩', scopedSlots: { customRender: 'entry' } },
        {
          customRender: (text, row, index) => {
            return {
              children: this.$createElement('a', {
                domProps: {
                  innerHTML: '查看',
                  href: 'javascript:void(0)'
                },
                on: {
                  click: () => {
                    this.detailHandler(row)
                  }
                }
              }),
              attrs: {
                rowSpan: row.scoreLength || 0
              }
            }
          }
        }
      ]
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let { gradeList = [] } = await $axios.$get('/diathesis/subject/gradeList')
    if (gradeList.length) {
      const arr = []
      gradeList.forEach(grade => {
        grade.scoreList.forEach((score, index) => {
          arr.push({
            gradeId: grade.gradeId,
            gradeName: grade.gradeName,
            gradeCode: grade.gradeCode,
            year: grade.year,
            semester: grade.semester,
            scoreId: score.scoreId,
            scoreType: score.scoreType,
            scoreName: score.scoreName,
            importTime: score.importTime,
            scoreLength: index === 0 ? grade.scoreList.length : 0
          })
        })
      })
      gradeList = arr
    }
    return { gradeList }
  },
  mounted() {
    // console.log(this.gradeList)
  },
  methods: {
    detailHandler(row) {
      this.$router.push({
        path: '/academicrecordentry/detail',
        query: { ...row }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.notice {
  color: var(--primary-color);
  padding: 10px;
  background: #e6f7ff;
  border: 1px solid #9bc9ff;
  border-radius: 4px;
}
</style>
