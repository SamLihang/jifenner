<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row>
      <wp-col>
        <p class="notice">每学年学期每种类型仅限录一份成绩，多次录入将覆盖之前的成绩。</p>
      </wp-col>
    </wp-row>
    <wp-row class="record_box">
      <wp-col
        :span="12"
        v-for="(item, index) in gradeList"
        :key="item.gradeCode + index"
        style="margin-bottom:20px;"
      >
        <div class="record_item">
          <div
            class="record_item_left"
            :class="item.scoreType === '2' ? 'scoreType2' : ''"
            @click="detailHandler(item)"
          >{{item.gradeName}}{{item.scoreType === '1' ? '必修' : '选修'}}</div>
          <div class="record_item_center">
            <div class="item_center_title">第{{item.semester === '1' ? '一' : '二'}}学期</div>
            <div class="item_center_body" v-if="item.unCompletedSub.length > 0">
              <span class="item_span">未完成：</span>
              <span class="label_more_box" ref="labelbox">
                <span v-for="minitem in item.unCompletedSub" :key="minitem">
                  <wp-tag
                    type="hollow"
                    border-color="#C1DDF2"
                    color="#317EEB"
                    background="#E7F3FC"
                    style="margin-right: 5px;margin-bottom:4px;word-break: break-all;"
                    :title="minitem"
                  >{{minitem}}</wp-tag>
                </span>
              </span>
              <wp-popover trigger="hover" class="label_more">
                <wp-tag
                  type="hollow"
                  border-color="#C1DDF2"
                  color="#317EEB"
                  background="#E7F3FC"
                  style="cursor:pointer;"
                  class="more-tip"
                >...</wp-tag>
                <div slot="content">
                  <p class="more_p">
                    <span v-for="(minitem,minindex) in item.unCompletedSub" :key="minindex">
                      <wp-tag
                        type="hollow"
                        border-color="#C1DDF2"
                        color="#317EEB"
                        background="#E7F3FC"
                        style="margin-right: 5px;margin-bottom:4px;word-break: break-all;"
                        v-if="minindex > labelarr[index]"
                      >{{minitem}}</wp-tag>
                    </span>
                  </p>
                </div>
              </wp-popover>
            </div>
            <div
              class="item_center_body item_center_body1"
              v-else-if="item.type === '0'"
            >您未录入过科目，请开始你的录入吧</div>
            <div class="item_center_body item_center_body1" v-else>您已完成所有科目录入</div>
            <div class="item_center_time">更新时间：{{item.importTime ? item.importTime : '无'}}</div>
          </div>
          <div class="record_item_right">
            <template v-if="item.type === '1'">
              <router-link
                :to="{path: 'academicrecordentry/upload', query: {gradeId: item.gradeId ,scoreType: item.scoreType}}"
              >
                <wp-button type="second" background="primary">继续录入</wp-button>
              </router-link>
            </template>
            <template v-else>
              <router-link
                :to="{path: 'academicrecordentry/upload', query: {gradeId: item.gradeId ,scoreType: item.scoreType}}"
              >
                <wp-button>开始录入</wp-button>
              </router-link>
            </template>
          </div>
        </div>
      </wp-col>
    </wp-row>
    <div class="nocontent" v-if="gradeList.length <= 0">
      <img src="~/assets/image/subject/nocontent.png" />
      <div class="nocontent_title">暂无成绩信息，联系管理员设置哦</div>
    </div>
    <!-- <div>
      <wp-button type="second" background="primary">历史数据</wp-button>
    </div>-->
  </div>
</template>

<script>
import { formatSemester, formatScoreType } from '~/utils/format'
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      labelarr: {}
    }
  },
  computed: {},
  async asyncData({ $axios }) {
    let { gradeList = [] } = await $axios.$get('/diathesis/subject/gradeList')
    if (gradeList.length) {
      const arr = []
      gradeList.forEach(grade => {
        grade.scoreList.forEach((score, index) => {
          arr.push({
            gradeId: grade.gradeId,
            gradeName: grade.gradeName,
            gradeCode: grade.gradeCode,
            year: grade.year,
            semester: grade.semester,
            scoreId: score.scoreId,
            scoreType: score.scoreType,
            scoreName: score.scoreName,
            importTime: score.importTime,
            type: score.type,
            scoreLength: index === 0 ? grade.scoreList.length : 0,
            unCompletedSub: score.unCompletedSub ? score.unCompletedSub : []
          })
        })
      })
      gradeList = arr
    }
    return { gradeList }
  },
  mounted() {
    let that = this
    setTimeout(function() {
      that.temp()
    }, 10)
    window.onresize = function temp() {
      that.labelarr = {}
      that.$refs.labelbox &&
        that.$refs.labelbox.forEach((v, index) => {
          let boxwidth = v.getBoundingClientRect().width
          let showuindex = 0
          let islong = false
          let addwidth = 0
          for (let i = 0; i < v.children.length; i++) {
            addwidth = addwidth + v.children[i].getBoundingClientRect().width
            if (addwidth > boxwidth - 32) {
              islong = true
              showuindex = i - 1
              addwidth = addwidth - v.children[i].getBoundingClientRect().width
              break
            }
          }
          if (showuindex === 0 && !islong) {
            v.nextElementSibling.style.display = 'none'
          } else {
            v.nextElementSibling.style.display = 'inline-block'
          }
          v.nextElementSibling.style.left = addwidth + 56 + 'px'
          let keyindex = 0
          that.gradeList.forEach((minitem, minindex) => {
            if (minitem.unCompletedSub.length > 0) {
              keyindex++
            }
            if (keyindex - 1 == index) {
              that.labelarr[minindex] = showuindex
            }
          })
        })
    }
  },
  methods: {
    temp() {
      let that = this
      that.labelarr = {}
      that.$refs.labelbox &&
        that.$refs.labelbox.forEach((v, index) => {
          let boxwidth = v.getBoundingClientRect().width
          let showuindex = 0
          let islong = false
          let addwidth = 0
          for (let i = 0; i < v.children.length; i++) {
            addwidth = addwidth + v.children[i].getBoundingClientRect().width
            if (addwidth > boxwidth - 32) {
              islong = true
              showuindex = i - 1
              addwidth = addwidth - v.children[i].getBoundingClientRect().width
              break
            }
          }
          if (showuindex === 0 && !islong) {
            v.nextElementSibling.style.display = 'none'
          } else {
            v.nextElementSibling.style.display = 'inline-block'
          }
          v.nextElementSibling.style.left = addwidth + 56 + 'px'
          let keyindex = 0
          that.gradeList.forEach((minitem, minindex) => {
            if (minitem.unCompletedSub.length > 0) {
              keyindex++
            }
            if (keyindex - 1 == index) {
              that.labelarr[minindex] = showuindex
            }
          })
        })
    },
    detailHandler(row) {
      this.$router.push({
        path: '/academicrecordentry/detail',
        query: { ...row }
      })
    },
    formatOption(structure) {
      return structure.join(',')
    }
  }
}
</script>
<style lang="scss" scoped>
.notice {
  color: #666666;
  padding: 6px 20px;
  background: #e7f3fc;
  border: 1px solid #c1ddf2;
  border-radius: 2px;
}
.record_box .wp-col:nth-child(odd) .record_item {
  margin-right: 10px;
}
.record_box .wp-col:nth-child(even) .record_item {
  margin-left: 10px;
}
.record_item {
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: relative;
  .record_item_left {
    width: 170px;
    height: 120px;
    display: inline-block;
    text-align: center;
    font-size: 22px;
    color: #ffffff;
    line-height: 120px;
    background-size: 100% 100%;
    background-image: url(~assets/image/academicRecord/obligatory.png);
    cursor: pointer;
  }
  .record_item_left.scoreType2 {
    background-image: url(~assets/image/academicRecord/course.png);
  }
  .record_item_center {
    height: 120px;
    display: inline-block;
    width: calc(100% - 180px);
    vertical-align: top;
    padding: 16px 0 16px 20px;
    .item_center_title {
      padding: 4px 0;
    }
    .item_center_time {
      color: #999999;
      padding: 4px 0;
    }
    .item_span {
      font-size: 14px;
      color: #333333;
      line-height: 26px;
      display: inline-block;
      margin-bottom: 4px;
    }
    .item_center_body {
      padding: 4px 0;
      overflow: hidden;
      white-space: pre-wrap;
      height: 32px;
      position: relative;
      padding-right: 80px;
    }
    .item_center_body1 {
      height: auto;
      max-height: 42px;
    }
  }
  .record_item_right {
    height: 120px;
    position: absolute;
    right: 10px;
    top: 44px;
  }
}
.record_item:hover {
  border: 1px solid #317eeb;
}
.label_more_box {
  display: inline-block;
  height: 28px;
  overflow: hidden;
  vertical-align: middle;
  padding-right: 32px;
  width: calc(100% - 62px);
  white-space: initial;
}
.label_more {
  position: absolute;
  top: 4px;
}
.more_p {
  max-width: 600px;
}
</style>
