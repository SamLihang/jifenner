<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <wp-row class="title">
      <div class="title_item wp_fl" style="line-height: 32px">年级：{{ gradeName }}</div>
      <div class="title_item wp_fl" style="line-height: 32px">级别：{{ year }}</div>
      <div class="title_item wp_fl">
        学期：
        <!-- <wp-select v-model="semester" :data="semesterList" value-key="value" label-key="label"></wp-select> -->
        <wp-select v-model="acadyear" :data="acadyearName"></wp-select>
      </div>
      <div class="title_item wp_fl">
        成绩类型：
        <wp-select v-model="scoreType" :data="scoreTypeList" value-key="value" label-key="label"></wp-select>
      </div>
      <div class="title_item wp_fl">
        班级：
        <wp-select v-model="classId" :data="classList" value-key="classId" label-key="className"></wp-select>
      </div>
      <wp-mixer size="base">
        <wp-select v-model="searchMode" :data="searchList" width="100px"></wp-select>
        <wp-input
          placeholder="请输入"
          width="200px"
          maxlength="20"
          v-on:keyup.enter.native="getData"
          v-model="searchKey"
        ></wp-input>
        <wp-button type="second" background="primary">
          <wp-icon name="search" fill="#999" @click.native="getData"></wp-icon>
        </wp-button>
      </wp-mixer>
    </wp-row>
    <wp-row style="position:relative;">
      <a-table
        bordered
        :scroll="{x: columns.length > 10 ? '1000px' : null}"
        key="studentId"
        class="detail_table"
        :data-source="studentList"
        :columns="columns"
        :loading="loading"
        :pagination="total > 10 ? { current: pageIndex, pageSize: pageSize, total: total || 0, showQuickJumper: true, showSizeChanger:true } : false"
        :locale="{emptyText: '暂无数据'}"
        @change="tableChangeHandler"
      ></a-table>
      <div class="subject_no_content" v-if="studentList.length <= 0">
        <img src="~/assets/image/subject/nocontent.png" />
        <div class="subject_no_title">录入成绩科目按以上表格内容信息展示</div>
        <div>
          <router-link
            :to="{path: '/academicrecordentry/upload', query: {gradeId: gradeId ,scoreType: scoreType}}"
          >
            <wp-button>录入成绩</wp-button>
          </router-link>
        </div>
      </div>
    </wp-row>
  </div>
</template>

<script>
import { formatGradeCode, formatSemesterName } from '~/utils/format'
function formatStudentList(studentList) {
  if (!studentList || !studentList.length) return
  return Array.from(studentList, scoreInfo => {
    const obj = {
      sex: scoreInfo.sex,
      className: scoreInfo.className,
      studentId: scoreInfo.studentId,
      studentCode: scoreInfo.studentCode,
      studentName: scoreInfo.studentName
    }
    scoreInfo.scoreList.forEach((item, index) => {
      obj[`score${index}`] = item
    })
    return obj
  })
}
const pageIndex = 1,
  pageSize = 10
export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      pageIndex,
      pageSize,
      courseList: [],
      loading: false,
      searchKey: '',
      searchMode: '姓名',
      searchList: ['姓名', '学号'],
      gradeName: this.$route.query.gradeName || '',
      year: this.$route.query.year || '',
      scoreType: this.$route.query.scoreType || '',
      scoreTypeList: [
        { value: '1', label: '必修课' },
        { value: '2', label: '选修课' }
      ],
      semesterList: [
        {
          value: '1',
          label: '第一学期'
        },
        {
          value: '2',
          label: '第二学期'
        }
      ]
    }
  },
  computed: {
    studentName() {
      if (this.searchMode === '姓名') {
        return this.searchKey
      } else {
        return ''
      }
    },
    studentCode() {
      if (this.searchMode === '学号') {
        return this.searchKey
      } else {
        return ''
      }
    },
    columns() {
      const columnsList = [
        {
          title: '序号',
          customRender: (text, row, index) => {
            return {
              children: (this.pageIndex - 1) * this.pageSize + index + 1
            }
          }
        },
        {
          title: '学生姓名',
          dataIndex: 'studentName'
        },
        {
          title: '学号',
          dataIndex: 'studentCode'
        },
        {
          title: '性别',
          dataIndex: 'sex'
        },
        {
          title: '班级',
          dataIndex: 'className'
        }
      ]
      this.courseList &&
        this.courseList.forEach((course, index) => {
          columnsList.push({
            title: course,
            dataIndex: `score${index}`,
            customRender: text => {
              return {
                children: text === '无' ? '' : text
              }
            }
          })
        })
      return columnsList
    }
  },
  async asyncData({ $axios, query }) {
    let total = 0
    const { gradeId, scoreType, semester, gradeCode } = query
    let { classList = [] } = await $axios.$get(
      `/diathesis/classList?gradeId=${gradeId}`
    )
    const classId = classList.length ? classList[0].classId : ''
    if (classId) {
      var {
        studentList = [],
        courseList = [],
        page = {},
        acadyearName = []
      } = await $axios.$get(`/diathesis/subject/detail`, {
        params: {
          gradeId,
          semester,
          scoreType,
          gradeCode,
          classId: classId,
          _pageSize: pageSize,
          _pageIndex: pageIndex
        }
      })
      if (studentList.length) {
        studentList = formatStudentList(studentList)
      }
      total = page.maxRowCount || 0
    }
    const acadyear = formatGradeCode(gradeCode) + formatSemesterName(semester)
    return {
      acadyear,
      classList,
      studentList,
      courseList,
      gradeId,
      semester,
      scoreType,
      gradeCode,
      total,
      classId,
      acadyearName
    }
  },
  async mounted() {},
  methods: {
    // 切换页码触发
    tableChangeHandler(pagination) {
      this.pageSize = pagination.pageSize
      this.pageIndex = pagination.current
      this.getData()
    },
    async getData() {
      this.loading = true
      const {
        studentList = [],
        courseList = [],
        page = {},
        acadyearName = []
      } = await this.$axios.$get(`/diathesis/subject/detail`, {
        params: {
          gradeId: this.gradeId,
          semester: this.semester,
          scoreType: this.scoreType,
          gradeCode: this.gradeCode,
          classId: this.classId,
          _pageSize: this.pageSize,
          _pageIndex: this.pageIndex,
          studentCode: this.studentCode,
          studentName: this.studentName
        }
      })
      this.studentList = formatStudentList(studentList)
      this.courseList = courseList
      this.acadyearName = acadyearName
      this.total = page.maxRowCount
      this.loading = false
    }
  },
  watch: {
    classId(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    scoreType(newVal) {
      this.pageIndex = 1
      this.getData()
    },
    acadyear(newVal) {
      this.pageIndex = 1
      let gradeCodeName = newVal.slice(0, 2)
      let semestername = newVal.slice(2)
      this.gradeCode = formatGradeCode(gradeCodeName)
      this.semester = formatSemesterName(semestername)
      this.getData()
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper {
  .title {
    .title_item {
      margin-right: 20px;
    }
  }
  .detail_table {
    white-space: nowrap;
  }
}
.subject_no_content {
  text-align: center;
  padding-top: 60px;
  background: #ffffff;
  position: relative;
  width: 100%;
  top: -53px;
  z-index: 99;
  .subject_no_title {
    color: #999999;
    padding: 15px 0 12px 0;
  }
}
</style>
