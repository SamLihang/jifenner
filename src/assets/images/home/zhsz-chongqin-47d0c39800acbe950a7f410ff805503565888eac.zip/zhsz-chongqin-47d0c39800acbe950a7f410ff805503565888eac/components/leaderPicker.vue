<!--  author:   Date:  -->
<template>
  <div class="person_picker">
    <div class="leader_picker_title">
      <wp-button type="second" background="primary" size="small" @click="resetHandler">清空</wp-button>
    </div>
    <wp-scrollbar style="height: 300px">
      <ul class="leader_list">
        <li v-for="(person, index) in personList" :key="index" class="leader_list_item">
          <wp-radio
            v-model="selectedId"
            :label="person.studentId"
            style="margin-right: 10px"
            type="button"
          >{{ person.studentName}}</wp-radio>
        </li>
      </ul>
    </wp-scrollbar>
  </div>
</template>

<script>
import { isArray } from '~/utils/tools'

export default {
  name: '',
  props: {
    value: {
      type: String,
      required: true
    },
    data: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      personList: [],
      searchKey: '',
      selectedId: ''
    }
  },
  computed: {},
  watch: {
    selectedId: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    },
    value: {
      handler: function(newVal) {
        this.selectedId = newVal
      },
      deep: true
    },
    data: {
      handler: function(newVal) {
        this.personList = newVal
      },
      deep: true
    }
  },
  mounted() {},
  methods: {
    //取消全选
    resetHandler() {
      this.selectedId = ''
    }
  }
}
</script>
<style lang="scss" scoped>
/deep/.wp-radio--button .wp-radio__text {
  font-size: 14px;
  line-height: 14px;
}
/deep/.wp-radio + .wp-radio--button {
  margin-left: 10px;
}
/deep/.wp-checkbox__text {
  padding-left: 0;
}
.person_picker {
  .leader_picker_title {
    text-align: right;
  }
}
.leader_list {
  margin-top: 10px;
  .leader_list_item {
    display: inline-block;
    margin-bottom: 10px;
  }
}
</style>
