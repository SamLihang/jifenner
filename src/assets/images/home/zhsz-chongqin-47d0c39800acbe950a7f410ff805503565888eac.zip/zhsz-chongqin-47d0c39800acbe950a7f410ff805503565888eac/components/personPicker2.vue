<!--  author:   Date:  -->
<template>
  <div class="person_picker">
    <wp-input
      v-model="searchKey"
      placeholder="请输入姓名"
      width="200px"
      @keyup.enter.native="searchHandler"
      maxlength="20"
    >
      <wp-icon slot="append" name="search" @click.native="searchHandler"></wp-icon>
    </wp-input>
    <table border="1" class="picker_table">
      <colgroup>
        <col width="160px" />
        <col width="200px" />
        <col width="200px" />
      </colgroup>
      <thead>
        <tr>
          <th>班级</th>
          <th>
            学生
            <wp-checkbox v-model="allSelected" class="wp_fr" @change="allSelectHandler">全选</wp-checkbox>
          </th>
          <th>
            已选{{ selectedList.length }}人
            <wp-button size="small" class="wp_fr" @click="resetHandler">清空</wp-button>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <wp-scrollbar style="height: 300px">
              <wp-tree
                accordion
                :data="deptList"
                @select="treeSelectHandler"
                open_icon="arrow-line"
                close_icon="arrow-line"
              ></wp-tree>
            </wp-scrollbar>
          </td>
          <td>
            <wp-scrollbar style="height: 300px">
              <ul class="person_list">
                <li v-for="(person, index) in personList" :key="index" class="person_list_item">
                  <wp-checkbox
                    v-model="person.selected"
                    style="margin-right: 10px"
                    @change="selectHandler(person)"
                  >
                    {{ person.studentName
                    }}{{
                    person.className ? `(${person.className})` : ''
                    }}
                  </wp-checkbox>
                </li>
              </ul>
            </wp-scrollbar>
          </td>
          <td>
            <wp-scrollbar style="height: 300px">
              <ul class="person_list">
                <li v-for="(person, index) in selectedList" :key="index" class="person_list_item">
                  {{ person.studentName }}
                  <wp-icon
                    name="close"
                    font-size="12"
                    class="person_list_item_icon"
                    fill="#ccc"
                    @click.native="removeHandler(index)"
                  ></wp-icon>
                </li>
              </ul>
            </wp-scrollbar>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: '',
  props: {
    value: {
      type: Array,
      required: true
    },
    data: {
      type: Array,
      required: true
    },
    projectId: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      personList: [],
      deptList: [],
      selectedList: [],
      searchKey: '',
      allSelected: false
    }
  },
  computed: {},
  watch: {
    selectedList: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    },
    value: {
      handler: function(newVal) {
        this.selectedList = newVal
      },
      deep: true,
      immediate: true
    },
    data: {
      handler: function(newVal) {
        const arr = []
        newVal.forEach(dept => {
          const child = { id: dept.gradeId, label: dept.gradeName }
          if (dept.classList) {
            child.children = []
            dept.classList.forEach(cls => {
              child.children.push({ id: cls.classId, label: cls.className })
            })
          }
          arr.push(child)
        })
        this.deptList = arr
      },
      deep: true
    }
  },
  mounted() {},
  methods: {
    allSelectHandler() {
      this.$nextTick(() => {
        this.personList.forEach(person => {
          if (person.selected !== this.allSelected) {
            person.selected = this.allSelected
            this.selectHandler(person)
          }
        })
      })
    },
    selectHandler(person) {
      const alive = this.selectedList.some((item, index) => {
        if (item.studentId === person.studentId) {
          this.selectedList.splice(index, 1)
          this.allSelected = false
          return true
        }
      })
      if (!alive) this.selectedList.push(person)
      this.checkAllSelect()
    },
    removeHandler(index) {
      this.personList.some(person => {
        if (person.studentId === this.selectedList[index].studentId) {
          person.selected = false
          return true
        }
      })
      this.selectedList.splice(index, 1)
      this.checkAllSelect()
    },
    checkAllSelect() {
      this.$nextTick(() => {
        this.allSelected = this.personList.every(item => {
          return item.selected
        })
      })
    },
    resetHandler() {
      this.selectedList = []
      this.allSelected = false
      this.personList.forEach(person => {
        person.selected = false
      })
    },
    async searchHandler() {
      if (!this.searchKey) return
      const personList = await this.$axios.$get(`/diathesis/getStudent`, {
        params: {
          studentName: this.searchKey,
          projectId: this.projectId,
          type: 1
        }
      })
      this.personList = Array.from(personList, person => {
        const selected = this.selectedList.some(item => {
          return item.studentId === person.studentId
        })
        return { ...person, selected: selected }
      })
      this.checkAllSelect()
    },
    async treeSelectHandler(item) {
      if (item.children) return
      const personList = await this.$axios.$get(
        `/diathesis/getStudentList?classId=${item.id}`
      )
      this.allSelected = false
      this.personList = Array.from(personList, person => {
        const selected = this.selectedList.some(item => {
          return item.studentId === person.studentId
        })
        return { ...person, selected: selected }
      })
      this.checkAllSelect()
    }
  }
}
</script>
<style lang="scss" scoped>
.person_picker {
  .search {
    right: 0;
  }
  .picker_table {
    text-align: left;
    width: 100%;
    margin-top: 10px;
    border: 1px solid #cccccc;
    thead {
      background: #f5f5f5;
      th {
        padding: 10px;
      }
    }
    td {
      vertical-align: top;
    }
    .person_list {
      .person_list_item {
        padding: 5px 10px;
        white-space: nowrap;
        overflow: hidden;
        &:hover {
          background: #e5f3ff;
        }
        .person_list_item_icon {
          float: right;
          cursor: pointer;
          margin-top: 5px;
        }
      }
    }
  }
}
</style>
