<!--  author:   Date:  -->
<template>
  <div class="person_picker">
    <wp-mixer>
      <wp-input
        v-model="searchKey"
        placeholder="请输入姓名"
        width="200px"
        @keyup.enter.native="searchHandler"
        maxlength="20"
      ></wp-input>
      <wp-button @click.native="searchHandler" type="second" background="primary">
        <wp-icon name="search" fill="#999"></wp-icon>
      </wp-button>
    </wp-mixer>
    <table border="1" class="picker_table">
      <colgroup>
        <col width="160px" />
        <col width="200px" />
        <col width="200px" />
      </colgroup>
      <thead>
        <tr>
          <th>
            人员
            <wp-checkbox v-model="allSelected" class="wp_fr" @change="allSelectHandler">全选</wp-checkbox>
          </th>
          <th>
            已选{{ selectedList.length }}人
            <wp-button
              type="second"
              background="primary"
              size="small"
              class="wp_fr"
              @click="resetHandler"
            >清空</wp-button>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <wp-scrollbar style="height: 300px">
              <ul class="person_list">
                <li
                  v-for="(person, index) in personList"
                  :key="index"
                  class="person_list_item"
                  v-show="person.hidden"
                >
                  <wp-checkbox
                    v-model="person.selected"
                    style="margin-right: 10px"
                    @change="selectHandler(person)"
                  >
                    {{ person.studentName
                    }}
                  </wp-checkbox>
                </li>
              </ul>
            </wp-scrollbar>
          </td>
          <td>
            <wp-scrollbar style="height: 300px">
              <ul class="person_list">
                <li v-for="(person, index) in selectedList" :key="index" class="person_list_item">
                  {{ person.studentName }}
                  <wp-icon
                    name="close"
                    font-size="14"
                    class="person_list_item_icon"
                    fill="#999"
                    @click.native="removeHandler(index)"
                  ></wp-icon>
                </li>
              </ul>
            </wp-scrollbar>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { deepClone } from '~/utils/tools'

export default {
  name: '',
  props: {
    value: {
      type: Array,
      required: true
    },
    data: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      personList: [],
      classid: [],
      selectedList: [],
      searchKey: '',
      allSelected: false
    }
  },
  computed: {},
  watch: {
    selectedList: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    },
    value: {
      handler: function(newVal) {
        this.selectedList = newVal
      },
      deep: true
    },
    data: {
      handler: function(newVal) {
        this.allSelected = false
        this.personList = Array.from(newVal, person => {
          const selected = this.selectedList.some(item => {
            return item.studentId === person.studentId
          })
          return { ...person, selected: selected, hidden: true }
        })
        this.checkAllSelect()
        this.searchKey = ''
      },
      deep: true
    }
  },
  mounted() {},
  methods: {
    //全选
    allSelectHandler() {
      this.$nextTick(() => {
        this.personList.forEach(person => {
          if (person.selected !== this.allSelected && person.hidden) {
            person.selected = this.allSelected
            this.selectHandler(person)
          }
        })
      })
    },
    //取消全选
    resetHandler() {
      this.selectedList = []
      this.allSelected = false
      this.personList.forEach(person => {
        if (person.hidden) {
          person.selected = false
        }
      })
    },
    //选择人员
    selectHandler(person) {
      const alive = this.selectedList.some((item, index) => {
        if (item.studentId === person.studentId) {
          this.selectedList.splice(index, 1)
          this.allSelected = false
          return true
        }
      })
      if (!alive) this.selectedList.push(person)
      this.checkAllSelect()
    },
    //删除人员
    removeHandler(index) {
      this.personList.some(person => {
        if (person.studentId === this.selectedList[index].studentId) {
          person.selected = false
          return true
        }
      })
      this.selectedList.splice(index, 1)
      this.checkAllSelect()
    },
    //判断是否全选
    checkAllSelect() {
      this.$nextTick(() => {
        if (!this.personList.length) return false
        this.allSelected = this.personList.every(item => {
          if (item.hidden) {
            return item.selected
          } else {
            return true
          }
        })
      })
    },
    //搜索
    searchHandler() {
      this.personList.forEach(item => {
        if (!item.studentName.includes(this.searchKey)) {
          item.hidden = false
        } else {
          item.hidden = true
        }
      })
      this.checkAllSelect()
    }
  }
}
</script>
<style lang="scss" scoped>
.person_picker {
  .search {
    right: 0;
  }
  .picker_table {
    text-align: left;
    width: 100%;
    margin-top: 10px;
    border: 1px solid #cccccc;
    thead {
      background: #f5f5f5;
      th {
        padding: 10px;
      }
    }
    td {
      vertical-align: top;
    }
    .person_list {
      .person_list_item {
        padding: 5px 10px;
        white-space: nowrap;
        overflow: hidden;
        &:hover {
          background: #e5f3ff;
        }
        .person_list_item_icon {
          float: right;
          cursor: pointer;
          margin-top: 5px;
        }
      }
    }
  }
}
</style>
