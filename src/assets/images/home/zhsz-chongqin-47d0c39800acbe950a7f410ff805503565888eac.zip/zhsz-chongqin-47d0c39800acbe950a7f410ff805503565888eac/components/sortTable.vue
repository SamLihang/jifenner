<!--  author:   Date:  -->
<template>
  <a-table
    class="sort_table"
    row-key="id"
    :columns="defaultColumns"
    :data-source="dataSource"
    :pagination="false"
    bordered
    :scroll=" {y: dataSource.length > 7 ? '300px' : null}"
    :locale="{emptyText: '暂无数据'}"
  >
    <wp-input
      slot="name"
      v-model="text.name"
      slot-scope="text,recored,index"
      maxlength="15"
      :ref="'sourcename' + index"
    ></wp-input>
    <div slot="sort" slot-scope="text, data, index">
      <wp-icon
        name="arrow-circle"
        font-size="20"
        class="upIcon"
        :fill="index === 0 ? '#999' : '#317eeb'"
        @click.native="swapArr(dataSource, index, index - 1)"
      ></wp-icon>
      <wp-icon
        name="arrow-circle"
        font-size="20"
        class="downIcon"
        :fill="index === dataSource.length - 1 ? '#999' : '#317eeb'"
        @click.native="swapArr(dataSource, index, index + 1)"
      ></wp-icon>
    </div>
    <a
      slot="delete"
      slot-scope="text, data, index"
      href="javascript:void(0)"
      @click="delHandler(index)"
    >删除</a>
    <template slot="footer">
      <wp-row class="footer" height="100%" @click.native="addHandler">
        <wp-col align="center">
          <wp-icon name="add-pure" font-size="12" fill="#347ee9"></wp-icon>
          <span>新增</span>
        </wp-col>
      </wp-row>
    </template>
  </a-table>
</template>

<script>
import { swapArr } from '../utils/tools'
const defaultColumns = [
  {
    title: '类目名称',
    scopedSlots: { customRender: 'name' },
    width: '213px'
  },
  {
    title: '排序',
    scopedSlots: { customRender: 'sort' },
    width: '250x'
  },
  {
    title: '操作',
    scopedSlots: { customRender: 'delete' },
    width: '100px'
  }
]
export default {
  name: '',
  components: {},
  props: {
    dataSource: { type: Array, required: true },
    columns: { type: Array, required: true }
  },
  data() {
    return {
      defaultColumns
    }
  },
  computed: {},
  watch: {
    columns: {
      handler: function(newVal) {
        this.defaultColumns.forEach((element, index) => {
          element.title = newVal[index]
        })
      },
      deep: true
    }
  },
  mounted() {},
  methods: {
    swapArr() {
      return swapArr(...arguments)
    },
    delHandler(index) {
      this.dataSource.splice(index, 1)
    },
    addHandler() {
      this.dataSource.push({
        id: '',
        name: ''
      })
      this.$nextTick(() => {
        const sortTable = document.querySelectorAll(
          '.sort_table .ant-table-body'
        )
        sortTable &&
          sortTable.length &&
          [].forEach.call(sortTable, item => {
            item.scrollTo && item.scrollTo(0, item.scrollHeight)
          })
        this.$refs['sourcename' + (this.dataSource.length - 1)].focus()
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.sort_table {
  .upIcon {
    margin-right: 20px;
    cursor: pointer;
  }
  .downIcon {
    transform: rotate(180deg);
    cursor: pointer;
  }
  .footer {
    cursor: pointer;
    span {
      color: #347ee9;
      font-size: 14px;
      vertical-align: middle;
      margin-left: 10px;
    }
  }
  /deep/ td {
    padding: 3px 10px !important;
  }
  /deep/ th {
    font-weight: 600;
    padding: 9px 10px !important;
  }
  /deep/ .ant-table-footer {
    padding: 8px;
    background: #fff;
  }
}
a:hover {
  text-decoration: underline;
}
.footer:hover span {
  text-decoration: underline;
}
</style>
