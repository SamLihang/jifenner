<!--  author:   Date:  -->
<template>
  <div>
    <div v-if="record.totalScore">
      <span class="minscore">{{record.totalScore}}</span>
      <wp-popover v-model="record.showscore">
        <wp-icon
          name="bianji1"
          @click="record.showscore = true"
          style="cursor:pointer;"
          fill="#999"
        ></wp-icon>
        <div slot="content">
          <p class="score_p" v-if="inputValueType === 'S'">
            <wp-number-input
              class="datainput"
              type="number"
              width="80"
              v-model="record.totalScore"
              :max="100"
              :mimn="0"
            ></wp-number-input>
          </p>
          <p class="score_p" v-else>
            <wp-radio
              v-model="record.totalScore"
              :label="rank"
              v-for="rank in rankItems"
              :key="rank"
            >{{rank}}</wp-radio>
          </p>

          <p class="score_p">
            备注:
            <wp-input v-model="record.totalRemark"></wp-input>
          </p>
          <wp-button-group class="mt20">
            <wp-button
              type="second"
              size="small"
              background="primary"
              @click="record.showscore = false"
            >取消</wp-button>
            <wp-button type="main" size="small" background="primary" @click="editscore(record)">确定</wp-button>
          </wp-button-group>
        </div>
      </wp-popover>
    </div>
    <p v-else>—</p>
  </div>
</template>

<script>
import { downloadFile } from '~/utils/tools'
import { baseURL } from '~/nuxt.config.js'
export default {
  name: '',
  components: {},
  data() {
    return {}
  },
  props: {
    record: {
      type: Object,
      required: true
    },
    inputValueType: {
      type: String,
      required: true
    },
    rankItems: {
      type: Array,
      required: true
    }
  },
  computed: {},
  methods: {
    editscore(record) {
      this.$emit('editscore', record)
    }
  },
  watch: {}
}
</script>
<style lang='scss' scoped>
.mt20 {
  float: right;
}
.minscore {
  font-size: 14px;
  margin-right: 20px;
}
.score_p {
  margin-bottom: 20px;
}
</style>