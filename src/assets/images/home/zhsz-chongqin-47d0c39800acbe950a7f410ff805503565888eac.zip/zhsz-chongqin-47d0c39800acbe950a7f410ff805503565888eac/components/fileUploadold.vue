<!--  author:   Date:  -->
<template>
  <div class="wrapper">
    <div class="title">
      <h5>导入说明</h5>
      <a href="javascript:void(0)" @click="downloadTemplate">
        <p>1、点击下载模板</p>
      </a>
      <p>
        2、根据模板完善相应的信息并导入
        <i>（请不要随意修改模板文件的字段）</i>
      </p>
    </div>
    <wp-button-group>
      <wp-upload
        name="file"
        :src="src"
        v-model="fileList"
        :data="{key: businessKey}"
        :accept="['application/vnd.ms-excel']"
        :with-credentials="true"
        @on-success="onSuccess"
        @on-error="onError"
        @on-progress="onProgress"
        @on-loadstart="onLoadstart"
        style="display: inline-block"
      >
        <wp-button>导入文件</wp-button>
      </wp-upload>
      <wp-button type="second" @click="downloadTemplate">下载模板</wp-button>
      <wp-button disabled>删除记录</wp-button>
    </wp-button-group>
    <a-table
      :columns="columns"
      :data-source="fileList"
      class="table"
      :locale="{emptyText: '暂无数据'}"
      :pagination="false"
    >
      <div slot="actions" slot-scope="record,index">
        <template v-if="record.totalCount && record.totalCount !== record.successCount">
          <a href="javascript: void(0)" @click="exportErrorMsg(record)">导出错误信息</a>
          <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
        </template>
        <a href="javascript: void(0)" @click="delHandler(index)">删除记录</a>
      </div>
      <div slot="count" slot-scope="record" style="white-space: nowrap">
        <template v-if="record.totalCount">
          <p class="record_count">
            <span :class="{error: record.errorCount}">{{record.errorCount}}</span>
            /
            <span>{{record.totalCount}}</span>
          </p>
        </template>
      </div>
      <div slot="status" slot-scope="record">
        <wp-progress
          :percent="record.percent"
          class="progressBar"
          :class="{hideen: record.status === 'success'}"
          stroke="3"
          :describe="false"
        ></wp-progress>
        <p class="error" v-if="record.err">{{record.err}}</p>
        <template
          v-else-if="record.totalCount && record.totalCount === record.successCount"
        >{{'导入成功'}}</template>
        <template
          v-else-if="record.totalCount && record.totalCount !== record.successCount"
        >{{'导入失败'}}</template>
        <template v-else>{{statusList[record.status]}}</template>
      </div>
    </a-table>
  </div>
</template>

<script>
import { baseURL } from '~/nuxt.config.js'
const columns = [
  { title: '文件名', dataIndex: 'name' },
  { title: '导入时间', dataIndex: 'startTime' },
  { title: '操作人', dataIndex: 'operater' },
  { title: '导入状态', scopedSlots: { customRender: 'status' } },
  {
    title: '失败数/总数',
    scopedSlots: { customRender: 'count' }
  },
  { title: '操作', scopedSlots: { customRender: 'actions' } }
]
export default {
  name: '',
  components: {},
  data() {
    return {
      columns,
      src: `${baseURL}/diathesis/common/webuploader/upload`,
      fileList: [],
      statusList: { ready: '上传中', success: '上传成功', error: '上传失败' }
    }
  },
  computed: {},
  props: {
    businessKey: {
      type: String
    },
    value: {
      type: Array,
      required: true
    }
  },
  methods: {
    delHandler(index) {
      this.fileList.splice(index, 1)
    },
    onProgress(e, file) {},
    downloadTemplate() {
      this.$emit('downloadTemplate')
    },
    exportErrorMsg(record) {
      this.$emit('exportErrorMsg', record.errorExcelPath)
    },
    onSuccess(res, file) {
      this.$emit('onSuccess', res, file)
    },
    onError(err, file) {
      this.$emit('onError', err)
    },
    onLoadstart(file) {
      this.$set(file, 'startTime', this.formatDate())
      this.$set(file, 'err', '')
      this.$set(file, 'errorCount', '')
      this.$set(file, 'errorExcelPath', '')
      this.$set(file, 'successCount', '')
      this.$set(file, 'totalCount', '')
      this.$set(file, 'operater', '')
    },
    formatDate() {
      let date = new Date()
      let seperator1 = '-'
      let seperator2 = ':'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let currentdate =
        date.getFullYear() +
        seperator1 +
        month +
        seperator1 +
        strDate +
        ' ' +
        date.getHours() +
        seperator2 +
        date.getMinutes() +
        seperator2 +
        date.getSeconds()
      return currentdate
    }
  },
  watch: {
    value: {
      handler: function(newVal) {
        this.fileList = newVal
      },
      deep: true
    },
    fileList: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    }
  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 20px;
  border: 1px solid #93c6ff;
  background: #f5faff;
  border-radius: 4px;
  margin-bottom: 20px;
  h5 {
    font-weight: 600;
    margin-bottom: 10px;
  }
  p {
    line-height: 39px;
  }
}
.table {
  margin-top: 20px;
  .progressBar {
    position: absolute;
    bottom: -1px;
    left: 0;
    opacity: 1;
    transition: opacity 0.3s ease-in-out 1s;
    &.hideen {
      opacity: 0;
    }
  }
}
.record_count {
  font-size: 14px;
}
.error {
  color: red;
}
/deep/ .wp-upload__list {
  display: none;
}
</style>
