<!--  author:   Date:  -->
<template>
  <div class="data_type_input">
    <wp-input
      v-if="datasource.dataType === '1'"
      v-model="datasource.contentTxt"
      maxlength="20"
      width="100%"
    ></wp-input>
    <wp-select
      v-if="datasource.dataType === '2'"
      v-model="datasource.contentTxt"
      :data="datasource.optionList"
      value-key="id"
      width="100%"
      label-key="contentTxt"
      placeholder="请选择"
    ></wp-select>
    <wp-checkbox-group v-if="datasource.dataType === '3'" v-model="checkList">
      <wp-checkbox
        v-for="(option,index) in datasource.optionList"
        :key="index"
        :label="option.id"
      >{{option.contentTxt}}</wp-checkbox>
    </wp-checkbox-group>
    <template>
      <a
        href="javascript:void(0)"
        v-if="datasource.dataType === '4' && datasource.contentTxt && !fileList.length"
        @click="downLoadHandler"
      >{{datasource.resultTxt}}</a>
      <wp-upload
        style="height: 32px"
        name="file"
        :src="src"
        ref="upload"
        :limit="1"
        :auto-upload="false"
        v-model="fileList"
        :data="{key: businessKey}"
        :with-credentials="true"
        @on-success="onSuccess"
        @on-error="onError"
        @on-loadstart="onLoadstart"
        v-if="datasource.dataType === '4'"
      >
        <div class="file_List">
          <a href="javascript:void(0)" v-if="!fileList.length">点击上传</a>
        </div>
      </wp-upload>
    </template>
  </div>
</template>

<script>
import { downloadFile } from '~/utils/tools'
import { baseURL } from '~/nuxt.config.js'
export default {
  name: '',
  components: {},
  data() {
    return {
      src: `${baseURL}/diathesis/common/webuploader/upload`,
      fileList: [],
      checkList: [],
      datasource: {},
      businessKey: '',
      uploadStatus: false
    }
  },
  props: {
    value: {
      type: Object,
      required: true
    }
  },
  computed: {},
  methods: {
    onLoadstart() {},
    onSuccess(res) {
      const { fullPath } = res
      this.datasource.contentTxt = fullPath
      this.$warn.show({ title: '上传成功' })
    },
    onError(err) {
      const { success, msg } = err
      if (!success) {
        this.$warn.show({ title: msg || '请求失败' })
      }
    },
    uploadHandler() {
      this.$refs.upload.submit()
    },
    async getBusinessKey() {
      this.uploadStatus = true
      const { businessKey } = await this.$axios.$get(
        `/diathesis/common/execute`
      )
      this.businessKey = businessKey
      this.$nextTick(() => {
        this.uploadHandler()
      })
    },
    async downLoadHandler() {
      const {
        data: { fileName, blob }
      } = await this.$axios({
        method: 'get',
        url: '/diathesis/common/downloadFile',
        params: { filePath: this.datasource.contentTxt },
        responseType: 'blob'
      })
      downloadFile(this.datasource.resultTxt, blob)
    }
  },
  watch: {
    fileList: {
      handler: function(newVal) {
        if (!newVal.length) {
          this.uploadStatus = false
        }
        newVal.forEach(element => {
          if (!this.uploadStatus) {
            this.getBusinessKey()
          }
        })
      },
      deep: true
    },
    checkList: {
      handler: function(newVal) {
        this.datasource.contentTxt = newVal.join(',')
      },
      deep: true
    },
    value: {
      handler: function(newVal) {
        this.datasource = newVal
        if (newVal.dataType === '3' && typeof newVal.contentTxt === 'string') {
          this.checkList = newVal.contentTxt ? newVal.contentTxt.split(',') : []
        }
      },
      deep: true,
      immediate: true
    },
    datasource: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    }
  }
}
</script>
<style lang='scss' scoped>
.data_type_input {
  overflow: hidden;
  text-overflow: ellipsis;
}
/deep/.wp-upload__inner {
  vertical-align: middle;
}
/deep/.wp-upload__list {
  margin-top: -30px;
}
/deep/.wp-checkbox {
  margin-left: 0;
  margin-right: 10px;
}
</style>