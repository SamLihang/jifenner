<!--  author:   Date:  -->
<template>
  <div>
    <div class="title">
      <h5>导入说明</h5>
      <p>
        1、点击
        <a href="javascript:void(0)" @click="downloadTemplate">下载模板</a>
      </p>
      <p style="margin-bottom:8px;">
        2、根据模板完善相应的信息并导入
        <i>（请不要随意修改模板文件的字段）</i>
      </p>
      <wp-button-group>
        <wp-button type="main" background="primary" ghost @click="downloadTemplate">下载模板</wp-button>
        <wp-upload
          name="file"
          :src="src"
          v-model="fileList"
          :data="{key: businessKey}"
          :accept="['application/vnd.ms-excel']"
          :with-credentials="true"
          @on-success="onSuccess"
          @on-error="onError"
          @on-progress="onProgress"
          @on-loadstart="onLoadstart"
          style="display: inline-block"
          ref="upload"
        >
          <wp-button type="main" background="primary" ghost>导入文件</wp-button>
        </wp-upload>
      </wp-button-group>
      <img src="~assets/image/academicRecord/loadback.png" class="titleimg" />
    </div>
    <div class="upload_body">
      <wp-button-group>
        <wp-button :disabled="selectedRowKeys.length > 0 ? false : true" @click="moreremove">删除记录</wp-button>
      </wp-button-group>
      <a-table
        :columns="columns"
        :data-source="fileList"
        class="table"
        :locale="{emptyText: '暂无数据'}"
        :pagination="false"
        :rowSelection="rowSelection"
      >
        <div slot="name" slot-scope="record,index" class="clearfix file_name">
          <i
            class="xls_img"
            v-if="record.name.split('.')[1] === 'xls' || record.name.split('.')[1] === 'xlsx'"
          ></i>
          <i class="pdf_img" v-if="record.name.split('.')[1] === 'pdf'"></i>
          <i
            class="pic_img"
            v-if="record.name.split('.')[1] === 'png' || record.name.split('.')[1] === 'jpg'
            || record.name.split('.')[1] === 'jpeg' || record.name.split('.')[1] === 'bmp'"
          ></i>
          <i
            class="ppt_img"
            v-if="record.name.split('.')[1] === 'ppt' || record.name.split('.')[1] === 'pptx'"
          ></i>
          <i
            class="word_img"
            v-if="record.name.split('.')[1] === 'doc' || record.name.split('.')[1] === 'docx'"
          ></i>
          {{record.name}}
        </div>
        <div slot="actions" slot-scope="record,index">
          <template v-if="record.totalCount && record.totalCount !== record.successCount">
            <a href="javascript: void(0)" @click="exportErrorMsg(record)">导出错误信息</a>
            <i style="color: #d9d9d9">&nbsp;&nbsp;|&nbsp;&nbsp;</i>
          </template>
          <a href="javascript: void(0)" @click="delHandler(index)">删除记录</a>
        </div>
        <div slot="count" slot-scope="record" style="white-space: nowrap">
          <template v-if="record.totalCount">
            <p class="record_count">
              <span :class="{error: record.errorCount}">{{record.errorCount}}</span>
              /
              <span>{{record.totalCount}}</span>
            </p>
          </template>
        </div>
        <div slot="status" slot-scope="record">
          <wp-progress
            :percent="record.percent"
            class="progressBar"
            :class="{hideen: record.status === 'success'}"
            stroke="3"
            :describe="false"
          ></wp-progress>
          <p class="error" v-if="record.err">{{record.err}}</p>
          <template
            v-else-if="record.totalCount && record.totalCount === record.successCount"
          >{{'导入成功'}}</template>
          <template
            v-else-if="record.totalCount && record.totalCount !== record.successCount"
          >{{'导入失败'}}</template>
          <template v-else>{{statusList[record.status]}}</template>
        </div>
      </a-table>
      <div class="subject_no_content" v-show="fileList.length <= 0">
        <img src="~/assets/image/subject/nocontent.png" />
        <div class="subject_no_title">根据模板完善相应的信息并导入</div>
        <div>
          <wp-upload
            name="file"
            :src="src"
            v-model="fileList"
            :data="{key: businessKey}"
            :accept="['application/vnd.ms-excel']"
            :with-credentials="true"
            @on-success="onSuccess"
            @on-error="onError"
            @on-progress="onProgress"
            @on-loadstart="onLoadstart"
            style="display: inline-block"
            ref="upload"
          >
            <wp-button type="main" background="primary" ghost>导入文件</wp-button>
          </wp-upload>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { baseURL } from '~/nuxt.config.js'
const columns = [
  { title: '文件名', scopedSlots: { customRender: 'name' } },
  { title: '导入时间', dataIndex: 'startTime' },
  { title: '操作人', dataIndex: 'operater' },
  { title: '导入状态', scopedSlots: { customRender: 'status' } },
  {
    title: '失败数/总数',
    scopedSlots: { customRender: 'count' }
  },
  { title: '操作', scopedSlots: { customRender: 'actions' } }
]
export default {
  name: '',
  components: {},
  data() {
    return {
      columns,
      src: `${baseURL}/diathesis/common/webuploader/upload`,
      fileList: [],
      statusList: { ready: '上传中', success: '上传成功', error: '上传失败' },
      rowSelection: {
        onChange: (selectedRowKeys, selectedRows) => {
          this.selectedRowKeys = selectedRows
        },
        onSelect: (record, selected, selectedRows) => {},
        onSelectAll: (selected, selectedRows, changeRows) => {}
      },
      selectedRowKeys: []
    }
  },
  computed: {},
  props: {
    businessKey: {
      type: String
    },
    value: {
      type: Array,
      required: true
    }
  },
  methods: {
    delHandler(index) {
      this.selectedRowKeys.length > 0 &&
        this.selectedRowKeys.forEach((minitem, minindex) => {
          if (index.uid === minitem.uid) {
            this.selectedRowKeys.splice(minindex, 1)
            return false
          }
        })
      this.fileList.splice(index, 1)
    },
    moreremove() {
      this.fileList.forEach((item, index) => {
        this.selectedRowKeys.forEach((minitem, minindex) => {
          if (item.uid === minitem.uid) {
            this.fileList.splice(index, 1)
            this.selectedRowKeys.splice(minindex, 1)
          }
        })
      })
    },
    onProgress(e, file) {},
    downloadTemplate() {
      this.$emit('downloadTemplate')
    },
    exportErrorMsg(record) {
      this.$emit('exportErrorMsg', record.errorExcelPath)
    },
    onSuccess(res, file) {
      this.$emit('onSuccess', res, file)
      // if (file.type !== 'application/vnd.ms-excel') {
      //   this.delHandler(this.fileList.length - 1)
      // }
    },
    onError(err, file) {
      this.$emit('onError', err)
    },
    onLoadstart(file) {
      this.$set(file, 'startTime', this.formatDate())
      this.$set(file, 'err', '')
      this.$set(file, 'errorCount', '')
      this.$set(file, 'errorExcelPath', '')
      this.$set(file, 'successCount', '')
      this.$set(file, 'totalCount', '')
      this.$set(file, 'operater', '')
    },
    formatDate() {
      let date = new Date()
      let seperator1 = '-'
      let seperator2 = ':'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let currentdate =
        date.getFullYear() +
        seperator1 +
        month +
        seperator1 +
        strDate +
        ' ' +
        date.getHours() +
        seperator2 +
        date.getMinutes() +
        seperator2 +
        date.getSeconds()
      return currentdate
    }
  },
  watch: {
    value: {
      handler: function(newVal) {
        this.fileList = newVal
      },
      deep: true
    },
    fileList: {
      handler: function(newVal) {
        this.$emit('input', newVal)
      },
      deep: true
    }
  }
}
</script>
<style lang="scss" scoped>
.title {
  padding: 20px;
  background-image: linear-gradient(-180deg, #c3e9fe 0%, #eaf6fd 100%);
  border-radius: 4px 4px 0 0;
  margin-bottom: 20px;
  position: relative;
  height: 162px;
  h5 {
    font-weight: 600;
    margin-bottom: 10px;
  }
  p {
    line-height: 24px;
  }
  .titleimg {
    position: absolute;
    right: 0;
    top: 0;
  }
}
.upload_body {
  padding: 0 20px;
  position: relative;
}
.table {
  margin-top: 10px;
  .progressBar {
    position: absolute;
    bottom: -1px;
    left: 0;
    opacity: 1;
    transition: opacity 0.3s ease-in-out 1s;
    &.hideen {
      opacity: 0;
    }
  }
}
.record_count {
  font-size: 14px;
}
.error {
  color: red;
}
/deep/ .wp-upload__list {
  display: none;
}
.file_name {
  line-height: 40px;
}
.xls_img {
  width: 34px;
  height: 40px;
  float: left;
  background-image: url(~assets/image/academicRecord/excel.png);
  margin-right: 4px;
}
.pdf_img {
  width: 34px;
  height: 40px;
  float: left;
  background-image: url(~assets/image/academicRecord/pdf.png);
  margin-right: 4px;
}
.pic_img {
  width: 34px;
  height: 40px;
  float: left;
  background-image: url(~assets/image/academicRecord/pic.png);
  margin-right: 4px;
}
.ppt_img {
  width: 34px;
  height: 40px;
  float: left;
  background-image: url(~assets/image/academicRecord/ppt.png);
  margin-right: 4px;
}
.word_img {
  width: 34px;
  height: 40px;
  float: left;
  background-image: url(~assets/image/academicRecord/word.png);
  margin-right: 4px;
}
.subject_no_content {
  text-align: center;
  padding-top: 60px;
  background: #ffffff;
  position: relative;
  width: 100%;
  top: -53px;
  z-index: 99;
  .subject_no_title {
    color: #999999;
    padding: 15px 0 12px 0;
  }
}
</style>
