<template>
  <div>
    <wp-row>
      <wp-step v-model="stepData" style="width: 100%" type="line" />
    </wp-row>
    <template v-if="showFlagOne">
      <template v-if="author.includes(2)">
        <wp-row>
          <wp-col :span="4" align="right">
            <h4 class="title">评价值设置</h4>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right" class="assess_label">最终展示形式:</wp-col>
          <wp-col
            :span="4"
            :offset=".2"
            class="assess_label"
          >{{localinputValueType ==='G' ? '等第' : '分值' }}</wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right" class="assess_label">评价值类型:</wp-col>
          <wp-col :span="18" :offset=".2">
            <div v-for="(item, index) in localRankItems" :key="item" class="type_item">
              {{item}}
              <i
                class="type_item_icon"
                v-if="index === localRankItems.length - 1"
                @click="removeitem(index)"
              >
                <wp-icon name="close" fill="#ffffff" font-size="12px"></wp-icon>
              </i>
            </div>
            <div class="type_item_add" @click="addrankitem">
              <wp-icon name="add-pure" font-size="12px"></wp-icon>
            </div>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right" class="assess_label">录入值形式:</wp-col>
          <wp-col :span="18" :offset=".2">
            <wp-radio v-model="localinputValueType" label="G" type="button">等第</wp-radio>
            <wp-radio v-model="localinputValueType" label="S" type="button">分值</wp-radio>
          </wp-col>
        </wp-row>
      </template>
      <div class="evaluationTip" v-else>
        小提示：等第信息、等第分值转换信息在此
        <wp-button type="words" background="primary" @click.native="detail_show = true">点击查看</wp-button>
      </div>
      <template v-if="platform==='school'">
        <wp-row>
          <wp-col :span="4" align="right">
            <h4 class="title">评价人设置</h4>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right" class="assess_label">学生互评形式:</wp-col>
          <wp-col :span="18" :offset=".2">
            <wp-radio v-model="localmutualType" label="M" type="button">组内人员互评</wp-radio>
            <wp-radio v-model="localmutualType" label="L" type="button">小组长评价</wp-radio>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right">写实记录录入人：</wp-col>
          <wp-col :span="18" :offset=".2">
            <wp-checkbox-group v-model="localInputTypes">
              <wp-checkbox
                :label="inputType"
                v-for="(inputType,index) in Object.keys(localPeopleTypesMap)"
                :key="index"
                type="button"
              >
                <span class="f16">{{localPeopleTypesMap[inputType]}}</span>
              </wp-checkbox>
            </wp-checkbox-group>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="4" align="right">写实记录审核人：</wp-col>
          <wp-col :span="18" :offset=".2">
            <wp-checkbox-group v-model="localAuditorTypes">
              <wp-checkbox
                :label="auditorType"
                v-for="(auditorType,index) in Object.keys(localPeopleTypesMap)"
                :key="index"
                type="button"
              >
                <span class="f16">{{localPeopleTypesMap[auditorType]}}</span>
              </wp-checkbox>
            </wp-checkbox-group>
          </wp-col>
        </wp-row>
      </template>
      <wp-row>
        <wp-col :offset="4.2" :span="10">
          <wp-button-group v-if="author.includes(2)">
            <wp-button
              type="main"
              size="large"
              background="primary"
              :disabled="firstDisabledFlag"
              @click="next(1)"
            >下一步</wp-button>
            <!-- <nuxt-link
              v-if="$store.state.globalSetting &&  platform === 'school'"
              to="/globalSetting"
            >
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>-->
            <!-- <nuxt-link v-if=" platform === 'education'" to="/eduGlobalsetting">
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>-->
          </wp-button-group>
          <wp-button v-else @click="save">保存</wp-button>
        </wp-col>
      </wp-row>
    </template>

    <template v-if="showFlagTwo">
      <wp-row>
        <wp-col :span="4" align="right">
          <h4 class="title">评价值转换</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right">单项转换：</wp-col>
        <wp-col :span="12" :offset=".2">
          <a-table
            :columns="columns"
            :data-source="scoreList"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template v-for="(col, index) in localRankItems" :slot="col">
              <div :key="index">
                <wp-input
                  maxlength="20"
                  v-model="localRankValues[index]"
                  @input="checkHandler(localRankValues[index], index)"
                ></wp-input>
              </div>
            </template>
          </a-table>
          <p class="tip">
            <wp-icon name="warning" fill="#faad14" style="float:left;margin:3px 5px 0 0;"></wp-icon>分值需是正整数
          </p>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right">
          <wp-tooltip position="right" class="convert_tool">
            <wp-icon name="question-fill" fill="#cccccc"></wp-icon>
            <p slot="content">转换需基于各评价人针对各一级指标的评价平均分</p>
          </wp-tooltip>一级指标转换:
        </wp-col>
        <wp-col :span="10" :offset=".2">
          <wp-radio v-model="localScoreType" label="S">按分数段</wp-radio>
          <wp-radio v-model="localScoreType" label="P">按分数排名比例</wp-radio>
        </wp-col>
      </wp-row>
      <wp-row v-if="localScoreType === 'S'">
        <wp-col :span="12" :offset="4.2" style="width:630px;">
          <a-table
            :columns="columns"
            :data-source="scoreList"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template v-for="(col, index) in localRankItems" :slot="col">
              <div :key="index">
                <template v-if="index < scoreScope.length -1">
                  <wp-input
                    v-model="scoreScope[index+1]"
                    width="50px"
                    maxlength="20"
                    type="number"
                    @input="checkInpHandler(scoreScope[index+1], index+1)"
                  ></wp-input>
                </template>
                <template v-else>
                  <p class="start_score1">0</p>
                </template>
                含 -
                <wp-input
                  v-model="scoreScope[index]"
                  width="50px"
                  maxlength="20"
                  type="number"
                  @input="checkInpHandler(scoreScope[index], index)"
                ></wp-input>
              </div>
            </template>
          </a-table>
          <p class="tip">
            <wp-icon name="warning" fill="#faad14" style="float:left;margin:3px 5px 0 0;"></wp-icon>评价平均分请保留1位小数
          </p>
        </wp-col>
      </wp-row>
      <wp-row v-else-if="localScoreType === 'P' && platform === 'school'">
        <wp-col :span="4" align="right">一级指标转换设置:</wp-col>
        <wp-col :span="12" :offset=".2">
          <a-table
            :columns="persentColumns"
            :data-source="anotherData"
            :pagination="false"
            bordered
            :locale="{emptyText: '暂无数据'}"
          >
            <template slot="score" slot-scope="text, record, index">
              <div>
                <template v-if="index > 0">
                  <wp-input
                    v-model="scoreScope[index-1]"
                    width="150px"
                    maxlength="20"
                    type="number"
                    @input="checkInpHandler(scoreScope[index-1], index-1)"
                  >
                    <p slot="suffix">%</p>
                  </wp-input>
                </template>
                <template v-else-if="index === 0">
                  <p class="start_score">0%</p>
                </template>
                - 含
                <wp-input
                  v-if="index < anotherData.length -1"
                  v-model="scoreScope[index]"
                  width="150px"
                  maxlength="20"
                  type="number"
                  @input="checkInpHandler(scoreScope[index], index)"
                >
                  <p slot="suffix">%</p>
                </wp-input>
                <p v-else class="start_score">100%</p>
              </div>
            </template>
          </a-table>
        </wp-col>
      </wp-row>
      <wp-row v-else-if="localScoreType === 'P'  && platform === 'education'">
        <wp-col :span="4" align="right">一级指标转换设置:</wp-col>
        <wp-col :span="15" :offset=".2">
          <wp-button type="second" @click.stop="setting_show = true">统一设置</wp-button>
          <table border="1" class="allUnitsTable">
            <colgroup>
              <col width="180px" />
            </colgroup>
            <thead>
              <tr>
                <th colspan="2">
                  <p class="wp_fl">所有单位</p>
                  <wp-input
                    placeholder="请输入姓名"
                    width="200px"
                    @keyup.enter.native="searchHandler"
                    maxlength="20"
                    class="wp_fr"
                    v-model="searchKey"
                  >
                    <wp-icon slot="suffix" name="search" @click.native="searchHandler"></wp-icon>
                  </wp-input>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="padding:0">
                  <wp-tree
                    :data="treeData"
                    width="180px"
                    @select="selectitem"
                    @expand="selectitem"
                    :default_select="treeData.length ? treeData[0] : null"
                    :filter="searchKey"
                    open_icon="angle-single-right"
                    close_icon="angle-single-right"
                    ref="mytree"
                  ></wp-tree>
                </td>
                <td>
                  <a-table
                    :columns="persentColumns"
                    :data-source="anotherData"
                    :pagination="false"
                    bordered
                    :locale="{emptyText: '暂无数据'}"
                  >
                    <template slot="score" slot-scope="text, record, index">
                      <div v-if="localSelectId">
                        <template v-if="index > 0">
                          <wp-input
                            v-model="localEduValueList[localSelectId][index-1]"
                            width="40%"
                            maxlength="20"
                            type="number"
                            @input="checkEduHandler(localEduValueList[localSelectId][index-1], index-1)"
                          >
                            <p slot="suffix">%</p>
                          </wp-input>
                        </template>
                        <template v-else-if="index === 0">
                          <p class="start_score2">0%</p>
                        </template>
                        - 含
                        <wp-input
                          v-if="index < anotherData.length -1"
                          v-model="localEduValueList[localSelectId][index]"
                          width="40%"
                          maxlength="20"
                          type="number"
                          @input="checkEduHandler(localEduValueList[localSelectId][index], index)"
                        >
                          <p slot="suffix">%</p>
                        </wp-input>
                        <p v-else class="start_score2">100%</p>
                      </div>
                    </template>
                  </a-table>
                </td>
              </tr>
            </tbody>
          </table>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :offset="4.2" :span="10">
          <wp-button-group>
            <!-- <wp-button
              type="main"
              size="large"
              background="primary"
              :disabled="secondDisabledFlag"
              @click="saveedu"
              v-if="localScoreType === 'P'  && platform === 'education'"
            >保存</wp-button>
            <wp-button
              type="main"
              size="large"
              background="primary"
              :disabled="secondDisabledFlag"
              @click="save"
              v-else
            >保存</wp-button>-->
            <wp-button type="main" size="large" background="primary" @click="next(2)">下一步</wp-button>
            <wp-button type="second" background="primary" size="large" @click="prev(1)">上一步</wp-button>
            <!-- <nuxt-link
              v-if="$store.state.globalSetting &&  platform === 'school'"
              to="/globalSetting"
            >
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>
            <nuxt-link v-if=" platform === 'education'" to="/eduGlobalsetting">
              <wp-button type="second" background="primary" size="large">取消</wp-button>
            </nuxt-link>-->
          </wp-button-group>
        </wp-col>
      </wp-row>
    </template>

    <template v-if="showFlagThree">
      <wp-row>
        <wp-col :span="4" align="right">
          <h4 class="title">必修课成绩</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right" class="assess_label">科目:</wp-col>
        <wp-col :span="18" :offset=".2">
          <div v-for="(item, index) in localRankItems" :key="item" class="type_item">
            {{item}}
            <i
              class="type_item_icon"
              v-if="index === localRankItems.length - 1"
              @click="removeitem(index)"
            >
              <wp-icon name="close" fill="#ffffff" font-size="12px"></wp-icon>
            </i>
          </div>
          <div class="type_item_add" @click="addrankitem">
            <wp-icon name="add-pure" font-size="12px"></wp-icon>
          </div>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right" class="assess_label">成绩字段:</wp-col>
        <wp-col :span="18" :offset=".2">
          <wp-radio v-model="localinputValueType" label="G" type="button">等第</wp-radio>
          <wp-radio v-model="localinputValueType" label="S" type="button">分值</wp-radio>
        </wp-col>
      </wp-row>
      <wp-button type="main" size="large" background="primary" @click="next(3)">下一步</wp-button>
      <wp-button type="second" background="primary" size="large" @click="prev(2)">上一步</wp-button>
    </template>

    <template v-if="showFlagFour">
      写实记录设置
      <wp-button
        type="main"
        size="large"
        background="primary"
        :disabled="secondDisabledFlag"
        @click="saveedu"
        v-if="localScoreType === 'P'  && platform === 'education'"
      >保存</wp-button>
      <wp-button
        type="main"
        size="large"
        background="primary"
        :disabled="secondDisabledFlag"
        @click="save"
        v-else
      >保存</wp-button>
      <wp-button type="second" background="primary" size="large" @click="prev(3)">上一步</wp-button>
    </template>

    <wp-alert
      :visible="setting_show"
      type="success"
      title="统一设置"
      @close="setting_show = false"
      @confirm="setallscore"
      :width="500"
    >
      <p class="setting_alert_notice">所有学校将被设置为相同比例。</p>
      <p />
      <a-table
        :columns="persentColumns"
        :data-source="anotherData"
        :pagination="false"
        bordered
        :locale="{emptyText: '暂无数据'}"
      >
        <template slot="score" slot-scope="text, record, index">
          <div>
            <template v-if="index > 0">
              <wp-input
                v-model="allscoreScope[index-1]"
                width="40%"
                maxlength="20"
                type="number"
                @input="checkallHandler(allscoreScope[index-1], index-1)"
              >
                <p slot="suffix">%</p>
              </wp-input>
            </template>
            <template v-else-if="index === 0">
              <p class="start_score">0%</p>
            </template>
            - 含
            <wp-input
              v-if="index < anotherData.length -1"
              v-model="allscoreScope[index]"
              width="40%"
              maxlength="20"
              type="number"
              @input="checkallHandler(allscoreScope[index], index)"
            >
              <p slot="suffix">%</p>
            </wp-input>
            <p v-else class="start_score">100%</p>
          </div>
        </template>
      </a-table>
    </wp-alert>

    <wp-alert
      :visible="detail_show"
      width="698"
      title="更多信息"
      @close="detail_show = false"
      @confirm="detail_show = false"
    >
      <div slot="default" class="score-detail-body">
        <wp-row>
          <wp-col :span="5" align="right">
            <h4 class="score-detail-title">{{inputValueType ==='G' ? '等第' : '分值' }}信息</h4>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">类型:</wp-col>
          <wp-col :span="15" :offset="0.2">
            <div v-for="item in rankItems" :key="item" class="type_show_item">{{item}}</div>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">录入形式:</wp-col>
          <wp-col :span="15" :offset="0.2">
            <wp-tag type="hollow" border-color="#C1DDF2" color="#317EEB" background="#E7F3FC">
              {{
              inputValueType.replace('S', '分值').replace('G', '等第')
              }}
            </wp-tag>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">
            <h4 class="score-detail-title">等第分值转换</h4>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">单项转换：</wp-col>
          <wp-col :span="15" :offset="0.2">
            <a-table
              :columns="columns"
              :data-source="scoreList"
              :pagination="false"
              bordered
              :locale="{emptyText: '暂无数据'}"
            >
              <template v-for="(col, index) in rankItems" :slot="col">
                <div :key="index">{{rankValues[index]}}</div>
              </template>
            </a-table>
          </wp-col>
        </wp-row>
        <wp-row>
          <wp-col :span="5" align="right">
            <wp-tooltip position="right" class="convert_tool" style="top: 0;">
              <wp-icon name="question-fill" fill="#cccccc"></wp-icon>
              <p slot="content">转换需基于各评价人针对各一级指标的评价平均分</p>
            </wp-tooltip>一级指标转换:
          </wp-col>
          <wp-col :span="15" :offset="0.2">
            <p class="tip mb10">
              <wp-tag type="hollow" background="#E7F3FC">{{scoreType === 'S' ? '按分数段' : '按分数排名比例'}}</wp-tag>
            </p>
            <a-table
              v-if="scoreType === 'S'"
              :columns="columns"
              :data-source="scoreList"
              :pagination="false"
              bordered
              :locale="{emptyText: '暂无数据'}"
            >
              <template v-for="(col, index) in rankItems" :slot="col">
                <div :key="index">
                  <template v-if="index < scoreScope.length -1">
                    <span class="score-table-span">{{scoreScope[index + 1]}}</span>
                  </template>
                  <template v-else>
                    <span class="score-table-span">0</span>
                  </template>
                  - 含
                  <span class="score-table-span">{{scoreScope[index]}}</span>
                </div>
              </template>
            </a-table>
            <a-table
              v-if="scoreType === 'P'"
              :columns="columns"
              :data-source="scoreList"
              :pagination="false"
              bordered
              :locale="{emptyText: '暂无数据'}"
            >
              <template v-for="(col, index) in rankItems" :slot="col">
                <div :key="index">
                  <template v-if="index > 0">
                    <span class="score-table-span">{{scoreScope[index-1]}}%</span>
                  </template>
                  <template v-else-if="index === 0">
                    <span class="score-table-span">0%</span>
                  </template>
                  - 含
                  <span
                    v-if="index < anotherData.length -1"
                    class="score-table-span"
                  >{{scoreScope[index]}}%</span>
                  <span v-else class="score-table-span">100%</span>
                </div>
              </template>
            </a-table>
          </wp-col>
        </wp-row>
      </div>
    </wp-alert>
  </div>
</template>

<script>
import { deepClone } from '~/utils/tools'
import { deleteIndex } from '~/utils/tools'
const anotherColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '对应评价平均分（保留1位小数）',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]
const persentColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '排名比例',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]

export default {
  name: '',
  scrollToTop: true,
  components: {},
  data() {
    return {
      showFlagOne: true,
      showFlagTwo: false,
      showFlagThree: false,
      showFlagFour: false,
      detail_show: false,
      setting_show: false,
      columns: [],
      data: [],
      anotherColumns,
      persentColumns,
      anotherData: [],
      scoreScope: [],
      localRankItems: this.rankItems,
      localinputValueType: this.inputValueType,
      localmutualType: this.mutualType,
      localInputTypes: this.inputTypes,
      localAuditorTypes: this.auditorTypes,
      localPeopleTypesMap: this.peopleTypesMap,
      localScoreType: this.scoreType,
      localRankValues: this.rankValues,
      localScoreScopes: this.scoreScopes,
      treeData: [],
      treeDataarr: [], //树的全部id
      localEduValueList: {}, //临时教育局数据数组
      localSelectId: '', //选择的教育局或学校id
      searchKey: '', //搜索单位值
      eduscoreScope: {}, //临时教育局数据数组(上传)
      allscoreScope: [], //统一设置的值
      setallscoretype: false, //统一设置的状态
      stepData: [
        { content: '等级评价设置', active: true, key: 0 },
        { content: '评价值转换', active: false, key: 1 },
        { content: '成绩显示设置', active: false, key: 2 },
        { content: '写实记录设置', active: false, key: 3 }
      ]
    }
  },
  props: {
    platform: {
      type: String,
      required: true
    },
    author: {
      type: Array,
      required: true
    },
    rankItems: {
      type: Array,
      required: true
    },
    inputValueType: {
      type: String,
      required: true
    },
    mutualType: {
      type: String,
      required: true
    },
    inputTypes: {
      type: Array,
      required: true
    },
    auditorTypes: {
      type: Array,
      required: true
    },
    peopleTypesMap: {
      type: Object,
      required: true
    },
    scoreType: {
      type: String,
      required: true
    },
    rankValues: {
      type: Array,
      required: true
    },
    scoreScopes: {
      type: Array,
      required: true
    }
  },
  computed: {
    firstDisabledFlag() {
      if (
        (this.platform === 'school' &&
          this.localRankItems.length &&
          this.localinputValueType.length &&
          this.localmutualType.length &&
          this.localInputTypes.length &&
          this.localAuditorTypes.length) ||
        (this.platform === 'education' &&
          this.localRankItems.length &&
          this.inputValueType)
      ) {
        return false
      } else {
        return true
      }
    },
    secondDisabledFlag() {
      if (this.localRankValues.length && this.scoreScope.length) {
        return false
      } else {
        return true
      }
    },
    scoreList() {
      const temp = []
      const map = {
        key: '0'
      }
      if (this.localRankItems.length) {
        this.localRankItems.forEach(item => {
          map[item] = ``
        })
      }
      temp.push(map)
      return temp
    },
    scoreScopesHander() {
      const temp = []
      if (this.localScoreType === 'S') {
        for (let i = 0; i < this.scoreScope.length - 1; i++) {
          temp.push(`${this.scoreScope[i + 1]}-${this.scoreScope[i]}`)
        }
        temp.push(`0-${this.scoreScope[this.scoreScope.length - 1]}`)
      } else if (this.localScoreType === 'P') {
        temp.push(`0-${this.scoreScope[0]}`)
        for (let i = 0; i < this.scoreScope.length - 1; i++) {
          temp.push(`${this.scoreScope[i]}-${this.scoreScope[i + 1]}`)
        }
        temp.push(`${this.scoreScope[this.scoreScope.length - 1]}-100`)
      }
      return temp
    }
  },
  watch: {
    localScoreType(newVal, oldVal) {
      this.scoreScope = []
      if (newVal) {
        if (newVal === 'S') {
          this.columns.forEach(item => {
            this.scoreScope.push('')
          })
        } else {
          for (let i = 0; i < this.columns.length - 1; i++) {
            this.scoreScope.push('')
          }
        }
      } else {
        this.localScoreType = oldVal
      }
    },
    // rankItem(newValue) {
    //   //firfox donot work
    //   // this.localRankItems = newValue.match(/(?<=\/|^).{1,}?(?=\/|$)/gi) || []
    //   this.localRankItems = newValue.split('/').filter(item => {
    //     return item
    //   })
    // },
    localRankItems: {
      handler: function(newValue, oldValue) {
        //if (newValue.toString() === oldValue.toString()) return
        this.localRankValues = []
        this.anotherData = []
        const tem = []
        this.columns = []
        newValue.forEach((item, index) => {
          this.columns.push({
            // 列标题
            title: item,
            // dataIndex的值与数据数组的名一一对应
            dataIndex: item,
            // 使用名为this.localRankItems[i]的插槽来填充dataIndex的值对应的数据数组的名
            scopedSlots: { customRender: item }
          })
          this.anotherData.push({
            key: index,
            rank: item,
            score: ``
          })
          tem.push('')
        })
        this.scoreScope = tem
      }
    },
    scoreScope: {
      handler: function(newVal, oldValue) {
        const temp = []
        if (this.localScoreType === 'S') {
          for (let i = 0; i < this.scoreScope.length - 1; i++) {
            temp.push(`${this.scoreScope[i + 1]}-${this.scoreScope[i]}`)
          }
          temp.push(`0-${this.scoreScope[this.scoreScope.length - 1]}`)
        } else if (this.localScoreType === 'P') {
          temp.push(`0-${this.scoreScope[0]}`)
          for (let i = 0; i < this.scoreScope.length - 1; i++) {
            temp.push(`${this.scoreScope[i]}-${this.scoreScope[i + 1]}`)
          }
          temp.push(`${this.scoreScope[this.scoreScope.length - 1]}-100`)
        }
        this.localScoreScopes = temp
      },
      deep: true
    }
  },
  created() {
    this.initData()
  },
  methods: {
    initData() {
      //this.rankItem = this.localRankItems.join('/')
      this.$nextTick(() => {
        this.localRankItems.forEach((item, index) => {
          this.columns.push({
            // 列标题
            title: item,
            // dataIndex的值与数据数组的名一一对应
            dataIndex: item,
            // 使用名为this.localRankItems[i]的插槽来填充dataIndex的值对应的数据数组的名
            scopedSlots: { customRender: item }
          })
          this.anotherData.push({
            key: index,
            rank: item,
            score: ``,
            persent: ''
          })
          if (
            this.localScoreType === 'P' &&
            index === this.localRankItems.length - 1
          ) {
            return
          } else {
            this.scoreScope.push(
              this.localScoreScopes[index]
                ? Number(this.localScoreScopes[index].split('-')[1]).toFixed(1)
                : ''
            )
            this.allscoreScope.push('')
          }
        })
        if (this.localScoreType === 'P' && this.platform === 'education') {
          this.getunittree()
        }
      })
    },
    next(key) {
      if (!this.firstDisabledFlag && key == 1) {
        this.showFlagOne = false
        this.showFlagTwo = true
      }
      if (key == 2) {
        this.showFlagTwo = false
        this.showFlagThree = true
      }
      if (key == 3) {
        this.showFlagThree = false
        this.showFlagFour = true
      }
    },
    prev(key) {
      if (key == 1) {
        this.showFlagOne = true
        this.showFlagTwo = false
      }
      if (key == 2) {
        this.showFlagTwo = true
        this.showFlagThree = false
      }
      if (key == 3) {
        this.showFlagThree = true
        this.showFlagFour = false
      }
    },
    async save() {
      if (!this.secondDisabledFlag) {
        let path =
          this.platform === 'school'
            ? '/diathesis/setting/saveGlobalSchool'
            : '/diathesis/setting/saveGlobalEducation'
        const { success, msg } = await this.$axios.$post(path, {
          id: this.id,
          rankItems: this.localRankItems,
          rankValues: this.localRankValues,
          inputValueType: this.localinputValueType,
          mutualType: this.localmutualType, //学生互评录入形式
          inputTypes: this.localInputTypes,
          auditorTypes: this.localAuditorTypes,
          scoreScopes: this.localScoreScopes,
          scoreType: this.localScoreType
        })
        if (success) {
          this.$warn.show({ title: '修改成功' })
          if (this.platform === 'school') {
            this.$router.replace({
              path: '/globalSetting'
            })
          } else {
            this.$router.replace({
              path: '/eduGlobalsetting'
            })
          }
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
    },
    //保存教育局按分数排名比例
    async saveedu() {
      if (!this.secondDisabledFlag) {
        let path = '/diathesis/setting/saveGlobalEducation'
        const { success, msg } = await this.$axios.$post(path, {
          id: this.id,
          rankItems: this.localRankItems,
          rankValues: this.localRankValues,
          inputValueType: this.localinputValueType,
          scoreType: this.localScoreType,
          educationScoreScopesMap: this.checkarr(this.localEduValueList)
        })
        if (success) {
          this.$warn.show({ title: '修改成功' })
          this.$router.replace({
            path: '/eduGlobalsetting'
          })
        } else {
          this.$warn.show({ title: msg || '请求失败' })
        }
      }
    },
    //统一设置树是否有子集，循环
    expansub(arr) {
      arr.forEach((item, index) => {
        this.treeDataarr.push(item.id)
        if (item.childList) {
          this.expansub(item.childList)
        }
      })
    },
    //统一设置分数
    setallscore() {
      this.setallscoretype = true
      this.treeDataarr.forEach(item => {
        this.$set(this.localEduValueList, item, this.allscoreScope)
      })
      this.setting_show = false
    },
    //比例数组转字符串数组
    checkarr(arr) {
      this.eduscoreScope = {}
      for (let key in arr) {
        let temp = []
        temp.push(`0-${arr[key][0]}`)
        for (let i = 0; i < arr[key].length - 1; i++) {
          temp.push(`${arr[key][i]}-${arr[key][i + 1]}`)
        }
        temp.push(`${arr[key][arr[key].length - 1]}-100`)
        this.$set(this.eduscoreScope, key, temp)
      }
      return this.eduscoreScope
    },
    checkHandler(val, index) {
      let reg = /^[1-9]\d*$/
      if (!reg.test(val)) {
        this.$warn.show({ title: '分值需是正整数，请重新输入' })
        this.localRankValues[index] = ''
      }
    },
    checkInpHandler(val, index) {
      if (!val) return
      let reg = /^\d*\.?\d?$/
      if (!reg.test(val)) {
        this.$warn.show({
          title: '平均分需是正浮点数且保留1位小数，请重新输入'
        })
        this.scoreScope[index] = ''
      }
    },
    //教育局判断
    checkEduHandler(val, index) {
      if (!val) return
      let reg = /^\d*\.?\d?$/
      if (!reg.test(val)) {
        this.$warn.show({
          title: '平均分需是正浮点数且保留1位小数，请重新输入'
        })
        this.localEduValueList[this.localSelectId][index] = ''
      }
    },
    //统一设置判断
    checkallHandler(val, index) {
      if (!val) return
      let reg = /^\d*\.?\d?$/
      if (!reg.test(val)) {
        this.$warn.show({
          title: '平均分需是正浮点数且保留1位小数，请重新输入'
        })
        this.allscoreScope[index] = ''
      }
    },
    //删除类型
    removeitem(index) {
      deleteIndex(this.localRankItems, index)
    },
    //添加类型
    addrankitem() {
      if (this.localRankItems.length >= 7) {
        this.$warn.show({ title: '类型不能超过7个' })
      } else {
        let rank = this.localRankItems[this.localRankItems.length - 1]
        switch (rank) {
          case 'A':
            this.localRankItems.push('B')
            break
          case 'B':
            this.localRankItems.push('C')
            break
          case 'C':
            this.localRankItems.push('D')
            break
          case 'D':
            this.localRankItems.push('E')
            break
          case 'E':
            this.localRankItems.push('F')
            break
          case 'F':
            this.localRankItems.push('G')
            break
          default:
            this.localRankItems.push('A')
        }
      }
    },
    //判断树是否有子集，循环
    circulatesub(arr) {
      arr.forEach((item, index) => {
        item.label = item.name
        if (item.childList) {
          item.children = this.circulatesub(item.childList)
        }
      })
      return arr
    },
    //获取单位树
    async getunittree() {
      const unitlist = await this.$axios.$get(
        '/diathesis/unitQuery/findUnitList'
      )
      let treeData = this.circulatesub(unitlist)
      this.treeData = treeData
      this.expansub(treeData)
    },
    //判断展开还是
    //点击最小树获取分数
    async selectitem(item) {
      this.$refs.mytree.selected = item
      if (this.localEduValueList.hasOwnProperty(item.id)) {
        this.localSelectId = item.id
        return
      }
      if (this.setallscoretype) {
        this.$set(this.localEduValueList, item.id, this.allscoreScope)
        this.localSelectId = item.id
      } else {
        let scorearr = await this.$axios.$get(
          `/diathesis/setting/findScoreScopes?unitId=${item.id}`
        )
        let tem = []
        this.localRankItems.forEach((item, index) => {
          tem.push(
            scorearr[index]
              ? Number(scorearr[index].split('-')[1]).toFixed(1)
              : ''
          )
        })
        deleteIndex(tem, tem.length - 1)
        this.$set(this.localEduValueList, item.id, tem)
        this.localSelectId = item.id
      }
    }
  }
}
</script>


<style lang="scss" scoped>
/deep/ .wp-radio--button {
  height: 32px;
  padding: 0 16px;
  line-height: 28px;
}
/deep/.wp-radio--button .wp-radio__text {
  font-size: 14px;
  line-height: 14px;
}
/deep/.wp-radio + .wp-radio--button {
  margin-left: 10px;
}
/deep/.wp-checkbox__text {
  padding-left: 0;
}
/deep/ .wp-step {
  background: #e7f3fc;
  height: 60px;
  line-height: 60px;
  .is-active {
    color: #317eeb;
    & > span i {
      background: #317eeb;
      color: #fff;
    }
  }
}
/deep/ .wp_clearfix {
  text-align: center !important;
}
.ant-table table td {
  white-space: nowrap;
}
.wp-checkbox-group .wp-checkbox {
  margin-right: 10px;
}
.title {
  display: inline-block;
  padding-left: 10px;
  margin-top: 30px;
  font-size: 16px;
  line-height: 18px;
  border-left: 5px solid #317eeb;
}
.tip {
  color: #faad14;
  padding-top: 3px;
}
.mb10 {
  margin-bottom: 10px;
}
.f16 {
  font-size: 14px;
}
.start_score1 {
  display: inline-block;
  width: 50px;
  padding-left: 10px;
}
.start_score {
  display: inline-block;
  width: 150px;
  padding-left: 10px;
}
.start_score2 {
  display: inline-block;
  width: 40%;
  padding-left: 10px;
}
.allUnitsTable {
  text-align: left;
  width: 100%;
  margin-top: 10px;
  border: 1px solid #cccccc;
  th,
  td {
    vertical-align: top;
    padding: 10px;
  }
}
.evaluationTip {
  font-size: 14px;
  color: #666666;
  padding: 6px 20px;
  background: #e7f3fc;
  border: 1px solid #c1ddf2;
  border-radius: 2px;
}
.setting_alert_notice {
  padding: 10px;
  background: #e6f7ff;
  border: 1px solid #9bc9ff;
  border-radius: 4px;
  margin-bottom: 10px;
}
.type_show_item {
  display: inline-block;
  padding: 6px 11px;
  font-size: 14px;
  color: #317eeb;
  line-height: 20px;
  background: #e7f3fc;
  margin-right: 5px;
  border-radius: 16px;
  position: relative;
  border: 1px solid #c1ddf2;
}
.type_item {
  width: 32px;
  height: 32px;
  text-align: center;
  line-height: 32px;
  display: inline-block;
  font-size: 14px;
  color: #ffffff;
  background: #347ee9;
  margin-right: 5px;
  border-radius: 16px;
  position: relative;
}
.type_item_icon {
  position: absolute;
  background: #f5222d;
  width: 12px;
  height: 12px;
  border-radius: 6px;
  top: -4px;
  right: 0;
  cursor: pointer;
  line-height: 9px;
}
.type_item_add {
  display: inline-block;
  padding: 10px;
  font-size: 12px;
  color: #333333;
  background: #ffffff;
  border: 1px solid #cccccc;
  margin-right: 5px;
  border-radius: 16px;
  cursor: pointer;
  line-height: 12px;
}
.type_item_add:hover {
  border-color: #347ee9;
}
.type_item_add:hover .icon {
  fill: #347ee9;
}
.type_item_custom {
  display: inline-block;
  padding: 6px 11px;
  font-size: 14px;
  color: #333333;
  background: #ffffff;
  border: 1px solid #cccccc;
  line-height: 20px;
  margin-right: 5px;
  border-radius: 16px;
  cursor: pointer;
}
.type_item_custom:hover {
  border-color: #347ee9;
  color: #347ee9;
}
.assess_label {
  line-height: 32px;
}
.convert_tool {
  margin-right: 3px;
  top: -3px;
}
</style>
