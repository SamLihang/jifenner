<template>
  <div>
    <wp-row>
      <wp-col :span="4" align="right">
        <h4 class="title">{{inputValueType ==='G' ? '等第' : '分值' }}信息</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="4" align="right">类型:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <div v-for="item in rankItems" :key="item" class="type_item">{{item}}</div>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="4" align="right">录入形式:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <wp-tag type="hollow" border-color="#C1DDF2" color="#317EEB" background="#E7F3FC">
          {{
          inputValueType.replace('S', '分值').replace('G', '等第')
          }}
        </wp-tag>
      </wp-col>
    </wp-row>
    <template v-if="platform==='school'">
      <wp-row>
        <wp-col :span="4" align="right">
          <h4 class="title">录入人员</h4>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right">学生互评形式:</wp-col>
        <wp-col :span="10" :offset="0.2">
          <wp-tag
            type="hollow"
            border-color="#C1DDF2"
            color="#317EEB"
            background="#E7F3FC"
          >{{formatMutualType(mutualType)}}</wp-tag>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right">录入人:</wp-col>
        <wp-col :span="10" :offset="0.2">
          <span class="f16" v-for="(inputType,index) in inputTypes" :key="index">
            <wp-tag
              type="hollow"
              border-color="#C1DDF2"
              color="#317EEB"
              background="#E7F3FC"
              style="margin-right: 10px;"
            >{{peopleTypesMap[inputType]}}</wp-tag>
          </span>
        </wp-col>
      </wp-row>
      <wp-row>
        <wp-col :span="4" align="right">审核人:</wp-col>
        <wp-col :span="10" :offset="0.2">
          <span class="f16" v-for="(auditorType,index) in auditorTypes" :key="index">
            <wp-tag
              type="hollow"
              border-color="#C1DDF2"
              color="#317EEB"
              background="#E7F3FC"
              style="margin-right: 10px;"
            >{{peopleTypesMap[auditorType]}}</wp-tag>
          </span>
        </wp-col>
      </wp-row>
    </template>
    <wp-row>
      <wp-col :span="4" align="right">
        <h4 class="title">等第分值转换</h4>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="4" align="right">单项转换:</wp-col>
      <wp-col :span="10" :offset="0.2">
        <a-table
          bordered
          :columns="columns"
          :data-source="data"
          :pagination="false"
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="4" align="right">
        <wp-tooltip position="right" class="convert_tool">
          <wp-icon name="question-fill" fill="#cccccc"></wp-icon>
          <p slot="content">转换需基于各评价人针对各一级指标的评价平均分</p>
        </wp-tooltip>一级指标转换:
      </wp-col>
      <wp-col :span="10" :offset="0.2">
        <wp-tag type="hollow" border-color="#C1DDF2" color="#317EEB" background="#E7F3FC">
          {{
          scoreType === 'S' ? '按分数段' : '按分数排名比例'
          }}
        </wp-tag>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :span="10" :offset="4.2">
        <a-table
          v-if="scoreType === 'S'"
          :columns="columns"
          :data-source="anotherData"
          :pagination="false"
          bordered
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
        <a-table
          v-if="scoreType === 'P' && platform === 'school'"
          :columns="persentColumns"
          :data-source="anotherData"
          :pagination="false"
          bordered
          :locale="{emptyText: '暂无数据'}"
        ></a-table>
      </wp-col>
    </wp-row>
    <wp-row v-if="scoreType === 'P'  && platform === 'education'" style="margin-top:0;">
      <wp-col :span="15" :offset="4.2">
        <table border="1" class="allUnitsTable">
          <colgroup>
            <col width="180px" />
          </colgroup>
          <thead>
            <tr>
              <th colspan="2">
                <p class="wp_fl">所有单位</p>
                <wp-input
                  placeholder="请输入姓名"
                  width="200px"
                  maxlength="20"
                  class="wp_fr"
                  v-model="searchKey"
                >
                  <wp-icon slot="suffix" name="search" @click.native="searchHandler"></wp-icon>
                </wp-input>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding:0">
                <wp-tree
                  :data="treeData"
                  width="180px"
                  @select="selectitem"
                  @expand="selectitem"
                  :default_select="treeData.length ? treeData[0] : null"
                  :filter="searchKey"
                  open_icon="angle-single-right"
                  close_icon="angle-single-right"
                  ref="mytree"
                ></wp-tree>
              </td>
              <td>
                <a-table
                  :columns="persentColumns"
                  :data-source="anotherData"
                  :pagination="false"
                  bordered
                  :locale="{emptyText: '暂无数据'}"
                >
                  <template slot="score" slot-scope="text, record, index">
                    <div v-if="localSelectId">
                      <template v-if="index > 0">
                        <p class="start_score2">{{localEduValueList[localSelectId][index-1]}}%</p>
                      </template>
                      <template v-else-if="index === 0">
                        <p class="start_score2">0%</p>
                      </template>
                      - 含
                      <p
                        v-if="index < anotherData.length -1"
                        class="start_score2"
                      >{{localEduValueList[localSelectId][index]}}%</p>
                      <p v-else class="start_score2">100%</p>
                    </div>
                  </template>
                </a-table>
              </td>
            </tr>
          </tbody>
        </table>
      </wp-col>
    </wp-row>
    <wp-row>
      <wp-col :offset="4.2" :span="5">
        <nuxt-link :to="settingPath[platform]">
          <wp-button type="main" background="primary" size="large">修改</wp-button>
        </nuxt-link>
      </wp-col>
    </wp-row>
  </div>
</template>


<script>
import { formatMutualType } from '~/utils/format'
import { deleteIndex } from '~/utils/tools'

const persentColumns = [
  {
    title: '对应等第',
    dataIndex: 'rank'
  },
  {
    title: '排名比例',
    dataIndex: 'score',
    scopedSlots: { customRender: 'score' }
  }
]

export default {
  name: 'globalSetting',
  data() {
    return {
      persentColumns,
      settingPath: {
        school: '/globalSetting/setting',
        education: '/eduGlobalSetting/setting'
      },
      treeData: [],
      treeDataarr: [], //树的全部id
      localEduValueList: {}, //临时教育局数据数组
      localSelectId: '', //选择的教育局或学校id
      searchKey: '' //搜索单位值
    }
  },
  props: {
    platform: {
      type: String,
      required: true
    },
    author: {
      type: Array,
      required: true
    },
    rankItems: {
      type: Array,
      required: true
    },
    inputValueType: {
      type: String,
      required: true
    },
    inputTypes: {
      type: Array,
      required: true
    },
    mutualType: {
      type: String,
      required: true
    },
    auditorTypes: {
      type: Array,
      required: true
    },
    peopleTypesMap: {
      type: Object,
      required: true
    },
    scoreType: {
      type: String,
      required: true
    },
    rankValues: {
      type: Array,
      required: true
    },
    scoreScopes: {
      type: Array,
      required: true
    }
  },
  methods: {
    formatMutualType(mutualType) {
      return formatMutualType(mutualType)
    },
    //判断树是否有子集，循环
    circulatesub(arr) {
      arr.forEach((item, index) => {
        item.label = item.name
        if (item.childList) {
          item.children = this.circulatesub(item.childList)
        }
      })
      return arr
    },
    //获取单位树
    async getunittree() {
      const unitlist = await this.$axios.$get(
        '/diathesis/unitQuery/findUnitList'
      )
      let treeData = this.circulatesub(unitlist)
      this.treeData = treeData
    },
    //点击最小树获取分数
    async selectitem(item) {
      this.$refs.mytree.selected = item
      if (this.localEduValueList.hasOwnProperty(item.id)) {
        this.localSelectId = item.id
        return
      }
      let scorearr = await this.$axios.$get(
        `/diathesis/setting/findScoreScopes?unitId=${item.id}`
      )
      let tem = []
      this.rankItems.forEach((item, index) => {
        tem.push(
          scorearr[index]
            ? Number(scorearr[index].split('-')[1]).toFixed(1)
            : ''
        )
      })
      deleteIndex(tem, tem.length - 1)
      this.$set(this.localEduValueList, item.id, tem)
      this.localSelectId = item.id
    }
  },
  created() {
    this.getunittree()
  },
  computed: {
    columns() {
      const temp = []
      this.rankItems.forEach(item => {
        temp.push({
          title: item,
          dataIndex: item,
          scopedSlots: { customRender: item }
        })
      })
      return temp
    },
    data() {
      const temp = []
      const map = Object.create(null)
      for (let i = 0; i < this.rankItems.length; i++) {
        map[this.rankItems[i]] = this.rankValues[i]
        map.key = i
      }
      temp.push(map)
      return temp
    },
    anotherData() {
      const temp = []
      const minarr = {}
      if (this.scoreType === 'S') {
        for (let i = 0; i < this.rankItems.length; i++) {
          minarr[this.rankItems[i]] = this.scoreScopes[i]
        }
        temp.push(minarr)
      } else if (this.scoreType === 'P') {
        for (let i = 0; i < this.rankItems.length; i++) {
          let score = this.scoreScopes[i]
            .split('-')
            .map(item => {
              return `${item}%`
            })
            .join('-')
          temp.push({
            key: i,
            rank: this.rankItems[i],
            score: score
          })
        }
      }
      return temp
    }
  }
}
</script>

<style lang="scss" scoped>
.title {
  padding-left: 12px;
  margin-top: 30px;
  font-size: 16px;
  line-height: 18px;
  display: inline-block;
}
.tip {
  color: #999;
}
.mb10 {
  margin-bottom: 10px;
}
.f16 {
  font-size: 14px;
}
.type_item {
  display: inline-block;
  width: 32px;
  height: 32px;
  text-align: center;
  font-size: 14px;
  color: #317eeb;
  line-height: 31px;
  background: #e7f3fc;
  margin-right: 5px;
  border-radius: 16px;
  position: relative;
  border: 1px solid #c1ddf2;
}
.convert_tool {
  margin-right: 3px;
  top: -3px;
}
.start_score2 {
  display: inline-block;
  width: 40%;
  padding-left: 10px;
}
.allUnitsTable {
  text-align: left;
  width: 100%;
  margin-top: 10px;
  border: 1px solid #cccccc;
  th,
  td {
    vertical-align: top;
    padding: 10px;
  }
}
</style>
