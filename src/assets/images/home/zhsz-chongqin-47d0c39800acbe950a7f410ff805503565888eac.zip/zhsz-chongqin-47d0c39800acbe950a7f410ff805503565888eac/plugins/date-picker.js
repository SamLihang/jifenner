import DatePicker from 'vue2-datepicker'
import Vue from 'vue'

Vue.component('date-picker', DatePicker)
