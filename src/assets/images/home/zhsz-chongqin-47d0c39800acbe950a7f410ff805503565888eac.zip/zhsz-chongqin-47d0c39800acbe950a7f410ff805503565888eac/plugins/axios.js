export default function({ app, $axios, redirect, store, query }) {
  $axios.onRequest(config => {
    // console.log('onRequest：', config)
    if (app.$cookie.get('JSESSIONID') !== query.ckjid) {
      config.headers.common.cookie = `JSESSIONID=${query.ckjid}`
    }
    // console.log('onRequest：', config)
    return config
  })
  $axios.onResponse(res => {
    // console.log('onResponse:', res.data)
    if (typeof res.data === 'string') {
      if (~res.data.indexOf('script')) redirect(app.context.url)
    }
    // 如果返回是文件二进制流， 提取文件名 返回 二进制流
    if (res.headers['content-type'] === 'application/data;charset=UTF-8') {
      // firfox donot work
      // const attachment = res.headers['content-disposition'].match(
      //   /(?<=filename=).*/gi
      // )
      const attachment = res.headers['content-disposition'].split('filename=')
      const fileName = attachment ? decodeURIComponent(attachment[1]) : ''
      res.data = {
        fileName: fileName,
        blob: res.data
      }
    }
    if (
      res.data.msg === '请先初始化全局设置!' ||
      res.data.msg === '查不到该单位的类目信息,请先全局设置'
    ) {
      store.commit('changeInitAlert')
    }
    if (
      res.data ===
      '<script>top.location.href = "http://xk.msyk.cn:80/homepage/loginPage/page";</script>'
    ) {
      redirect('/error')
    }
  })
  $axios.onError(error => {
    const code = parseInt(error.response && error.response.status)
    if (code === 400) {
      redirect('/400')
    }
    if (code === 404) {
      redirect('/404')
    }
    if (code === 499) {
      redirect('/499')
    }
  })
}
