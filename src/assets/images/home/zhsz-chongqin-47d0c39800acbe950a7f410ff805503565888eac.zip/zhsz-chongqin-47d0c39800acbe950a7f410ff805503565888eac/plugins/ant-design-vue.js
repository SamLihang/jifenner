import Vue from 'vue'
import Table from 'ant-design-vue/lib/table'
import LocalProvider from 'ant-design-vue/lib/locale-provider'
import InputNumber from 'ant-design-vue/lib/input-number'

Vue.component(Table.name, Table)
Vue.component(LocalProvider.name, LocalProvider)
Vue.component(InputNumber.name, InputNumber)
