const api = require('./api.json')
const fs = require('fs')

// console.log(api)

