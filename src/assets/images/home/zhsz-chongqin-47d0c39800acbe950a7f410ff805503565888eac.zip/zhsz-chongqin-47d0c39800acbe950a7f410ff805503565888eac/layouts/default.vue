<template>
  <div class="iframe-outter">
    <a-locale-provider :locale="zh_CN">
      <nuxt/>
    </a-locale-provider>
    <wp-alert
      :visible="initAlertState"
      type="danger"
      title="警告"
      message="未初始化全局设置!"
      description="请先联系管理员初始化全局设置。"
      :closeAble="false"
    ></wp-alert>
  </div>
</template>
<script>
import { mapState } from 'vuex'
import zh_CN from 'ant-design-vue/lib/locale-provider/zh_CN'
import moment from 'moment'
import 'moment/locale/zh-cn'
moment.locale('zh-cn')
export default {
  data() {
    return {
      zh_CN
    }
  },
  computed: {
    ...mapState(['initAlertState'])
  }
}
</script>

<style lang="scss" scoped>
.iframe-outter {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: auto;
  padding: 20px;
  background: #f4f4f4;
}
</style>
