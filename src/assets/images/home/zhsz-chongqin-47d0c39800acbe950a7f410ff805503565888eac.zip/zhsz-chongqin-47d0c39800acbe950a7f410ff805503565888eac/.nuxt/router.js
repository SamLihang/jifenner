import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _516a16f6 = () => interopDefault(import('..\\pages\\academicRecordEntry\\index.vue' /* webpackChunkName: "pages_academicRecordEntry_index" */))
const _1dfa8a98 = () => interopDefault(import('..\\pages\\comprehensiveQualityEntry\\index.vue' /* webpackChunkName: "pages_comprehensiveQualityEntry_index" */))
const _1be4b09e = () => interopDefault(import('..\\pages\\eduGlobalSetting\\index.vue' /* webpackChunkName: "pages_eduGlobalSetting_index" */))
const _368c669c = () => interopDefault(import('..\\pages\\eduProjectSetting\\index.vue' /* webpackChunkName: "pages_eduProjectSetting_index" */))
const _946788e0 = () => interopDefault(import('..\\pages\\eduProjectSetting\\index\\index.vue' /* webpackChunkName: "pages_eduProjectSetting_index_index" */))
const _69efafcb = () => interopDefault(import('..\\pages\\eduProjectSetting\\index\\realisticRecordSetting.vue' /* webpackChunkName: "pages_eduProjectSetting_index_realisticRecordSetting" */))
const _0687605c = () => interopDefault(import('..\\pages\\eduStudentQuery\\index.vue' /* webpackChunkName: "pages_eduStudentQuery_index" */))
const _44c3e025 = () => interopDefault(import('..\\pages\\eduSubUnitSetting.vue' /* webpackChunkName: "pages_eduSubUnitSetting" */))
const _45c1e4b6 = () => interopDefault(import('..\\pages\\eduSubUnitSetting.vue\\index.vue' /* webpackChunkName: "pages_eduSubUnitSetting.vue_index" */))
const _56b46b80 = () => interopDefault(import('..\\pages\\famComprehensivequalityentry\\index.vue' /* webpackChunkName: "pages_famComprehensivequalityentry_index" */))
const _c8795500 = () => interopDefault(import('..\\pages\\famStudentQuery\\index.vue' /* webpackChunkName: "pages_famStudentQuery_index" */))
const _6fbcc852 = () => interopDefault(import('..\\pages\\globalSetting\\index.vue' /* webpackChunkName: "pages_globalSetting_index" */))
const _44c6899d = () => interopDefault(import('..\\pages\\mulualEvaluation\\index.vue' /* webpackChunkName: "pages_mulualEvaluation_index" */))
const _0be4ab7e = () => interopDefault(import('..\\pages\\projectSetting\\index.vue' /* webpackChunkName: "pages_projectSetting_index" */))
const _17bb5f44 = () => interopDefault(import('..\\pages\\projectSetting\\index\\index.vue' /* webpackChunkName: "pages_projectSetting_index_index" */))
const _203cde81 = () => interopDefault(import('..\\pages\\projectSetting\\index\\index copy.vue' /* webpackChunkName: "pages_projectSetting_index_index copy" */))
const _6c5dea97 = () => interopDefault(import('..\\pages\\projectSetting\\index\\realisticRecordSetting.vue' /* webpackChunkName: "pages_projectSetting_index_realisticRecordSetting" */))
const _201b6f0e = () => interopDefault(import('..\\pages\\projectSetting\\index\\realisticRecordSetting copy.vue' /* webpackChunkName: "pages_projectSetting_index_realisticRecordSetting copy" */))
const _6852c031 = () => interopDefault(import('..\\pages\\realisticRecordAudit\\index.vue' /* webpackChunkName: "pages_realisticRecordAudit_index" */))
const _84fda99e = () => interopDefault(import('..\\pages\\realisticRecordAudit\\index\\index.vue' /* webpackChunkName: "pages_realisticRecordAudit_index_index" */))
const _dd2f534e = () => interopDefault(import('..\\pages\\realisticRecordAudit\\index\\audited.vue' /* webpackChunkName: "pages_realisticRecordAudit_index_audited" */))
const _208a5f3a = () => interopDefault(import('..\\pages\\realisticRecordEntry\\index.vue' /* webpackChunkName: "pages_realisticRecordEntry_index" */))
const _2b334008 = () => interopDefault(import('..\\pages\\realisticRecordEntry\\index\\index.vue' /* webpackChunkName: "pages_realisticRecordEntry_index_index" */))
const _1e65dfd7 = () => interopDefault(import('..\\pages\\realisticRecordEntry\\index\\add.vue' /* webpackChunkName: "pages_realisticRecordEntry_index_add" */))
const _2b26d83d = () => interopDefault(import('..\\pages\\realisticRecordEntry\\index\\index copy.vue' /* webpackChunkName: "pages_realisticRecordEntry_index_index copy" */))
const _62c69ddc = () => interopDefault(import('..\\pages\\roleManagement\\index.vue' /* webpackChunkName: "pages_roleManagement_index" */))
const _67a3b062 = () => interopDefault(import('..\\pages\\stuComprehensiveQualityEntry\\index.vue' /* webpackChunkName: "pages_stuComprehensiveQualityEntry_index" */))
const _2199b4e8 = () => interopDefault(import('..\\pages\\studentEvaluation\\index.vue' /* webpackChunkName: "pages_studentEvaluation_index" */))
const _2f98fbb0 = () => interopDefault(import('..\\pages\\studentQuery\\index.vue' /* webpackChunkName: "pages_studentQuery_index" */))
const _318179a0 = () => interopDefault(import('..\\pages\\stuRealisticRecordEntry\\index.vue' /* webpackChunkName: "pages_stuRealisticRecordEntry_index" */))
const _a1abc95c = () => interopDefault(import('..\\pages\\stuRealisticRecordEntry\\index\\index.vue' /* webpackChunkName: "pages_stuRealisticRecordEntry_index_index" */))
const _680f05a1 = () => interopDefault(import('..\\pages\\stuRealisticRecordEntry\\index\\add.vue' /* webpackChunkName: "pages_stuRealisticRecordEntry_index_add" */))
const _636ebc1e = () => interopDefault(import('..\\pages\\stuStudentQuery\\index.vue' /* webpackChunkName: "pages_stuStudentQuery_index" */))
const _b78f65d0 = () => interopDefault(import('..\\pages\\stuStudentReoprt\\index.vue' /* webpackChunkName: "pages_stuStudentReoprt_index" */))
const _64512976 = () => interopDefault(import('..\\pages\\subjectLevelEntry\\index.vue' /* webpackChunkName: "pages_subjectLevelEntry_index" */))
const _ab32a8a4 = () => interopDefault(import('..\\pages\\academicRecordEntry\\detail.vue' /* webpackChunkName: "pages_academicRecordEntry_detail" */))
const _0cef2b25 = () => interopDefault(import('..\\pages\\academicRecordEntry\\download.vue' /* webpackChunkName: "pages_academicRecordEntry_download" */))
const _730d69e0 = () => interopDefault(import('..\\pages\\academicRecordEntry\\index copy.vue' /* webpackChunkName: "pages_academicRecordEntry_index copy" */))
const _4ca36d44 = () => interopDefault(import('..\\pages\\academicRecordEntry\\upload.vue' /* webpackChunkName: "pages_academicRecordEntry_upload" */))
const _3fea34a7 = () => interopDefault(import('..\\pages\\academicRecordEntry\\upload copy.vue' /* webpackChunkName: "pages_academicRecordEntry_upload copy" */))
const _230c1f42 = () => interopDefault(import('..\\pages\\academicRecordEntry\\uploadSetting.vue' /* webpackChunkName: "pages_academicRecordEntry_uploadSetting" */))
const _31899a38 = () => interopDefault(import('..\\pages\\comprehensiveQualityEntry\\entry.vue' /* webpackChunkName: "pages_comprehensiveQualityEntry_entry" */))
const _debd47e6 = () => interopDefault(import('..\\pages\\comprehensiveQualityEntry\\entry copy.vue' /* webpackChunkName: "pages_comprehensiveQualityEntry_entry copy" */))
const _1917a7ad = () => interopDefault(import('..\\pages\\comprehensiveQualityEntry\\index copy.vue' /* webpackChunkName: "pages_comprehensiveQualityEntry_index copy" */))
const _68f175ab = () => interopDefault(import('..\\pages\\comprehensiveQualityEntry\\upload.vue' /* webpackChunkName: "pages_comprehensiveQualityEntry_upload" */))
const _c5da2bc8 = () => interopDefault(import('..\\pages\\eduGlobalSetting\\setting.vue' /* webpackChunkName: "pages_eduGlobalSetting_setting" */))
const _142d9887 = () => interopDefault(import('..\\pages\\eduStudentQuery\\comprehensiveQualityQuery.vue' /* webpackChunkName: "pages_eduStudentQuery_comprehensiveQualityQuery" */))
const _6ebdcc69 = () => interopDefault(import('..\\pages\\eduStudentQuery\\index copy.vue' /* webpackChunkName: "pages_eduStudentQuery_index copy" */))
const _2f964c40 = () => interopDefault(import('..\\pages\\famComprehensivequalityentry\\entry.vue' /* webpackChunkName: "pages_famComprehensivequalityentry_entry" */))
const _34ce239a = () => interopDefault(import('..\\pages\\globalSetting\\index copy.vue' /* webpackChunkName: "pages_globalSetting_index copy" */))
const _5b43e4d0 = () => interopDefault(import('..\\pages\\globalSetting\\setting.vue' /* webpackChunkName: "pages_globalSetting_setting" */))
const _95b41f16 = () => interopDefault(import('..\\pages\\globalSetting\\setting copy.vue' /* webpackChunkName: "pages_globalSetting_setting copy" */))
const _8f47956e = () => interopDefault(import('..\\pages\\realisticRecordEntry\\upload.vue' /* webpackChunkName: "pages_realisticRecordEntry_upload" */))
const _7b32c002 = () => interopDefault(import('..\\pages\\stuComprehensiveQualityEntry\\entry.vue' /* webpackChunkName: "pages_stuComprehensiveQualityEntry_entry" */))
const _649a4483 = () => interopDefault(import('..\\pages\\stuComprehensiveQualityEntry\\entry copy.vue' /* webpackChunkName: "pages_stuComprehensiveQualityEntry_entry copy" */))
const _25dedfba = () => interopDefault(import('..\\pages\\stuComprehensiveQualityEntry\\index copy.vue' /* webpackChunkName: "pages_stuComprehensiveQualityEntry_index copy" */))
const _696cd410 = () => interopDefault(import('..\\pages\\stuComprehensiveQualityEntry\\mutualEvaluation.vue' /* webpackChunkName: "pages_stuComprehensiveQualityEntry_mutualEvaluation" */))
const _53520c2c = () => interopDefault(import('..\\pages\\studentQuery\\newIndex.vue' /* webpackChunkName: "pages_studentQuery_newIndex" */))
const _577d2b20 = () => interopDefault(import('..\\pages\\subjectLevelEntry\\index copy.vue' /* webpackChunkName: "pages_subjectLevelEntry_index copy" */))
const _6d9c2290 = () => interopDefault(import('..\\pages\\subjectLevelEntry\\subjectDetail.vue' /* webpackChunkName: "pages_subjectLevelEntry_subjectDetail" */))
const _969eaac4 = () => interopDefault(import('..\\pages\\subjectLevelEntry\\upload.vue' /* webpackChunkName: "pages_subjectLevelEntry_upload" */))
const _02244a55 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

const scrollBehavior = function (to, from, savedPosition) {
      const scrollWarpper = document.querySelector('.iframe-outter')
      scrollWarpper && scrollWarpper.scrollTo(0, 0)
      // if (savedPosition) {
      //   return savedPosition
      // } else {
      //   let position = {}
      //   // 目标页面子组件少于两个
      //   if (to.matched.length < 2) {
      //     // 滚动至页面顶部滚动至页面顶部
      //     position = { x: 0, y: 0 }
      //   } else if (
      //     to.matched.some(r => r.components.default.options.scrollToTop)
      //   ) {
      //     // 如果目标页面子组件中存在配置了scrollToTop为true
      //     position = { x: 0, y: 0 }
      //   }
      //   // 如果目标页面的url有锚点,  则滚动至锚点所在的位置
      //   if (to.hash) {
      //     position = { selector: to.hash }
      //   }
      //   return position
      // }
    }

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/academicRecordEntry",
<<<<<<< HEAD
      component: _516a16f6,
      name: "academicRecordEntry"
    }, {
      path: "/comprehensiveQualityEntry",
      component: _1dfa8a98,
      name: "comprehensiveQualityEntry"
    }, {
      path: "/eduGlobalSetting",
      component: _1be4b09e,
      name: "eduGlobalSetting"
    }, {
      path: "/eduProjectSetting",
      component: _368c669c,
      children: [{
        path: "",
        component: _946788e0,
        name: "eduProjectSetting-index"
      }, {
        path: "realisticRecordSetting",
        component: _69efafcb,
=======
      component: _3ec56027,
      name: "academicRecordEntry"
    }, {
      path: "/comprehensiveQualityEntry",
      component: _366a34ba,
      name: "comprehensiveQualityEntry"
    }, {
      path: "/eduGlobalSetting",
      component: _533e8f88,
      name: "eduGlobalSetting"
    }, {
      path: "/eduProjectSetting",
      component: _79beb8d4,
      children: [{
        path: "",
        component: _d4e475a4,
        name: "eduProjectSetting-index"
      }, {
        path: "realisticRecordSetting",
        component: _485ad5ed,
>>>>>>> 484d79936a4dff4c2c04058527fc3e904646e2c7
        name: "eduProjectSetting-index-realisticRecordSetting"
      }]
    }, {
      path: "/eduStudentQuery",
<<<<<<< HEAD
      component: _0687605c,
      name: "eduStudentQuery"
    }, {
      path: "/eduSubUnitSetting",
      component: _44c3e025,
      name: "eduSubUnitSetting"
    }, {
      path: "/eduSubUnitSetting.vue",
      component: _45c1e4b6,
      name: "eduSubUnitSetting.vue"
    }, {
      path: "/famComprehensivequalityentry",
      component: _56b46b80,
      name: "famComprehensivequalityentry"
    }, {
      path: "/famStudentQuery",
      component: _c8795500,
      name: "famStudentQuery"
    }, {
      path: "/globalSetting",
      component: _6fbcc852,
      name: "globalSetting"
    }, {
      path: "/mulualEvaluation",
      component: _44c6899d,
      name: "mulualEvaluation"
    }, {
      path: "/projectSetting",
      component: _0be4ab7e,
      children: [{
        path: "",
        component: _17bb5f44,
        name: "projectSetting-index"
      }, {
        path: "index copy",
        component: _203cde81,
        name: "projectSetting-index-index copy"
      }, {
        path: "realisticRecordSetting",
        component: _6c5dea97,
        name: "projectSetting-index-realisticRecordSetting"
      }, {
        path: "realisticRecordSetting copy",
        component: _201b6f0e,
        name: "projectSetting-index-realisticRecordSetting copy"
      }]
    }, {
      path: "/realisticRecordAudit",
      component: _6852c031,
      children: [{
        path: "",
        component: _84fda99e,
        name: "realisticRecordAudit-index"
      }, {
        path: "audited",
        component: _dd2f534e,
=======
      component: _5a862604,
      name: "eduStudentQuery"
    }, {
      path: "/eduSubUnitSetting",
      component: _704d7643,
      name: "eduSubUnitSetting"
    }, {
      path: "/eduSubUnitSetting.vue",
      component: _4fad18c7,
      name: "eduSubUnitSetting.vue"
    }, {
      path: "/famComprehensivequalityentry",
      component: _7f2d54de,
      name: "famComprehensivequalityentry"
    }, {
      path: "/famStudentQuery",
      component: _67f8e222,
      name: "famStudentQuery"
    }, {
      path: "/globalSetting",
      component: _205dd518,
      name: "globalSetting"
    }, {
      path: "/mulualEvaluation",
      component: _017add8a,
      name: "mulualEvaluation"
    }, {
      path: "/projectSetting",
      component: _e34bfac8,
      children: [{
        path: "",
        component: _eb6d2b34,
        name: "projectSetting-index"
      }, {
        path: "index copy",
        component: _15c2789f,
        name: "projectSetting-index-index copy"
      }, {
        path: "realisticRecordSetting",
        component: _07a747b5,
        name: "projectSetting-index-realisticRecordSetting"
      }, {
        path: "realisticRecordSetting copy",
        component: _105594b0,
        name: "projectSetting-index-realisticRecordSetting copy"
      }]
    }, {
      path: "/realisticRecordAssignmentSettings",
      component: _65d7523a,
      name: "realisticRecordAssignmentSettings"
    }, {
      path: "/realisticRecordAudit",
      component: _1fb46e62,
      children: [{
        path: "",
        component: _78aed4d3,
        name: "realisticRecordAudit-index"
      }, {
        path: "audited",
        component: _37d21f7b,
>>>>>>> 484d79936a4dff4c2c04058527fc3e904646e2c7
        name: "realisticRecordAudit-index-audited"
      }]
    }, {
      path: "/realisticRecordEntry",
<<<<<<< HEAD
      component: _208a5f3a,
      children: [{
        path: "",
        component: _2b334008,
        name: "realisticRecordEntry-index"
      }, {
        path: "add",
        component: _1e65dfd7,
        name: "realisticRecordEntry-index-add"
      }, {
        path: "index copy",
        component: _2b26d83d,
=======
      component: _af453050,
      children: [{
        path: "",
        component: _333e2cac,
        name: "realisticRecordEntry-index"
      }, {
        path: "add",
        component: _36d589f9,
        name: "realisticRecordEntry-index-add"
      }, {
        path: "index copy",
        component: _48e8384a,
>>>>>>> 484d79936a4dff4c2c04058527fc3e904646e2c7
        name: "realisticRecordEntry-index-index copy"
      }]
    }, {
      path: "/roleManagement",
<<<<<<< HEAD
      component: _62c69ddc,
      name: "roleManagement"
    }, {
      path: "/stuComprehensiveQualityEntry",
      component: _67a3b062,
      name: "stuComprehensiveQualityEntry"
    }, {
      path: "/studentEvaluation",
      component: _2199b4e8,
      name: "studentEvaluation"
    }, {
      path: "/studentQuery",
      component: _2f98fbb0,
      name: "studentQuery"
    }, {
      path: "/stuRealisticRecordEntry",
      component: _318179a0,
      children: [{
        path: "",
        component: _a1abc95c,
        name: "stuRealisticRecordEntry-index"
      }, {
        path: "add",
        component: _680f05a1,
=======
      component: _3588160c,
      name: "roleManagement"
    }, {
      path: "/stuComprehensiveQualityEntry",
      component: _122b3b00,
      name: "stuComprehensiveQualityEntry"
    }, {
      path: "/studentEvaluation",
      component: _92c2bdec,
      name: "studentEvaluation"
    }, {
      path: "/studentQuery",
      component: _57b008c6,
      name: "studentQuery"
    }, {
      path: "/stuRealisticRecordEntry",
      component: _2311e45c,
      children: [{
        path: "",
        component: _540d1320,
        name: "stuRealisticRecordEntry-index"
      }, {
        path: "add",
        component: _1296903f,
>>>>>>> 484d79936a4dff4c2c04058527fc3e904646e2c7
        name: "stuRealisticRecordEntry-index-add"
      }]
    }, {
      path: "/stuStudentQuery",
<<<<<<< HEAD
      component: _636ebc1e,
      name: "stuStudentQuery"
    }, {
      path: "/stuStudentReoprt",
      component: _b78f65d0,
      name: "stuStudentReoprt"
    }, {
      path: "/subjectLevelEntry",
      component: _64512976,
      name: "subjectLevelEntry"
    }, {
      path: "/academicRecordEntry/detail",
      component: _ab32a8a4,
      name: "academicRecordEntry-detail"
    }, {
      path: "/academicRecordEntry/download",
      component: _0cef2b25,
      name: "academicRecordEntry-download"
    }, {
      path: "/academicRecordEntry/index copy",
      component: _730d69e0,
      name: "academicRecordEntry-index copy"
    }, {
      path: "/academicRecordEntry/upload",
      component: _4ca36d44,
      name: "academicRecordEntry-upload"
    }, {
      path: "/academicRecordEntry/upload copy",
      component: _3fea34a7,
      name: "academicRecordEntry-upload copy"
    }, {
      path: "/academicRecordEntry/uploadSetting",
      component: _230c1f42,
      name: "academicRecordEntry-uploadSetting"
    }, {
      path: "/comprehensiveQualityEntry/entry",
      component: _31899a38,
      name: "comprehensiveQualityEntry-entry"
    }, {
      path: "/comprehensiveQualityEntry/entry copy",
      component: _debd47e6,
      name: "comprehensiveQualityEntry-entry copy"
    }, {
      path: "/comprehensiveQualityEntry/index copy",
      component: _1917a7ad,
      name: "comprehensiveQualityEntry-index copy"
    }, {
      path: "/comprehensiveQualityEntry/upload",
      component: _68f175ab,
      name: "comprehensiveQualityEntry-upload"
    }, {
      path: "/eduGlobalSetting/setting",
      component: _c5da2bc8,
      name: "eduGlobalSetting-setting"
    }, {
      path: "/eduStudentQuery/comprehensiveQualityQuery",
      component: _142d9887,
      name: "eduStudentQuery-comprehensiveQualityQuery"
    }, {
      path: "/eduStudentQuery/index copy",
      component: _6ebdcc69,
      name: "eduStudentQuery-index copy"
    }, {
      path: "/famComprehensivequalityentry/entry",
      component: _2f964c40,
      name: "famComprehensivequalityentry-entry"
    }, {
      path: "/globalSetting/index copy",
      component: _34ce239a,
      name: "globalSetting-index copy"
    }, {
      path: "/globalSetting/setting",
      component: _5b43e4d0,
      name: "globalSetting-setting"
    }, {
      path: "/globalSetting/setting copy",
      component: _95b41f16,
      name: "globalSetting-setting copy"
    }, {
      path: "/realisticRecordEntry/upload",
      component: _8f47956e,
      name: "realisticRecordEntry-upload"
    }, {
      path: "/stuComprehensiveQualityEntry/entry",
      component: _7b32c002,
      name: "stuComprehensiveQualityEntry-entry"
    }, {
      path: "/stuComprehensiveQualityEntry/entry copy",
      component: _649a4483,
      name: "stuComprehensiveQualityEntry-entry copy"
    }, {
      path: "/stuComprehensiveQualityEntry/index copy",
      component: _25dedfba,
      name: "stuComprehensiveQualityEntry-index copy"
    }, {
      path: "/stuComprehensiveQualityEntry/mutualEvaluation",
      component: _696cd410,
      name: "stuComprehensiveQualityEntry-mutualEvaluation"
    }, {
      path: "/studentQuery/newIndex",
      component: _53520c2c,
      name: "studentQuery-newIndex"
    }, {
      path: "/subjectLevelEntry/index copy",
      component: _577d2b20,
      name: "subjectLevelEntry-index copy"
    }, {
      path: "/subjectLevelEntry/subjectDetail",
      component: _6d9c2290,
      name: "subjectLevelEntry-subjectDetail"
    }, {
      path: "/subjectLevelEntry/upload",
      component: _969eaac4,
      name: "subjectLevelEntry-upload"
    }, {
      path: "/",
      component: _02244a55,
=======
      component: _2fa448c0,
      name: "stuStudentQuery"
    }, {
      path: "/stuStudentReoprt",
      component: _5eb454b6,
      name: "stuStudentReoprt"
    }, {
      path: "/subjectLevelEntry",
      component: _62dc5767,
      name: "subjectLevelEntry"
    }, {
      path: "/academicRecordEntry/detail",
      component: _3239b44c,
      name: "academicRecordEntry-detail"
    }, {
      path: "/academicRecordEntry/download",
      component: _27baf77a,
      name: "academicRecordEntry-download"
    }, {
      path: "/academicRecordEntry/index copy",
      component: _52cef37e,
      name: "academicRecordEntry-index copy"
    }, {
      path: "/academicRecordEntry/upload",
      component: _618151fc,
      name: "academicRecordEntry-upload"
    }, {
      path: "/academicRecordEntry/upload copy",
      component: _5859dec9,
      name: "academicRecordEntry-upload copy"
    }, {
      path: "/academicRecordEntry/uploadSetting",
      component: _438c6e38,
      name: "academicRecordEntry-uploadSetting"
    }, {
      path: "/comprehensiveQualityEntry/entry",
      component: _49f9445a,
      name: "comprehensiveQualityEntry-entry"
    }, {
      path: "/comprehensiveQualityEntry/entry copy",
      component: _911e91aa,
      name: "comprehensiveQualityEntry-entry copy"
    }, {
      path: "/comprehensiveQualityEntry/index copy",
      component: _3fe702cb,
      name: "comprehensiveQualityEntry-index copy"
    }, {
      path: "/comprehensiveQualityEntry/upload",
      component: _5e770fc9,
      name: "comprehensiveQualityEntry-upload"
    }, {
      path: "/eduGlobalSetting/setting",
      component: _aea8fb8c,
      name: "eduGlobalSetting-setting"
    }, {
      path: "/eduStudentQuery/comprehensiveQualityQuery",
      component: _52f08029,
      name: "eduStudentQuery-comprehensiveQualityQuery"
    }, {
      path: "/eduStudentQuery/index copy",
      component: _12de55f2,
      name: "eduStudentQuery-index copy"
    }, {
      path: "/famComprehensivequalityentry/entry",
      component: _da873704,
      name: "famComprehensivequalityentry-entry"
    }, {
      path: "/globalSetting/index copy",
      component: _1d9cf35e,
      name: "globalSetting-index copy"
    }, {
      path: "/globalSetting/setting",
      component: _27797172,
      name: "globalSetting-setting"
    }, {
      path: "/globalSetting/setting copy",
      component: _3cf8f913,
      name: "globalSetting-setting copy"
    }, {
      path: "/projectSetting/evaluationStandardSetting",
      component: _494a6c41,
      name: "projectSetting-evaluationStandardSetting"
    }, {
      path: "/realisticRecordEntry/upload",
      component: _2aea406b,
      name: "realisticRecordEntry-upload"
    }, {
      path: "/stuComprehensiveQualityEntry/entry",
      component: _25ba4aa0,
      name: "stuComprehensiveQualityEntry-entry"
    }, {
      path: "/stuComprehensiveQualityEntry/entry copy",
      component: _7e52a6b6,
      name: "stuComprehensiveQualityEntry-entry copy"
    }, {
      path: "/stuComprehensiveQualityEntry/index copy",
      component: _494cf845,
      name: "stuComprehensiveQualityEntry-index copy"
    }, {
      path: "/stuComprehensiveQualityEntry/mutualEvaluation",
      component: _374f1ab2,
      name: "stuComprehensiveQualityEntry-mutualEvaluation"
    }, {
      path: "/studentQuery/newIndex",
      component: _1f8798ce,
      name: "studentQuery-newIndex"
    }, {
      path: "/subjectLevelEntry/index copy",
      component: _36b0843e,
      name: "subjectLevelEntry-index copy"
    }, {
      path: "/subjectLevelEntry/subjectDetail",
      component: _f3e8669c,
      name: "subjectLevelEntry-subjectDetail"
    }, {
      path: "/subjectLevelEntry/upload",
      component: _7f6d7a88,
      name: "subjectLevelEntry-upload"
    }, {
      path: "/",
      component: _f890c51a,
>>>>>>> 484d79936a4dff4c2c04058527fc3e904646e2c7
      name: "index"
    }],

    fallback: false
  })
}
