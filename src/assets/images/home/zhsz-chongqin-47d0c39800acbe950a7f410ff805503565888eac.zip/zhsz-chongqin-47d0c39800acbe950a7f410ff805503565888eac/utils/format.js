// 学生互评录入形式
export function formatMutualType(mutualType) {
  switch (mutualType) {
    case 'L':
      return '组长统一录入'
    case 'M':
      return '组内人员相互评价'
  }
}

// 学期
export function formatSemester(semester) {
  switch (semester) {
    case '1':
      return '第一学期'
    case '2':
      return '第二学期'
  }
}

export function formatSemesterName(semesterName) {
  switch (semesterName) {
    case '上':
      return '1'
    case '下':
      return '2'
    case '1':
      return '上'
    case '2':
      return '下'
  }
}

// 学科类型
export function formatScoreType(scoreType) {
  switch (scoreType) {
    case '1':
      return '必修课'
    case '2':
      return '选修课'
  }
}

export function formatAuditStatus(status) {
  switch (status) {
    case '0':
      return '未审核'
    case '1':
      return '已通过'
    case '2':
      return '未通过'
  }
}

// 评价类型
export function formatEvaluationType(evaluation) {
  switch (evaluation) {
    case '学生自评':
      return 1
    case '家长评价':
      return 2
    case '学生互评':
      return 3
    case '导师评价':
      return 4
    case '班主任评价':
      return 5
  }
}

export function formatGradeCode(grade) {
  switch (grade) {
    case '小一':
      return '11'
    case '小二':
      return '12'
    case '小三':
      return '13'
    case '小四':
      return '14'
    case '小五':
      return '15'
    case '小六':
      return '16'
    case '初一':
      return '21'
    case '初二':
      return '22'
    case '初三':
      return '23'
    case '高一':
      return '31'
    case '高二':
      return '32'
    case '高三':
      return '33'
    case '高四':
      return '34'
    case '11':
      return '小一'
    case '12':
      return '小二'
    case '13':
      return '小三'
    case '14':
      return '小四'
    case '15':
      return '小五'
    case '16':
      return '小六'
    case '21':
      return '初一'
    case '22':
      return '初二'
    case '23':
      return '初三'
    case '31':
      return '高一'
    case '32':
      return '高二'
    case '33':
      return '高三'
    case '34':
      return '高四'
  }
}
