/**
 * 数组删除
 * @param {Array} array 要删除的数组
 * @param {Array, Number} index 下标数组或数字
 */
export function deleteIndex(array, index) {
  if (~['string', 'number'].indexOf(typeof index)) {
    array.splice(index, 1)
  } else {
    const indexLength = index.length
    index.sort(function(a, b) {
      return a - b
      // if (a - b > 0) {
      //   return 1;
      // } else if (a - b < 0) {
      //   return -1;
      // } else {
      //   return 0;
      // }
    })
    let deltimes = 0
    for (let i = 0; i < indexLength; i++) {
      array.splice(index[i] - deltimes, 1)
      deltimes++
    }
  }
  return array
}

/**
 * 深拷贝
 * @param {Object} obj
 * @returns {Object} clone的对象
 */
export function deepClone(obj) {
  if (obj === null) return obj
  if (typeof obj !== 'object') return obj
  const objClone = new obj.constructor()
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      // 判断ojb子元素是否为对象，如果是，递归复制
      if (obj[key] && typeof obj[key] === 'object') {
        objClone[key] = deepClone(obj[key])
      } else {
        // 如果不是，简单复制
        objClone[key] = obj[key]
      }
    }
  }
  return objClone
}

/**
 * 交换数组元素
 * @param {Array} arr 原数组
 * @param {Number} index1 原始下标
 * @param {Number} index2 要转换的下标
 */
export function swapArr(arr, index1, index2) {
  if (index2 < 0 || index2 > arr.length - 1) return
  arr[index1] = arr.splice(index2, 1, arr[index1])[0]
}

// 判断类型
const gettype = Object.prototype.toString
const isObj = function(o) {
  return gettype.call(o) === '[object Object]'
}

const isArray = function(o) {
  return gettype.call(o) === '[object Array]'
}

const isNULL = function(o) {
  return gettype.call(o) === '[object Null]'
}

export { isObj, isArray, isNULL }

/**
 * 比较对象或数组是否完全相等
 * @param {[Object, Array]} obj1
 * @param {[Object, Array]} obj2
 */
export function chargeObjectEqual(obj1, obj2) {
  return JSON.stringify(obj1) === JSON.stringify(obj2)
}

/**
 * 深度对比两个对象是否完全相等
 * @param {[Object, Array]} x
 * @param {[Object, Array]} y
 */
export function deepCompare(x, y) {
  let i, l, leftChain, rightChain
  function compare2Objects(x, y) {
    let p
    // remember that NaN === NaN returns false
    // and isNaN(undefined) returns true
    if (
      isNaN(x) &&
      isNaN(y) &&
      typeof x === 'number' &&
      typeof y === 'number'
    ) {
      return true
    }
    // Compare primitives and functions.
    // Check if both arguments link to the same object.
    // Especially useful on the step where we compare prototypes
    if (x === y) {
      return true
    }
    // Works in case when functions are created in constructor.
    // Comparing dates is a common scenario. Another built-ins?
    // We can even handle functions passed across iframes
    if (
      (typeof x === 'function' && typeof y === 'function') ||
      (x instanceof Date && y instanceof Date) ||
      (x instanceof RegExp && y instanceof RegExp) ||
      (x instanceof String && y instanceof String) ||
      (x instanceof Number && y instanceof Number)
    ) {
      return x.toString() === y.toString()
    }
    // At last checking prototypes as good as we can
    if (!(x instanceof Object && y instanceof Object)) {
      return false
    }
    if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
      return false
    }
    if (x.constructor !== y.constructor) {
      return false
    }
    if (x.prototype !== y.prototype) {
      return false
    }
    // Check for infinitive linking loops
    if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
      return false
    }
    // Quick checking of one object being a subset of another.
    // todo: cache the structure of arguments[0] for performance
    for (p in y) {
      if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
        return false
      } else if (typeof y[p] !== typeof x[p]) {
        return false
      }
    }
    for (p in x) {
      if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
        return false
      } else if (typeof y[p] !== typeof x[p]) {
        return false
      }
      switch (typeof x[p]) {
        case 'object':
        case 'function':
          leftChain.push(x)
          rightChain.push(y)
          if (!compare2Objects(x[p], y[p])) {
            return false
          }
          leftChain.pop()
          rightChain.pop()
          break
        default:
          if (x[p] !== y[p]) {
            return false
          }
          break
      }
    }
    return true
  }
  if (arguments.length < 1) {
    return true // Die silently? Don't know how to handle such case, please help...
    // throw "Need two or more arguments to compare";
  }
  for (i = 1, l = arguments.length; i < l; i++) {
    leftChain = [] // Todo: this can be cached
    rightChain = []
    if (!compare2Objects(arguments[0], arguments[i])) {
      return false
    }
  }
  return true
}

export function isIE() {
  if (!!window.ActiveXObject || 'ActiveXObject' in window) return true
  else return false
}

export function isEdge() {
  return navigator.userAgent.indexOf('Edge') > -1
}

/**
 *
 * @param {string} fileName 文件名
 * @param {blob} blob blob文件
 */
export function downloadFile(fileName, blob) {
  if (!blob) return
  if (isIE() || isEdge()) {
    window.navigator.msSaveOrOpenBlob(blob, fileName)
  } else {
    const url = window.URL || window.webkitURL || window.moxURL
    const downloadHref = url.createObjectURL(blob)
    const downloadLink = document.createElement('a')
    downloadLink.href = downloadHref
    downloadLink.download = fileName
    downloadLink.click()
  }
}
